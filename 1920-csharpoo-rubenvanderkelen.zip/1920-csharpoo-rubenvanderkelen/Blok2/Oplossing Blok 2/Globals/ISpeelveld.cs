﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Globals
{
    public interface ISpeelVeld
    {
        //klasse die status spelers checkt
        ISpeler Speler
        {
            get;
            set;
        }
        IDeck Deck
        {
            get;
            set;
        }
        IDeck Kerkhof
        {
            get;
            set;
        }
        IList<IKaart> MonsterVeld
        {
            get;
            set;
        }
        IList<IKaart> SpreukEnTrapVeld
        {
            get;
            set;
        }
        IList<IKaart> Hand
        {
            get;
            set;
        }
        Boolean Status
        {
            get;
            set;
        }
        ISpeelVeld speelVeldCopyConstructur(ISpeelVeld speelVeld);
        //ISpeelVeld DeepCloneSpeelVeld(ISpeelVeld speelVeld);
    }
}
