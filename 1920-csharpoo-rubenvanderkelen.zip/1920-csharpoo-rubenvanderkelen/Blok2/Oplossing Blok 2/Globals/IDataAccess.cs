﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Globals
{
    public interface IDataAccess
    {
        //spelers: naam + decknaam
        IList<string> GeefAlleSpelers();
        void VoegSpelerToe(string naamSpeler, string naamDeck);
        string GeefDeckVoorSpeler(string spelerEnDeck);
        string GeefSpelerNaam(string spelerEnDeck);
        IList<string> GeefDeckInfo(string Deck);
    }
}
