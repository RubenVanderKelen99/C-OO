﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Globals
{
    public interface ISpel
    {       
        ISpeelVeld SpeelVeld1
        {
            get;
            set;
        }
        ISpeelVeld SpeelVeld2
        {
            get;
            set;
        }

        void EersteBeurt();
    }
}
