﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Globals
{
    public interface ISpeler
    {
        string Naam
        {
            get;
            set;
        }
        int SpelerHp
        {
            get;
            set;
        }
        Boolean Status
        {
            get;
            set;
        }
        IDeck StartDeck
        {
            get;
            set;
        }
        
        /*ISpeler GeefSpeler();
        void ZetSpelerNaam(string naam);
        string GeefSpelerNaam();
        int GeefSpelerHP();
        Boolean GeefSpelerStatus();
        IDeck GeefStartDeck();*/
    }
}
