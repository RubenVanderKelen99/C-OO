﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Globals
{
    public interface IKaart
    {
        IKaart GeefKaart();
        string GeefKaartNaam();
        List<string> ToonKaartActies();
        void KaartActie(string actie);
    }

    public enum Locatie
    {
        Deck,
        Hand,
        Kerkhof,
        MonsterVeld,
        SpreukTrapVeld
    }

    public enum Soort
    {
        Monster,
        Spreuk,
        Trap
    }

    public enum Element
    {
        Vuur,
        Water,
        Aarde,
        Lucht
    }

    public enum Effect
    {
        Vernietig,
        Versterk,
        Verzwak,
        TrekKaart
    }
}
