﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Globals
{
    public interface IDeck
    {
       IDictionary<string, IKaart> Kaarten
        {
            get;
            set;
        }
        void MaakDeck(IList<string> deckInfo);
        IKaart HaalSpecifiekeKaart(string naamKaart);
    }
}
