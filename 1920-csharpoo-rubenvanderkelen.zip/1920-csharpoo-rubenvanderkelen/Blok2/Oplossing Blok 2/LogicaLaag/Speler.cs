﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Globals;


namespace LogicaLaag
{
    public class Speler : ISpeler
    {
        private IDeck _startDeck = new Deck();

        public string Naam { get; set; }
        public int SpelerHp { get; set; }
        public bool Status { get; set; }
        public IDeck StartDeck
        {
            get
            {
                return _startDeck;
            }
            set
            {
                if (value.Kaarten.Count == 0) throw new ArgumentException("Leeg Deck");
                _startDeck = value;
            }
        }

        public Speler()
        {
            this.SpelerHp = 4500;
            this.Status = true;
        }
        public Speler(string naam, IDeck deck)
        {
            this.Naam = naam;
            this.SpelerHp = 4500;
            this.Status = true;
            this.StartDeck = deck;
        }

        //korte delegate test
        delegate int schadeBerekening(int aanval, int doel);

        public void NeemSchade(IKaart aanvaller)
        {
            schadeBerekening test;
            test = (aanval, doel) => doel - aanval;

            this.SpelerHp = test(1500, SpelerHp);
        }

        public void CheckStatus()
        {
            throw new NotImplementedException();
        }
    }
}
