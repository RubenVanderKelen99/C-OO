﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Globals;

namespace LogicaLaag
{
    public class KaartSpel : ISpel
    {
        public ISpeelVeld SpeelVeld1 { get; set; }
        public ISpeelVeld SpeelVeld2 { get; set; }

        public KaartSpel()
        {
        }
        public KaartSpel(ISpeelVeld speelVeld1, ISpeelVeld speelVeld2)
        {
            this.SpeelVeld1 = speelVeld1;
            this.SpeelVeld2 = speelVeld2;
        }
        public void EersteBeurt()
        {
            this.SpeelVeld1.Status = true;
            for (int i = 0; i < 3; i++)
            {
                this.SpeelVeld1.Hand.Add(SpeelVeld1.Deck.Kaarten[SpeelVeld1.Deck.Kaarten.Keys.Last()]);
                this.SpeelVeld1.Deck.Kaarten.Remove(SpeelVeld1.Deck.Kaarten.Keys.Last());
                this.SpeelVeld2.Hand.Add(SpeelVeld2.Deck.Kaarten[SpeelVeld2.Deck.Kaarten.Keys.Last()]);
                this.SpeelVeld2.Deck.Kaarten.Remove(SpeelVeld2.Deck.Kaarten.Keys.Last());
            }
        }
    }
}
