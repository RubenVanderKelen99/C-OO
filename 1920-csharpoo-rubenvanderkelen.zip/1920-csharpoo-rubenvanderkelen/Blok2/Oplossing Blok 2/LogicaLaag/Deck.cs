﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Globals;

namespace LogicaLaag
{
    public class Deck : IDeck
    {
        private IDictionary<string, IKaart> kaarten = new SortedDictionary<string, IKaart>();
        public Deck()
        {

        }
        public Deck(IList<IKaart> kaarten)
        {
            IDictionary<string, IKaart> temp = new SortedDictionary<string, IKaart>();
            foreach (IKaart kaart in kaarten)
            {
                temp.Add(kaart.GeefKaartNaam(), kaart);
            }
            Kaarten = temp;
        }

        public IDictionary<string, IKaart> Kaarten
        {
            get
            {
                return kaarten;
            }
            set
            {
                value = kaarten;
            }
        }

        //Zoeken naar specifieke kaart via key => dictionary
        public IKaart HaalSpecifiekeKaart(string naamKaart)
        {
            if (Kaarten.ContainsKey(naamKaart))
            {
                return Kaarten[naamKaart];
            }
            else
            {
                throw new ArgumentException($"Dit Deck bevat geen kaart genaamd: {naamKaart}");
            }
        }

        public void MaakDeck(IList<string> deckInfo)
        {
            IList<string> woordenLijst = new List<string>();
            foreach (string kaartInfo in deckInfo)
            {
                string[] woorden = kaartInfo.Split('*');
                woordenLijst.Clear();
                foreach (string woord in woorden)
                {
                    woordenLijst.Add(woord);
                }
                VoegKaartToe(woordenLijst);
            }
        }

        private void VoegKaartToe(IList<string> kaartInfo)
        {
            switch (kaartInfo[0])
            {
                case "Monster":
                    MonsterKaart monsterKaart = new MonsterKaart(kaartInfo[1], Int32.Parse(kaartInfo[2]), Int32.Parse(kaartInfo[3]), (Element)Enum.Parse(typeof(Element), kaartInfo[4]));
                    kaarten.Add(monsterKaart.GeefKaartNaam(), monsterKaart);
                    break;
                case "Trap":
                    TrapKaart trapKaart = new TrapKaart(kaartInfo[1], (Effect)Enum.Parse(typeof(Effect), kaartInfo[2]), Int32.Parse(kaartInfo[3]));
                    kaarten.Add(trapKaart.GeefKaartNaam(), trapKaart);
                    break;
                case "Spreuk":
                    SpreukKaart spreukKaart = new SpreukKaart(kaartInfo[1], (Effect)Enum.Parse(typeof(Effect), kaartInfo[2]), Int32.Parse(kaartInfo[3]));
                    kaarten.Add(spreukKaart.GeefKaartNaam(), spreukKaart);
                    break;
                default:
                    throw new ArgumentException($"Foutieve soort: {kaartInfo[0]} voor de kaart: {kaartInfo[1]}");
                    break;
            }
        }
    }
}
