﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Globals;

namespace LogicaLaag
{
    /*public enum Locatie
    {
        Deck,
        Hand,
        Kerkhof,
        MonsterVeld,
        SpreukTrapVeld
    }

    public enum Soort
    {
        Monster,
        Spreuk,
        Trap
    }

    public enum Element
    {
        Vuur,
        Water,
        Aarde,
        Lucht
    }*/

    public abstract class Kaart : IKaart
    {
        private Soort soort;
        private Locatie locatie;

        public Kaart(string naam, Soort soort)
        {
            this.Naam = naam;
            this.Status = true;
            this.Soort = soort;
            this.Locatie = Locatie.Deck;
        }
        public string Naam { get; set; }
        public Boolean Status { get; set; }
        public Soort Soort
        {
            get
            {
                return this.soort;
            }
            set
            {
                if (!Enum.IsDefined(typeof(Soort), value)) throw new ArgumentNullException($"Verkeerde soort voor kaart: {this.Naam}");
                this.soort = value;
            }
        }

        public Locatie Locatie
        {
            get
            {
                return this.locatie;
            }
            set
            {
                if (!Enum.IsDefined(typeof(Locatie), value)) throw new ArgumentNullException($"Verkeerde soort voor kaart: {this.Naam}");
                this.locatie = value;
            }
        }

        public abstract IKaart GeefKaart();
        public abstract string GeefKaartNaam();
        public abstract void KaartActie(string actie);
        public abstract List<string> ToonKaartActies();
    }

    public class MonsterKaart : Kaart, IKaart
    {
        private int ap;
        private int dp;
        private Element element;
        public MonsterKaart(string naam, int ap, int dp, Element element) : base(naam, Soort.Monster)
        {
            this.Ap = ap;
            this.Dp = dp;
            this.Element = element;
            this.Stand = true;
        }

        public int Ap
        {
            get
            {
                return this.ap;
            }
            set
            {
                if (value < 0) throw new ArgumentNullException($"Negatieve Ap-waarde onmogelijke bij kaart: {this.Naam}, waarde van {value}");
                if (value > 10000) throw new ArgumentNullException($"Ap-waarde te groot bij kaart: {this.Naam}, waarde van: {value}");
                this.ap = value;
            }
        }

        public int Dp
        {
            get
            {
                return this.dp;
            }
            set
            {
                if (value < 0) throw new ArgumentNullException($"Negatieve Ap-waarde onmogelijke bij kaart: {this.Naam}, waarde van {value}");
                if (value > 10000) throw new ArgumentNullException($"Ap-waarde te groot bij kaart: {this.Naam}, waarde van: {value}");
                this.dp = value;
            }
        }

        public Element Element
        {
            get
            {
                return this.element;
            }
            set
            {
                if (!Enum.IsDefined(typeof(Element), value)) throw new ArgumentNullException($"Onbestaand element voor kaart: {this.Naam}, zijnde {value}");
                this.element = value;
            }
        }

        public Boolean Stand { get; set; }

        public override IKaart GeefKaart()
        {
            return this;
        }

        public override string GeefKaartNaam()
        {
            return this.Naam;
        }

        public override void KaartActie(string actie)
        {
            if (actie.Equals("Plaats offensief"))
            {
                this.Locatie = Locatie.MonsterVeld;
            }
            else if (actie.Equals("Plaats Defensief"))
            {
                this.Locatie = Locatie.MonsterVeld;
                this.Stand = false;
            }
            else if (actie.Equals("Verander stand"))
            {
                this.Stand = !(this.Stand);
            }
            else if (actie.StartsWith("Doe aanval"))
            {
                this.DoeAanval(actie.Substring(11));
            }
            else
            {
                throw new ArgumentException($"De actie: {actie} is onmogelijk voor deze kaart: {this.GeefKaartNaam()}");
            }
        }        

        public override List<string> ToonKaartActies()
        {
            List<string> acties = new List<string>();
            if (this.Locatie == Locatie.Hand)
            {
                acties.Add("Plaats offensief");
                acties.Add("Plaats defensief");
            }
            else if (this.Locatie == Locatie.MonsterVeld)
            {
                acties.Add("Verander stand");
                acties.Add("Doe aanval");
            }
            else
            {
                acties.Add("Geen");
            }
            return acties;
        }

        public void DoeAanval(string doelwit)
        {
            if (string.IsNullOrWhiteSpace(doelwit)) throw new ArgumentNullException("Geen doelwit opgegeven");
            else
            {
                throw new NotImplementedException();
            }
        }
    }

    /*public enum Effect
    {
        Vernietig,
        Versterk,
        Verzwak,
        TrekKaart
    }*/

    public class SpreukKaart : Kaart, IKaart
    {
        private Effect effect;

        public SpreukKaart(string naam, Effect effect, int sterkte) : base(naam, Soort.Spreuk)
        {
            this.effect = effect;
            this.Sterkte = sterkte;
        }

        public int Sterkte { get; set; }

        public override IKaart GeefKaart()
        {
            return this;
        }

        public override string GeefKaartNaam()
        {
            return this.Naam;
        }

        public override void KaartActie(string actie)
        {
            if (actie.Equals("Plaats"))
            {
                this.Locatie = Locatie.SpreukTrapVeld;
            }
            else if (actie.StartsWith("Activeer effect"))
            {
                this.ActiveerEffect(actie.Substring(16));
            }
            else
            {
                throw new ArgumentException($"De actie: {actie} is onmogelijk voor deze kaart: {this.GeefKaartNaam()}");
            }
        }

        public override List<string> ToonKaartActies()
        {
            List<string> acties = new List<string>();
            if (this.Locatie == Locatie.Hand)
            {
                acties.Add("Plaats");
                acties.Add("Activeer effect");
            }
            else if (this.Locatie == Locatie.SpreukTrapVeld)
            {
                acties.Add("Activeer effect");
            }
            else
            {
                acties.Add("Geen");
            }
            return acties;
        }

        public void ActiveerEffect(string doelwit)
        {
            if (string.IsNullOrWhiteSpace(doelwit)) throw new ArgumentNullException("Geen doelwit opgegeven");
            else
            {
                throw new NotImplementedException();
            }
        }
    }

    public class TrapKaart : Kaart, IKaart
    {
        private Effect effect;

        public TrapKaart(string naam, Effect effect, int sterkte) : base(naam, Soort.Trap)
        {
            this.effect = effect;
            this.Sterkte = sterkte;
            this.Lock = true;
        }

        public int Sterkte { get; set; }
        public Boolean Lock { get; set; }

        public override IKaart GeefKaart()
        {
            return this;
        }

        public override string GeefKaartNaam()
        {
            return this.Naam;
        }

        public override void KaartActie(string actie)
        {
            if (actie.Equals("Plaats"))
            {
                this.Locatie = Locatie.SpreukTrapVeld;
            }
            else if (actie.StartsWith("Activeer effect"))
            {
                this.ActiveerEffect(actie.Substring(16));
            }
            else
            {
                throw new ArgumentException($"De actie: {actie} is onmogelijk voor deze kaart: {this.GeefKaartNaam()}");
            }
        }

        public override List<string> ToonKaartActies()
        {
            List<string> acties = new List<string>();
            if (this.Locatie == Locatie.Hand)
            {
                acties.Add("Plaats");
            }
            else if (this.Locatie == Locatie.SpreukTrapVeld)
            {
                acties.Add("Activeer effect");
            }
            else
            {
                acties.Add("Geen");
            }
            return acties;
        }

        public void ActiveerEffect(string doelwit)
        {
            if (string.IsNullOrWhiteSpace(doelwit)) throw new ArgumentNullException("Geen doelwit opgegeven");
            else
            {
                throw new NotImplementedException();
            }
        }

    }
}
