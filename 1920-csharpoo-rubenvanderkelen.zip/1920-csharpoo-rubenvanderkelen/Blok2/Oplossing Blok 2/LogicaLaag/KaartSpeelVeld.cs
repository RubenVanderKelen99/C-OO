﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Globals;

namespace LogicaLaag
{
    [Serializable]
    public class KaartSpeelVeld : ISpeelVeld
    {
        //klasse die status spelers checkt
        /*private ISpeler speler;
        private IDeck deck;
        private IDeck graveyard;
        private List<Kaart> spreukEnTrapVeld;
        private List<Kaart> monsterVeld;*/

        public ISpeler Speler { get; set; }
        public IDeck Deck { get; set; }
        public IDeck Kerkhof { get; set; }
        public IList<IKaart> MonsterVeld { get; set; }
        public IList<IKaart> SpreukEnTrapVeld { get; set; }
        public IList<IKaart> Hand { get; set; }
        public bool Status { get; set; }

        public KaartSpeelVeld(ISpeler speler, IDeck deck)
        {
            this.Speler = speler;
            this.Deck = deck;
            this.Kerkhof = new Deck();
            this.MonsterVeld = new List<IKaart>(5);
            this.SpreukEnTrapVeld = new List<IKaart>(5);
            this.Hand = new List<IKaart>();
            this.Status = false;
        }

        public KaartSpeelVeld(ISpeelVeld kopie)
        {
            this.Speler = kopie.Speler;
            this.Speler.Naam = ($"{kopie.Speler.Naam}2");
            this.Deck = kopie.Deck;
            this.Kerkhof = kopie.Kerkhof;
            this.MonsterVeld = kopie.MonsterVeld;
            this.SpreukEnTrapVeld = kopie.SpreukEnTrapVeld;
            this.Hand = kopie.Hand;
            this.Status = false;
        }

        public ISpeelVeld speelVeldCopyConstructur(ISpeelVeld speelVeld)
        {
            ISpeelVeld nieuw = new KaartSpeelVeld(speelVeld);
            return nieuw;
        }

        /*public ISpeelVeld DeepCloneSpeelVeld(ISpeelVeld speelVeld)
        {

                if (!typeof(KaartSpeelVeld).IsSerializable)
                {
                    throw new ArgumentException("The type must be serializable.", "speelVeld");
                }

                if (Object.ReferenceEquals(speelVeld, null))
                {
                    return default(KaartSpeelVeld);
                }

                IFormatter formatter = new BinaryFormatter();
                Stream stream = new MemoryStream();
                using (stream)
                {
                    formatter.Serialize(stream, speelVeld);
                    stream.Seek(0, SeekOrigin.Begin);
                    return (ISpeelVeld)formatter.Deserialize(stream);
                }
            
        }*/
    }
}
