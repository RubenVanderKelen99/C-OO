﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Globals;

namespace DataAccessLaag
{
    public class DataAccessImplementatie : IDataAccess
    {
        private string projectDirectory;
        public DataAccessImplementatie()
        {
            this.projectDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
        }
        public string FetchDataPath(string fileName)
        {
            string filePath = projectDirectory + @"\Data\" + fileName;
            return filePath;
        }

        public IList<string> GeefAlleSpelers()
        {
            string spelersFilePath = FetchDataPath("Spelers.txt");
            IList<string> lijnen = LeesBestandPerLijn(spelersFilePath);
            IList<string> woorden;
            IList<string> spelers = new List<string>();
            foreach (string lijn in lijnen)
            {
                woorden = (ConverteerLijnNaarWoorden(lijn));
                string speler = "";
                foreach (string woord in woorden)
                {
                    speler += woord + " ";
                }
                spelers.Add(speler);
            }
            return spelers;
        }

        public IList<string> GeefDeckInfo(string Deck)
        {
            string spelersFilePath = FetchDataPath($"{Deck}.txt");
            IList<string> lijnen = LeesBestandPerLijn(spelersFilePath);
            return lijnen;
            /*IList<string> woorden;
            IList<string> kaarten = new List<string>();
            foreach (string lijn in lijnen)
            {
                woorden = (ConverteerLijnNaarWoorden(lijn));
                string kaart = "";
                foreach (string woord in woorden)
                {
                    kaart += woord + " ";
                }
                kaarten.Add(kaart);
            }
            return kaarten;*/
        }

        private IList<string> LeesBestandPerLijn(string filePath)
        {
            StreamReader sr = new StreamReader(filePath);
            string lijn = "";
            IList<string> lijnen = new List<string>();
            while ((lijn = sr.ReadLine()) != null)
            {
                lijnen.Add(lijn);
            }
            sr.Close();
            return lijnen;
        }

        private IList<string> ConverteerLijnNaarWoorden(string lijn)
        {
            IList<string> woordenLijst = new List<string>();
            string[] woorden = lijn.Split('*');
            foreach (string woord in woorden)
            {
                woordenLijst.Add(woord);
            }
            return woordenLijst;
        }

        public void VoegSpelerToe(string naamSpeler, string naamDeck)
        {
            string spelersFilePath = FetchDataPath("Spelers.txt");
            StreamWriter sw = new StreamWriter(spelersFilePath, append: true);
            sw.WriteLine($"{naamSpeler}*{naamDeck}");
            sw.Close();
        }

        public string GeefSpelerNaam(string spelerEnDeck)
        {
            string[] woorden = spelerEnDeck.Split(' '); ;
            return woorden[0];
        }

        public string GeefDeckVoorSpeler(string spelerEnDeck)
        {
            string[] woorden = spelerEnDeck.Split(' '); ;
            return woorden[1];
        }

        /* private bool StudentExists(string naam, string wachtwoord, string path)
        {
            StreamReader sr = new StreamReader(path);
            string lijn = "";
            //while (!(String.IsNullOrEmpty(sr.ReadLine())))
            while ((lijn = sr.ReadLine()) != null)
            {
                string[] woorden = lijn.Split('*');
                if (woorden[0] == naam)
                {
                    if (woorden[1] == wachtwoord)
                    {
                        sr.Close();
                        return true;
                    }
                }
            }
            sr.Close();
            return false;
        }

        private void ButtonRegistreerReg_Click(object sender, EventArgs e)
        {
            string naam = textBoxNaamReg.Text;
            string wachtwoord = textBoxPassReg.Text;
            labelErrorReg.Visible = false;
            if (!CheckNaamEnPass(naam, wachtwoord))
            {
                try
                {
                    Student nieuweGebruiker = new Student(naam, wachtwoord);
                    EmptyUserTextBoxes();
                    GenerateUserFiles(nieuweGebruiker);
                    SaveUser(nieuweGebruiker);
                    StartSession(nieuweGebruiker);
                }
                catch (Exception ex)
                {
                    labelErrorReg.Visible = true;
                    labelErrorReg.Text = $"Error: {ex.Message} ";
                }
                finally
                {
                    EmptyUserTextBoxes();
                }
            }
            else
            {
                labelErrorReg.Visible = true;
                labelErrorReg.Text = "Error: die gebruiker bestaat al";
            }
        }

        private void SaveUser(Student gebruiker)
        {
            FetchDataPath studentPath = new FetchDataPath("Student.txt");
            string path = studentPath.ProjectDirectory;
            StreamWriter sw = new StreamWriter(path, append:true);
            sw.WriteLine($"{gebruiker.Naam}*{gebruiker.Wachtwoord}");
            sw.Close();
        }

        private void GenerateUserFiles(Student gebruiker)
        {
            FetchDataPath studentFilesPath = new FetchDataPath("Studenten");
            string path = System.IO.Path.Combine(studentFilesPath.ProjectDirectory, gebruiker.Naam);
            StreamWriter userFile = new StreamWriter($"{path}.txt");
            userFile.WriteLine("");
            userFile.Close();
            /*StreamWriter sw = File.CreateText($@"{studentFilesPath.ProjectDirectory}\{gebruiker.Naam}");
            sw.WriteLine("test");
            sw.Close();
    } */
    }
}
