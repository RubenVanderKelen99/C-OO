﻿namespace WindowsFormsApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelStart = new System.Windows.Forms.Panel();
            this.panelSpel = new System.Windows.Forms.Panel();
            this.labelErrorMessage = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStartCopy = new System.Windows.Forms.Button();
            this.labelSpeler1 = new System.Windows.Forms.Label();
            this.comboBoxSpeler2 = new System.Windows.Forms.ComboBox();
            this.labelSpeler2 = new System.Windows.Forms.Label();
            this.comboBoxSpeler1 = new System.Windows.Forms.ComboBox();
            this.labelNaamSpeler1 = new System.Windows.Forms.Label();
            this.labelNaamSpeler2 = new System.Windows.Forms.Label();
            this.labelDeckSpeler1 = new System.Windows.Forms.Label();
            this.labelDeckKaarten1 = new System.Windows.Forms.Label();
            this.labelDeckSpeler2 = new System.Windows.Forms.Label();
            this.labelKerkhofSpeler2 = new System.Windows.Forms.Label();
            this.labelKaartenKerkhof2 = new System.Windows.Forms.Label();
            this.labelHandSpeler2 = new System.Windows.Forms.Label();
            this.labelVeld2Speler2 = new System.Windows.Forms.Label();
            this.labelVeld1Speler2 = new System.Windows.Forms.Label();
            this.labelKerkhofSpeler1 = new System.Windows.Forms.Label();
            this.labelKaartenKerkhof1 = new System.Windows.Forms.Label();
            this.labelVeld1Speler1 = new System.Windows.Forms.Label();
            this.labelVeld2Speler1 = new System.Windows.Forms.Label();
            this.labelHandSpeler1 = new System.Windows.Forms.Label();
            this.labelKaartenHandSpeler2 = new System.Windows.Forms.Label();
            this.labelKaartenVeld2Speler2 = new System.Windows.Forms.Label();
            this.labelKaartenVeld1Speler2 = new System.Windows.Forms.Label();
            this.labelKaartenVeld1Speler1 = new System.Windows.Forms.Label();
            this.labelKaartenVeld2Speler1 = new System.Windows.Forms.Label();
            this.labelKaartenHandSpeler1 = new System.Windows.Forms.Label();
            this.labelDeckKaarten2 = new System.Windows.Forms.Label();
            this.labelHPSpeler1 = new System.Windows.Forms.Label();
            this.labelHPSpeler2 = new System.Windows.Forms.Label();
            this.panelStart.SuspendLayout();
            this.panelSpel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelStart
            // 
            this.panelStart.Controls.Add(this.panelSpel);
            this.panelStart.Controls.Add(this.labelErrorMessage);
            this.panelStart.Controls.Add(this.buttonStart);
            this.panelStart.Controls.Add(this.buttonStartCopy);
            this.panelStart.Controls.Add(this.labelSpeler1);
            this.panelStart.Controls.Add(this.comboBoxSpeler2);
            this.panelStart.Controls.Add(this.labelSpeler2);
            this.panelStart.Controls.Add(this.comboBoxSpeler1);
            this.panelStart.Location = new System.Drawing.Point(4, 3);
            this.panelStart.Name = "panelStart";
            this.panelStart.Size = new System.Drawing.Size(868, 546);
            this.panelStart.TabIndex = 1;
            // 
            // panelSpel
            // 
            this.panelSpel.Controls.Add(this.labelHPSpeler2);
            this.panelSpel.Controls.Add(this.labelHPSpeler1);
            this.panelSpel.Controls.Add(this.labelDeckKaarten2);
            this.panelSpel.Controls.Add(this.labelKaartenHandSpeler1);
            this.panelSpel.Controls.Add(this.labelKaartenVeld2Speler1);
            this.panelSpel.Controls.Add(this.labelKaartenVeld1Speler1);
            this.panelSpel.Controls.Add(this.labelKaartenVeld1Speler2);
            this.panelSpel.Controls.Add(this.labelKaartenVeld2Speler2);
            this.panelSpel.Controls.Add(this.labelKaartenHandSpeler2);
            this.panelSpel.Controls.Add(this.labelHandSpeler1);
            this.panelSpel.Controls.Add(this.labelVeld2Speler1);
            this.panelSpel.Controls.Add(this.labelVeld1Speler1);
            this.panelSpel.Controls.Add(this.labelKaartenKerkhof1);
            this.panelSpel.Controls.Add(this.labelKerkhofSpeler1);
            this.panelSpel.Controls.Add(this.labelVeld1Speler2);
            this.panelSpel.Controls.Add(this.labelVeld2Speler2);
            this.panelSpel.Controls.Add(this.labelHandSpeler2);
            this.panelSpel.Controls.Add(this.labelKaartenKerkhof2);
            this.panelSpel.Controls.Add(this.labelKerkhofSpeler2);
            this.panelSpel.Controls.Add(this.labelDeckSpeler2);
            this.panelSpel.Controls.Add(this.labelDeckKaarten1);
            this.panelSpel.Controls.Add(this.labelDeckSpeler1);
            this.panelSpel.Controls.Add(this.labelNaamSpeler2);
            this.panelSpel.Controls.Add(this.labelNaamSpeler1);
            this.panelSpel.Location = new System.Drawing.Point(3, 3);
            this.panelSpel.Name = "panelSpel";
            this.panelSpel.Size = new System.Drawing.Size(875, 549);
            this.panelSpel.TabIndex = 10;
            this.panelSpel.Visible = false;
            // 
            // labelErrorMessage
            // 
            this.labelErrorMessage.AutoSize = true;
            this.labelErrorMessage.ForeColor = System.Drawing.Color.Red;
            this.labelErrorMessage.Location = new System.Drawing.Point(368, 229);
            this.labelErrorMessage.Name = "labelErrorMessage";
            this.labelErrorMessage.Size = new System.Drawing.Size(29, 13);
            this.labelErrorMessage.TabIndex = 9;
            this.labelErrorMessage.Text = "Error";
            this.labelErrorMessage.Visible = false;
            // 
            // buttonStart
            // 
            this.buttonStart.Enabled = false;
            this.buttonStart.Location = new System.Drawing.Point(371, 245);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(121, 35);
            this.buttonStart.TabIndex = 8;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = false;
            this.buttonStart.Visible = false;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStartCopy
            // 
            this.buttonStartCopy.Enabled = false;
            this.buttonStartCopy.Location = new System.Drawing.Point(558, 129);
            this.buttonStartCopy.Name = "buttonStartCopy";
            this.buttonStartCopy.Size = new System.Drawing.Size(137, 35);
            this.buttonStartCopy.TabIndex = 7;
            this.buttonStartCopy.Text = "Start (2x speler1 Copy Constr)";
            this.buttonStartCopy.UseVisualStyleBackColor = true;
            this.buttonStartCopy.Visible = false;
            this.buttonStartCopy.Click += new System.EventHandler(this.buttonStartCopy_Click);
            // 
            // labelSpeler1
            // 
            this.labelSpeler1.AutoSize = true;
            this.labelSpeler1.Location = new System.Drawing.Point(297, 140);
            this.labelSpeler1.Name = "labelSpeler1";
            this.labelSpeler1.Size = new System.Drawing.Size(43, 13);
            this.labelSpeler1.TabIndex = 2;
            this.labelSpeler1.Text = "Speler1";
            this.labelSpeler1.Click += new System.EventHandler(this.labelSpeler1_Click);
            // 
            // comboBoxSpeler2
            // 
            this.comboBoxSpeler2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeler2.FormattingEnabled = true;
            this.comboBoxSpeler2.Location = new System.Drawing.Point(371, 193);
            this.comboBoxSpeler2.Name = "comboBoxSpeler2";
            this.comboBoxSpeler2.Size = new System.Drawing.Size(121, 21);
            this.comboBoxSpeler2.TabIndex = 6;
            this.comboBoxSpeler2.SelectedIndexChanged += new System.EventHandler(this.comboBoxSpeler2_SelectedIndexChanged);
            // 
            // labelSpeler2
            // 
            this.labelSpeler2.AutoSize = true;
            this.labelSpeler2.Location = new System.Drawing.Point(297, 196);
            this.labelSpeler2.Name = "labelSpeler2";
            this.labelSpeler2.Size = new System.Drawing.Size(43, 13);
            this.labelSpeler2.TabIndex = 3;
            this.labelSpeler2.Text = "Speler2";
            // 
            // comboBoxSpeler1
            // 
            this.comboBoxSpeler1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSpeler1.FormattingEnabled = true;
            this.comboBoxSpeler1.Location = new System.Drawing.Point(371, 137);
            this.comboBoxSpeler1.Name = "comboBoxSpeler1";
            this.comboBoxSpeler1.Size = new System.Drawing.Size(121, 21);
            this.comboBoxSpeler1.TabIndex = 5;
            this.comboBoxSpeler1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // labelNaamSpeler1
            // 
            this.labelNaamSpeler1.AutoSize = true;
            this.labelNaamSpeler1.Location = new System.Drawing.Point(415, 517);
            this.labelNaamSpeler1.Name = "labelNaamSpeler1";
            this.labelNaamSpeler1.Size = new System.Drawing.Size(43, 13);
            this.labelNaamSpeler1.TabIndex = 0;
            this.labelNaamSpeler1.Text = "Speler1";
            this.labelNaamSpeler1.Click += new System.EventHandler(this.labelSpelerNaam1_Click);
            // 
            // labelNaamSpeler2
            // 
            this.labelNaamSpeler2.AutoSize = true;
            this.labelNaamSpeler2.Location = new System.Drawing.Point(415, 16);
            this.labelNaamSpeler2.Name = "labelNaamSpeler2";
            this.labelNaamSpeler2.Size = new System.Drawing.Size(43, 13);
            this.labelNaamSpeler2.TabIndex = 1;
            this.labelNaamSpeler2.Text = "Speler2";
            this.labelNaamSpeler2.Click += new System.EventHandler(this.label2_Click);
            // 
            // labelDeckSpeler1
            // 
            this.labelDeckSpeler1.AutoSize = true;
            this.labelDeckSpeler1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDeckSpeler1.Location = new System.Drawing.Point(796, 460);
            this.labelDeckSpeler1.Name = "labelDeckSpeler1";
            this.labelDeckSpeler1.Size = new System.Drawing.Size(37, 13);
            this.labelDeckSpeler1.TabIndex = 2;
            this.labelDeckSpeler1.Text = "Deck";
            // 
            // labelDeckKaarten1
            // 
            this.labelDeckKaarten1.AutoSize = true;
            this.labelDeckKaarten1.Location = new System.Drawing.Point(800, 484);
            this.labelDeckKaarten1.Name = "labelDeckKaarten1";
            this.labelDeckKaarten1.Size = new System.Drawing.Size(19, 13);
            this.labelDeckKaarten1.TabIndex = 3;
            this.labelDeckKaarten1.Text = "[0]";
            // 
            // labelDeckSpeler2
            // 
            this.labelDeckSpeler2.AutoSize = true;
            this.labelDeckSpeler2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDeckSpeler2.Location = new System.Drawing.Point(800, 19);
            this.labelDeckSpeler2.Name = "labelDeckSpeler2";
            this.labelDeckSpeler2.Size = new System.Drawing.Size(37, 13);
            this.labelDeckSpeler2.TabIndex = 4;
            this.labelDeckSpeler2.Text = "Deck";
            // 
            // labelKerkhofSpeler2
            // 
            this.labelKerkhofSpeler2.AutoSize = true;
            this.labelKerkhofSpeler2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelKerkhofSpeler2.Location = new System.Drawing.Point(29, 19);
            this.labelKerkhofSpeler2.Name = "labelKerkhofSpeler2";
            this.labelKerkhofSpeler2.Size = new System.Drawing.Size(51, 13);
            this.labelKerkhofSpeler2.TabIndex = 6;
            this.labelKerkhofSpeler2.Text = "Kerkhof";
            // 
            // labelKaartenKerkhof2
            // 
            this.labelKaartenKerkhof2.AutoSize = true;
            this.labelKaartenKerkhof2.Location = new System.Drawing.Point(30, 52);
            this.labelKaartenKerkhof2.Name = "labelKaartenKerkhof2";
            this.labelKaartenKerkhof2.Size = new System.Drawing.Size(19, 13);
            this.labelKaartenKerkhof2.TabIndex = 7;
            this.labelKaartenKerkhof2.Text = "[0]";
            // 
            // labelHandSpeler2
            // 
            this.labelHandSpeler2.AutoSize = true;
            this.labelHandSpeler2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHandSpeler2.Location = new System.Drawing.Point(162, 89);
            this.labelHandSpeler2.Name = "labelHandSpeler2";
            this.labelHandSpeler2.Size = new System.Drawing.Size(37, 13);
            this.labelHandSpeler2.TabIndex = 8;
            this.labelHandSpeler2.Text = "Hand";
            // 
            // labelVeld2Speler2
            // 
            this.labelVeld2Speler2.AutoSize = true;
            this.labelVeld2Speler2.Location = new System.Drawing.Point(163, 123);
            this.labelVeld2Speler2.Name = "labelVeld2Speler2";
            this.labelVeld2Speler2.Size = new System.Drawing.Size(34, 13);
            this.labelVeld2Speler2.TabIndex = 9;
            this.labelVeld2Speler2.Text = "Veld2";
            // 
            // labelVeld1Speler2
            // 
            this.labelVeld1Speler2.AutoSize = true;
            this.labelVeld1Speler2.Location = new System.Drawing.Point(163, 158);
            this.labelVeld1Speler2.Name = "labelVeld1Speler2";
            this.labelVeld1Speler2.Size = new System.Drawing.Size(34, 13);
            this.labelVeld1Speler2.TabIndex = 10;
            this.labelVeld1Speler2.Text = "Veld1";
            // 
            // labelKerkhofSpeler1
            // 
            this.labelKerkhofSpeler1.AutoSize = true;
            this.labelKerkhofSpeler1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelKerkhofSpeler1.Location = new System.Drawing.Point(33, 484);
            this.labelKerkhofSpeler1.Name = "labelKerkhofSpeler1";
            this.labelKerkhofSpeler1.Size = new System.Drawing.Size(51, 13);
            this.labelKerkhofSpeler1.TabIndex = 11;
            this.labelKerkhofSpeler1.Text = "Kerkhof";
            // 
            // labelKaartenKerkhof1
            // 
            this.labelKaartenKerkhof1.AutoSize = true;
            this.labelKaartenKerkhof1.Location = new System.Drawing.Point(34, 515);
            this.labelKaartenKerkhof1.Name = "labelKaartenKerkhof1";
            this.labelKaartenKerkhof1.Size = new System.Drawing.Size(19, 13);
            this.labelKaartenKerkhof1.TabIndex = 12;
            this.labelKaartenKerkhof1.Text = "[0]";
            this.labelKaartenKerkhof1.Click += new System.EventHandler(this.labelKaartenKerkhof1_Click);
            // 
            // labelVeld1Speler1
            // 
            this.labelVeld1Speler1.AutoSize = true;
            this.labelVeld1Speler1.Location = new System.Drawing.Point(170, 366);
            this.labelVeld1Speler1.Name = "labelVeld1Speler1";
            this.labelVeld1Speler1.Size = new System.Drawing.Size(34, 13);
            this.labelVeld1Speler1.TabIndex = 13;
            this.labelVeld1Speler1.Text = "Veld1";
            // 
            // labelVeld2Speler1
            // 
            this.labelVeld2Speler1.AutoSize = true;
            this.labelVeld2Speler1.Location = new System.Drawing.Point(170, 398);
            this.labelVeld2Speler1.Name = "labelVeld2Speler1";
            this.labelVeld2Speler1.Size = new System.Drawing.Size(34, 13);
            this.labelVeld2Speler1.TabIndex = 14;
            this.labelVeld2Speler1.Text = "Veld2";
            // 
            // labelHandSpeler1
            // 
            this.labelHandSpeler1.AutoSize = true;
            this.labelHandSpeler1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHandSpeler1.Location = new System.Drawing.Point(170, 431);
            this.labelHandSpeler1.Name = "labelHandSpeler1";
            this.labelHandSpeler1.Size = new System.Drawing.Size(37, 13);
            this.labelHandSpeler1.TabIndex = 15;
            this.labelHandSpeler1.Text = "Hand";
            // 
            // labelKaartenHandSpeler2
            // 
            this.labelKaartenHandSpeler2.AutoSize = true;
            this.labelKaartenHandSpeler2.Location = new System.Drawing.Point(245, 89);
            this.labelKaartenHandSpeler2.Name = "labelKaartenHandSpeler2";
            this.labelKaartenHandSpeler2.Size = new System.Drawing.Size(31, 13);
            this.labelKaartenHandSpeler2.TabIndex = 16;
            this.labelKaartenHandSpeler2.Text = "Leeg";
            // 
            // labelKaartenVeld2Speler2
            // 
            this.labelKaartenVeld2Speler2.AutoSize = true;
            this.labelKaartenVeld2Speler2.Location = new System.Drawing.Point(245, 123);
            this.labelKaartenVeld2Speler2.Name = "labelKaartenVeld2Speler2";
            this.labelKaartenVeld2Speler2.Size = new System.Drawing.Size(31, 13);
            this.labelKaartenVeld2Speler2.TabIndex = 17;
            this.labelKaartenVeld2Speler2.Text = "Leeg";
            this.labelKaartenVeld2Speler2.Click += new System.EventHandler(this.label16_Click);
            // 
            // labelKaartenVeld1Speler2
            // 
            this.labelKaartenVeld1Speler2.AutoSize = true;
            this.labelKaartenVeld1Speler2.Location = new System.Drawing.Point(245, 158);
            this.labelKaartenVeld1Speler2.Name = "labelKaartenVeld1Speler2";
            this.labelKaartenVeld1Speler2.Size = new System.Drawing.Size(31, 13);
            this.labelKaartenVeld1Speler2.TabIndex = 18;
            this.labelKaartenVeld1Speler2.Text = "Leeg";
            // 
            // labelKaartenVeld1Speler1
            // 
            this.labelKaartenVeld1Speler1.AutoSize = true;
            this.labelKaartenVeld1Speler1.Location = new System.Drawing.Point(261, 366);
            this.labelKaartenVeld1Speler1.Name = "labelKaartenVeld1Speler1";
            this.labelKaartenVeld1Speler1.Size = new System.Drawing.Size(31, 13);
            this.labelKaartenVeld1Speler1.TabIndex = 19;
            this.labelKaartenVeld1Speler1.Text = "Leeg";
            // 
            // labelKaartenVeld2Speler1
            // 
            this.labelKaartenVeld2Speler1.AutoSize = true;
            this.labelKaartenVeld2Speler1.Location = new System.Drawing.Point(261, 398);
            this.labelKaartenVeld2Speler1.Name = "labelKaartenVeld2Speler1";
            this.labelKaartenVeld2Speler1.Size = new System.Drawing.Size(31, 13);
            this.labelKaartenVeld2Speler1.TabIndex = 20;
            this.labelKaartenVeld2Speler1.Text = "Leeg";
            // 
            // labelKaartenHandSpeler1
            // 
            this.labelKaartenHandSpeler1.AutoSize = true;
            this.labelKaartenHandSpeler1.Location = new System.Drawing.Point(261, 431);
            this.labelKaartenHandSpeler1.Name = "labelKaartenHandSpeler1";
            this.labelKaartenHandSpeler1.Size = new System.Drawing.Size(31, 13);
            this.labelKaartenHandSpeler1.TabIndex = 21;
            this.labelKaartenHandSpeler1.Text = "Leeg";
            this.labelKaartenHandSpeler1.Click += new System.EventHandler(this.labelKaartenHandSpeler1_Click);
            // 
            // labelDeckKaarten2
            // 
            this.labelDeckKaarten2.AutoSize = true;
            this.labelDeckKaarten2.Location = new System.Drawing.Point(800, 52);
            this.labelDeckKaarten2.Name = "labelDeckKaarten2";
            this.labelDeckKaarten2.Size = new System.Drawing.Size(19, 13);
            this.labelDeckKaarten2.TabIndex = 22;
            this.labelDeckKaarten2.Text = "[0]";
            // 
            // labelHPSpeler1
            // 
            this.labelHPSpeler1.AutoSize = true;
            this.labelHPSpeler1.Location = new System.Drawing.Point(508, 521);
            this.labelHPSpeler1.Name = "labelHPSpeler1";
            this.labelHPSpeler1.Size = new System.Drawing.Size(31, 13);
            this.labelHPSpeler1.TabIndex = 23;
            this.labelHPSpeler1.Text = "4500";
            // 
            // labelHPSpeler2
            // 
            this.labelHPSpeler2.AutoSize = true;
            this.labelHPSpeler2.Location = new System.Drawing.Point(508, 16);
            this.labelHPSpeler2.Name = "labelHPSpeler2";
            this.labelHPSpeler2.Size = new System.Drawing.Size(31, 13);
            this.labelHPSpeler2.TabIndex = 24;
            this.labelHPSpeler2.Text = "4500";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.panelStart);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panelStart.ResumeLayout(false);
            this.panelStart.PerformLayout();
            this.panelSpel.ResumeLayout(false);
            this.panelSpel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelStart;
        private System.Windows.Forms.Label labelSpeler1;
        private System.Windows.Forms.Label labelSpeler2;
        private System.Windows.Forms.ComboBox comboBoxSpeler1;
        private System.Windows.Forms.ComboBox comboBoxSpeler2;
        private System.Windows.Forms.Button buttonStartCopy;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Label labelErrorMessage;
        private System.Windows.Forms.Panel panelSpel;
        private System.Windows.Forms.Label labelNaamSpeler2;
        private System.Windows.Forms.Label labelNaamSpeler1;
        private System.Windows.Forms.Label labelKaartenHandSpeler1;
        private System.Windows.Forms.Label labelKaartenVeld2Speler1;
        private System.Windows.Forms.Label labelKaartenVeld1Speler1;
        private System.Windows.Forms.Label labelKaartenVeld1Speler2;
        private System.Windows.Forms.Label labelKaartenVeld2Speler2;
        private System.Windows.Forms.Label labelKaartenHandSpeler2;
        private System.Windows.Forms.Label labelHandSpeler1;
        private System.Windows.Forms.Label labelVeld2Speler1;
        private System.Windows.Forms.Label labelVeld1Speler1;
        private System.Windows.Forms.Label labelKaartenKerkhof1;
        private System.Windows.Forms.Label labelKerkhofSpeler1;
        private System.Windows.Forms.Label labelVeld1Speler2;
        private System.Windows.Forms.Label labelVeld2Speler2;
        private System.Windows.Forms.Label labelHandSpeler2;
        private System.Windows.Forms.Label labelKaartenKerkhof2;
        private System.Windows.Forms.Label labelKerkhofSpeler2;
        private System.Windows.Forms.Label labelDeckSpeler2;
        private System.Windows.Forms.Label labelDeckKaarten1;
        private System.Windows.Forms.Label labelDeckSpeler1;
        private System.Windows.Forms.Label labelDeckKaarten2;
        private System.Windows.Forms.Label labelHPSpeler2;
        private System.Windows.Forms.Label labelHPSpeler1;
    }
}

