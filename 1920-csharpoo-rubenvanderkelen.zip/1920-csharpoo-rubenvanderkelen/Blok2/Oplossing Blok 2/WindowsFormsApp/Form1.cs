﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Globals;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        private readonly IDataAccess dataAccess;
        private readonly ISpel spel;
        //private ISpeler<Speler, Deck> _speler;
        
        public Form1(IDataAccess dataAccess, ISpel spel)
        {
            InitializeComponent();
            this.dataAccess = dataAccess;
            this.spel = spel;
            VulListBoxesSpelers();
            panelStart.Enabled = true;
            panelStart.BringToFront();
        }

        /*private void button1_Click(object sender, EventArgs e)
        {
            /*IKaart kaart1 = new MonsterKaart("test", 1500, 1500, Element.Aarde);
            spel.SpeelVeld1.Speler.StartDeck.VoegKaartToe(kaart1);
            button1.Text = spel.SpeelVeld1.Speler.StartDeck.Kaarten["test"].GeefKaartNaam();
            spel.SpeelVeld1.Speler.StartDeck.MaakDeck(dataAccess.GeefDeckInfo("DeckA"));
            button1.Text = spel.SpeelVeld1.Speler.StartDeck.Kaarten.Count.ToString();
        }*/

        private void labelSpeler1_Click(object sender, EventArgs e)
        {

        }

        private void VulListBoxesSpelers()
        {
            comboBoxSpeler1.Items.AddRange(dataAccess.GeefAlleSpelers().ToArray<string>());
            comboBoxSpeler2.Items.AddRange(dataAccess.GeefAlleSpelers().ToArray<string>());
            
        }

        private void ErrorMessage(string message)
        {
            labelErrorMessage.Visible = true;
            labelErrorMessage.Text = $"Error: {message}";
        }

        private void ErrorMessageUit()
        {
            labelErrorMessage.Visible = false;
            labelErrorMessage.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonStartCopy.Visible = true;
            buttonStartCopy.Enabled = true;
        }

        private void comboBoxSpeler2_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonStartCopy.Visible = true;
            buttonStartCopy.Enabled = true;
            buttonStart.Visible = true;
            buttonStart.Enabled = true;
        }

        private void buttonStartCopy_Click(object sender, EventArgs e)
        {
            //dit is een test voor de copyconstructor
            if (comboBoxSpeler1.SelectedIndex.ToString() != "-1")
            {
                ErrorMessageUit();
                GenereerObject(comboBoxSpeler1.Text);
                //spel.SpeelVeld2 = spel.SpeelVeld2.speelVeldCopyConstructur(spel.SpeelVeld1);
                ISpeelVeld test = spel.SpeelVeld1.speelVeldCopyConstructur(spel.SpeelVeld1);
                spel.SpeelVeld2 = test;
                spel.EersteBeurt();
                StelWaardenIn();
                StartSpel();

            }
            else
            {
                ErrorMessage("Speler1 moet geselecteerd zijn!");
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            if (comboBoxSpeler1.SelectedIndex.ToString() != "-1" && comboBoxSpeler2.SelectedIndex.ToString() != "-1")
            {
                ErrorMessageUit();
                GenereerObjecten(comboBoxSpeler1.Text, comboBoxSpeler2.Text);
                spel.EersteBeurt();
                StelWaardenIn();
                StartSpel();
            }
            else
            {
                ErrorMessage("Speler1 EN Speler2 moeten beiden geselecteerd zijn!");
            }
        }

        private void StartSpel()
        {
            panelStart.Enabled = false;
            panelSpel.Visible = true;
            panelSpel.Enabled = true;
            panelSpel.BringToFront();
        }

        //dit is een test voor de copyconstructor
        private void GenereerObject(string spelerEnDeck1)
        {
            string deck1 = dataAccess.GeefDeckVoorSpeler(spelerEnDeck1);
            spel.SpeelVeld1.Speler.Naam = dataAccess.GeefSpelerNaam(spelerEnDeck1);
            spel.SpeelVeld1.Speler.StartDeck.MaakDeck(dataAccess.GeefDeckInfo(deck1));
            spel.SpeelVeld1.Deck = spel.SpeelVeld1.Speler.StartDeck;
        }

        private void GenereerObjecten(string spelerEnDeck1, string spelerEnDeck2)
        {
            string deck1 = dataAccess.GeefDeckVoorSpeler(spelerEnDeck1);
            string deck2 = dataAccess.GeefDeckVoorSpeler(spelerEnDeck2);
            spel.SpeelVeld1.Speler.Naam = dataAccess.GeefSpelerNaam(spelerEnDeck1);
            spel.SpeelVeld2.Speler.Naam = dataAccess.GeefSpelerNaam(spelerEnDeck2);
            spel.SpeelVeld1.Speler.StartDeck.MaakDeck(dataAccess.GeefDeckInfo(deck1));
            spel.SpeelVeld2.Speler.StartDeck.MaakDeck(dataAccess.GeefDeckInfo(deck2));
            spel.SpeelVeld1.Deck = spel.SpeelVeld1.Speler.StartDeck;
            spel.SpeelVeld2.Deck = spel.SpeelVeld2.Speler.StartDeck;
        }

        private void StelWaardenIn()
        {
            labelNaamSpeler1.Text = spel.SpeelVeld1.Speler.Naam;
            labelNaamSpeler2.Text = spel.SpeelVeld2.Speler.Naam;
            labelHPSpeler1.Text = spel.SpeelVeld1.Speler.SpelerHp.ToString();
            labelHPSpeler2.Text = spel.SpeelVeld1.Speler.SpelerHp.ToString();
            WaardenSpeler1();
            WaardenSpeler2();           
        }

        private void WaardenSpeler1()
        {
            labelDeckKaarten1.Text = spel.SpeelVeld1.Deck.Kaarten.Count().ToString();
            labelKaartenKerkhof1.Text = spel.SpeelVeld1.Kerkhof.Kaarten.Count().ToString();
            StelKaartenIn(spel.SpeelVeld1.Hand, labelKaartenHandSpeler1);
            StelKaartenIn(spel.SpeelVeld1.MonsterVeld, labelKaartenVeld1Speler1);
            StelKaartenIn(spel.SpeelVeld1.SpreukEnTrapVeld, labelKaartenVeld2Speler1);
        }
        
        private void WaardenSpeler2()
        {
            labelDeckKaarten2.Text = spel.SpeelVeld2.Deck.Kaarten.Count().ToString();
            labelKaartenKerkhof2.Text = spel.SpeelVeld2.Kerkhof.Kaarten.Count().ToString();
            StelKaartenIn(spel.SpeelVeld2.Hand, labelKaartenHandSpeler2);
            StelKaartenIn(spel.SpeelVeld2.MonsterVeld, labelKaartenVeld1Speler2);
            StelKaartenIn(spel.SpeelVeld2.SpreukEnTrapVeld, labelKaartenVeld2Speler2);
        }

        private void StelKaartenIn(IList<IKaart> kaarten, Label label)
        {
            label.Text = "";
            if(kaarten.Count() == 0)
            {
                label.Text = "Leeg";
            }
            else
            {
                foreach (IKaart kaart in kaarten)
                {
                    label.Text += $"[ {kaart.GeefKaartNaam()} ] ";
                }
            }
        }

        private void labelSpelerNaam1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void labelKaartenKerkhof1_Click(object sender, EventArgs e)
        {

        }

        private void labelKaartenHandSpeler1_Click(object sender, EventArgs e)
        {

        }
    }
}
