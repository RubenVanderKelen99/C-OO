﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Globals;
using LogicaLaag;
using DataAccessLaag;

namespace WindowsFormsApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            IDataAccess dataAccess = new DataAccessImplementatie();

            IList<IKaart> kaarten1 = new List<IKaart>();
            IList<IKaart> kaarten2 = new List<IKaart>();
            IDeck deck1 = new Deck(kaarten1);
            IDeck deck2 = new Deck(kaarten2);
            ISpeler speler1 = new Speler();
            ISpeler speler2 = new Speler();
            ISpeelVeld speelVeld1 = new KaartSpeelVeld(speler1, deck1);
            ISpeelVeld speelVeld2 = new KaartSpeelVeld(speler2, deck2);
            ISpel spel = new KaartSpel(speelVeld1, speelVeld2);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(dataAccess, spel));
        }
    }
}
