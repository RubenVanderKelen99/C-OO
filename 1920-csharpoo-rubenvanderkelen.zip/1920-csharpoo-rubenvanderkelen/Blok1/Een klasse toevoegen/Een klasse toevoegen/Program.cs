﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Een_klasse_toevoegen
{
    class Program
    {

        private static int som(int a, int b)
        {
            int uitkomst = a + b;
            return uitkomst;
        }

        private static int verschil(int a, int b)
        {
            int uitkomst = a - b;
            return uitkomst;
        }

        private static int vermenigvuldiging(int a, int b)
        {
            int uitkomst = a * b;
            return uitkomst;
        }

        private static int deling(int a, int b)
        {
            int uitkomst = a / b;
            return uitkomst;
        }

        private static void geefUitkomst(int uitkomst)
        {
            Console.WriteLine("De uitkomst is: " + uitkomst);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Geef twee willekeurig gehele getal in: ");
            string[] getallen = Console.ReadLine().Split(' ');
            
            int getal1 = Convert.ToInt32(getallen[0]);
            int getal2 = Convert.ToInt32(getallen[1]);

            Console.WriteLine("Kies een bewerking: (1, 2, 3 of 4) \n1) som \n2) verschil \n3) vermenigvuldiging \n4) deling");
            string bewerking = Console.ReadLine();

            switch (bewerking)
            {
                case "1":
                    geefUitkomst(som(getal1, getal2));
                    break;
                case "2":
                    geefUitkomst(verschil(getal1, getal2));
                    break;
                case "3":
                    geefUitkomst(vermenigvuldiging(getal1, getal2));
                    break;
                case "4":
                    geefUitkomst(deling(getal1, getal2));
                    break;
                default:
                    Console.WriteLine("Error: verkeerde input");
                    break;

            }

            Console.ReadKey();

        }
    }
}
