﻿namespace WindowsFormsApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "1",
            "2",
            "3"}, -1);
            System.Windows.Forms.ColumnHeader opos;
            this.buttonLoginLog = new System.Windows.Forms.Button();
            this.labelnaamLogin = new System.Windows.Forms.Label();
            this.labelPassLogin = new System.Windows.Forms.Label();
            this.textBoxPassLog = new System.Windows.Forms.TextBox();
            this.textBoxNaamLog = new System.Windows.Forms.TextBox();
            this.labelNieuw = new System.Windows.Forms.Label();
            this.buttonRegistreerLog = new System.Windows.Forms.Button();
            this.labelErrorLog = new System.Windows.Forms.Label();
            this.panelLogin = new System.Windows.Forms.Panel();
            this.labelTitleLog = new System.Windows.Forms.Label();
            this.panelRegistreer = new System.Windows.Forms.Panel();
            this.buttonTerugReg = new System.Windows.Forms.Button();
            this.labelTitleReg = new System.Windows.Forms.Label();
            this.labelErrorReg = new System.Windows.Forms.Label();
            this.buttonRegistreerReg = new System.Windows.Forms.Button();
            this.textBoxNaamReg = new System.Windows.Forms.TextBox();
            this.textBoxPassReg = new System.Windows.Forms.TextBox();
            this.labelPassReg = new System.Windows.Forms.Label();
            this.labelNaamReg = new System.Windows.Forms.Label();
            this.labelTitleMain = new System.Windows.Forms.Label();
            this.panelMain = new System.Windows.Forms.Panel();
            this.buttonMainLog = new System.Windows.Forms.Button();
            this.labelMainOPOsTitle = new System.Windows.Forms.Label();
            this.buttonMainVorige = new System.Windows.Forms.Button();
            this.buttonMainVolgende = new System.Windows.Forms.Button();
            this.buttonMainDetails = new System.Windows.Forms.Button();
            this.buttonMainTvg = new System.Windows.Forms.Button();
            this.listViewOPOs = new System.Windows.Forms.ListView();
            this.naam = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.studiepunten = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.resultaat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.situering = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            opos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelLogin.SuspendLayout();
            this.panelRegistreer.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonLoginLog
            // 
            this.buttonLoginLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLoginLog.Location = new System.Drawing.Point(465, 274);
            this.buttonLoginLog.Name = "buttonLoginLog";
            this.buttonLoginLog.Size = new System.Drawing.Size(161, 36);
            this.buttonLoginLog.TabIndex = 2;
            this.buttonLoginLog.Text = "Login";
            this.buttonLoginLog.UseVisualStyleBackColor = true;
            this.buttonLoginLog.Click += new System.EventHandler(this.ButtonLoginLog_Click);
            // 
            // labelnaamLogin
            // 
            this.labelnaamLogin.AutoSize = true;
            this.labelnaamLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnaamLogin.Location = new System.Drawing.Point(327, 161);
            this.labelnaamLogin.Name = "labelnaamLogin";
            this.labelnaamLogin.Size = new System.Drawing.Size(49, 17);
            this.labelnaamLogin.TabIndex = 3;
            this.labelnaamLogin.Text = "Name:";
            // 
            // labelPassLogin
            // 
            this.labelPassLogin.AutoSize = true;
            this.labelPassLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassLogin.Location = new System.Drawing.Point(327, 210);
            this.labelPassLogin.Name = "labelPassLogin";
            this.labelPassLogin.Size = new System.Drawing.Size(73, 17);
            this.labelPassLogin.TabIndex = 4;
            this.labelPassLogin.Text = "Password:";
            this.labelPassLogin.Click += new System.EventHandler(this.LabelPass_Click);
            // 
            // textBoxPassLog
            // 
            this.textBoxPassLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPassLog.Location = new System.Drawing.Point(406, 207);
            this.textBoxPassLog.Name = "textBoxPassLog";
            this.textBoxPassLog.Size = new System.Drawing.Size(284, 23);
            this.textBoxPassLog.TabIndex = 1;
            this.textBoxPassLog.TextChanged += new System.EventHandler(this.TextBoxPass_TextChanged);
            // 
            // textBoxNaamLog
            // 
            this.textBoxNaamLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNaamLog.Location = new System.Drawing.Point(406, 158);
            this.textBoxNaamLog.Name = "textBoxNaamLog";
            this.textBoxNaamLog.Size = new System.Drawing.Size(284, 23);
            this.textBoxNaamLog.TabIndex = 0;
            // 
            // labelNieuw
            // 
            this.labelNieuw.AutoSize = true;
            this.labelNieuw.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNieuw.Location = new System.Drawing.Point(483, 340);
            this.labelNieuw.Name = "labelNieuw";
            this.labelNieuw.Size = new System.Drawing.Size(130, 17);
            this.labelNieuw.TabIndex = 7;
            this.labelNieuw.Text = "Nieuwe gebruiker? ";
            // 
            // buttonRegistreerLog
            // 
            this.buttonRegistreerLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRegistreerLog.Location = new System.Drawing.Point(465, 360);
            this.buttonRegistreerLog.Name = "buttonRegistreerLog";
            this.buttonRegistreerLog.Size = new System.Drawing.Size(161, 36);
            this.buttonRegistreerLog.TabIndex = 3;
            this.buttonRegistreerLog.Text = "Registreer";
            this.buttonRegistreerLog.UseVisualStyleBackColor = true;
            this.buttonRegistreerLog.Click += new System.EventHandler(this.ButtonRegistreerLogin_Click);
            // 
            // labelErrorLog
            // 
            this.labelErrorLog.AutoSize = true;
            this.labelErrorLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelErrorLog.ForeColor = System.Drawing.Color.Red;
            this.labelErrorLog.Location = new System.Drawing.Point(462, 233);
            this.labelErrorLog.Name = "labelErrorLog";
            this.labelErrorLog.Size = new System.Drawing.Size(44, 17);
            this.labelErrorLog.TabIndex = 9;
            this.labelErrorLog.Text = "Error ";
            this.labelErrorLog.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelErrorLog.Visible = false;
            // 
            // panelLogin
            // 
            this.panelLogin.Controls.Add(this.labelTitleLog);
            this.panelLogin.Controls.Add(this.labelErrorLog);
            this.panelLogin.Controls.Add(this.buttonRegistreerLog);
            this.panelLogin.Controls.Add(this.labelNieuw);
            this.panelLogin.Controls.Add(this.textBoxNaamLog);
            this.panelLogin.Controls.Add(this.textBoxPassLog);
            this.panelLogin.Controls.Add(this.labelPassLogin);
            this.panelLogin.Controls.Add(this.labelnaamLogin);
            this.panelLogin.Controls.Add(this.buttonLoginLog);
            this.panelLogin.Location = new System.Drawing.Point(1, 0);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(1005, 600);
            this.panelLogin.TabIndex = 10;
            // 
            // labelTitleLog
            // 
            this.labelTitleLog.AutoSize = true;
            this.labelTitleLog.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleLog.Location = new System.Drawing.Point(11, 9);
            this.labelTitleLog.Name = "labelTitleLog";
            this.labelTitleLog.Size = new System.Drawing.Size(63, 24);
            this.labelTitleLog.TabIndex = 10;
            this.labelTitleLog.Text = "Login";
            this.labelTitleLog.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // panelRegistreer
            // 
            this.panelRegistreer.Controls.Add(this.buttonTerugReg);
            this.panelRegistreer.Controls.Add(this.labelTitleReg);
            this.panelRegistreer.Controls.Add(this.labelErrorReg);
            this.panelRegistreer.Controls.Add(this.buttonRegistreerReg);
            this.panelRegistreer.Controls.Add(this.textBoxNaamReg);
            this.panelRegistreer.Controls.Add(this.textBoxPassReg);
            this.panelRegistreer.Controls.Add(this.labelPassReg);
            this.panelRegistreer.Controls.Add(this.labelNaamReg);
            this.panelRegistreer.Enabled = false;
            this.panelRegistreer.Location = new System.Drawing.Point(1, 0);
            this.panelRegistreer.Name = "panelRegistreer";
            this.panelRegistreer.Size = new System.Drawing.Size(1005, 600);
            this.panelRegistreer.TabIndex = 11;
            // 
            // buttonTerugReg
            // 
            this.buttonTerugReg.Location = new System.Drawing.Point(832, 7);
            this.buttonTerugReg.Name = "buttonTerugReg";
            this.buttonTerugReg.Size = new System.Drawing.Size(161, 36);
            this.buttonTerugReg.TabIndex = 12;
            this.buttonTerugReg.Text = "< Terug";
            this.buttonTerugReg.UseVisualStyleBackColor = true;
            this.buttonTerugReg.Click += new System.EventHandler(this.ButtonTerugReg_Click);
            // 
            // labelTitleReg
            // 
            this.labelTitleReg.AutoSize = true;
            this.labelTitleReg.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleReg.Location = new System.Drawing.Point(11, 11);
            this.labelTitleReg.Name = "labelTitleReg";
            this.labelTitleReg.Size = new System.Drawing.Size(108, 24);
            this.labelTitleReg.TabIndex = 11;
            this.labelTitleReg.Text = "Registreer";
            this.labelTitleReg.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // labelErrorReg
            // 
            this.labelErrorReg.AutoSize = true;
            this.labelErrorReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelErrorReg.ForeColor = System.Drawing.Color.Red;
            this.labelErrorReg.Location = new System.Drawing.Point(462, 233);
            this.labelErrorReg.Name = "labelErrorReg";
            this.labelErrorReg.Size = new System.Drawing.Size(44, 17);
            this.labelErrorReg.TabIndex = 9;
            this.labelErrorReg.Text = "Error ";
            this.labelErrorReg.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelErrorReg.Visible = false;
            // 
            // buttonRegistreerReg
            // 
            this.buttonRegistreerReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRegistreerReg.Location = new System.Drawing.Point(465, 276);
            this.buttonRegistreerReg.Name = "buttonRegistreerReg";
            this.buttonRegistreerReg.Size = new System.Drawing.Size(161, 36);
            this.buttonRegistreerReg.TabIndex = 2;
            this.buttonRegistreerReg.Text = "Registreer";
            this.buttonRegistreerReg.UseVisualStyleBackColor = true;
            this.buttonRegistreerReg.Click += new System.EventHandler(this.ButtonRegistreerReg_Click);
            // 
            // textBoxNaamReg
            // 
            this.textBoxNaamReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNaamReg.Location = new System.Drawing.Point(406, 158);
            this.textBoxNaamReg.Name = "textBoxNaamReg";
            this.textBoxNaamReg.Size = new System.Drawing.Size(284, 23);
            this.textBoxNaamReg.TabIndex = 0;
            // 
            // textBoxPassReg
            // 
            this.textBoxPassReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPassReg.Location = new System.Drawing.Point(406, 207);
            this.textBoxPassReg.Name = "textBoxPassReg";
            this.textBoxPassReg.Size = new System.Drawing.Size(284, 23);
            this.textBoxPassReg.TabIndex = 1;
            // 
            // labelPassReg
            // 
            this.labelPassReg.AutoSize = true;
            this.labelPassReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassReg.Location = new System.Drawing.Point(327, 210);
            this.labelPassReg.Name = "labelPassReg";
            this.labelPassReg.Size = new System.Drawing.Size(73, 17);
            this.labelPassReg.TabIndex = 4;
            this.labelPassReg.Text = "Password:";
            // 
            // labelNaamReg
            // 
            this.labelNaamReg.AutoSize = true;
            this.labelNaamReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNaamReg.Location = new System.Drawing.Point(327, 161);
            this.labelNaamReg.Name = "labelNaamReg";
            this.labelNaamReg.Size = new System.Drawing.Size(49, 17);
            this.labelNaamReg.TabIndex = 3;
            this.labelNaamReg.Text = "Name:";
            // 
            // labelTitleMain
            // 
            this.labelTitleMain.AutoSize = true;
            this.labelTitleMain.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitleMain.Location = new System.Drawing.Point(11, 9);
            this.labelTitleMain.Name = "labelTitleMain";
            this.labelTitleMain.Size = new System.Drawing.Size(85, 24);
            this.labelTitleMain.TabIndex = 10;
            this.labelTitleMain.Text = "Welkom";
            this.labelTitleMain.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.listViewOPOs);
            this.panelMain.Controls.Add(this.buttonMainTvg);
            this.panelMain.Controls.Add(this.buttonMainDetails);
            this.panelMain.Controls.Add(this.buttonMainVolgende);
            this.panelMain.Controls.Add(this.buttonMainVorige);
            this.panelMain.Controls.Add(this.buttonMainLog);
            this.panelMain.Controls.Add(this.labelMainOPOsTitle);
            this.panelMain.Controls.Add(this.labelTitleMain);
            this.panelMain.Enabled = false;
            this.panelMain.Location = new System.Drawing.Point(1, 606);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1005, 600);
            this.panelMain.TabIndex = 12;
            // 
            // buttonMainLog
            // 
            this.buttonMainLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainLog.Location = new System.Drawing.Point(821, 9);
            this.buttonMainLog.Name = "buttonMainLog";
            this.buttonMainLog.Size = new System.Drawing.Size(161, 36);
            this.buttonMainLog.TabIndex = 14;
            this.buttonMainLog.Text = "Uitloggen";
            this.buttonMainLog.UseVisualStyleBackColor = true;
            this.buttonMainLog.Click += new System.EventHandler(this.buttonMainLog_Click);
            // 
            // labelMainOPOsTitle
            // 
            this.labelMainOPOsTitle.AutoSize = true;
            this.labelMainOPOsTitle.Location = new System.Drawing.Point(12, 54);
            this.labelMainOPOsTitle.Name = "labelMainOPOsTitle";
            this.labelMainOPOsTitle.Size = new System.Drawing.Size(137, 17);
            this.labelMainOPOsTitle.TabIndex = 12;
            this.labelMainOPOsTitle.Text = "Overzicht van OPOs";
            // 
            // buttonMainVorige
            // 
            this.buttonMainVorige.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainVorige.Location = new System.Drawing.Point(841, 102);
            this.buttonMainVorige.Name = "buttonMainVorige";
            this.buttonMainVorige.Size = new System.Drawing.Size(108, 27);
            this.buttonMainVorige.TabIndex = 15;
            this.buttonMainVorige.Text = "Vorige";
            this.buttonMainVorige.UseVisualStyleBackColor = true;
            // 
            // buttonMainVolgende
            // 
            this.buttonMainVolgende.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainVolgende.Location = new System.Drawing.Point(841, 149);
            this.buttonMainVolgende.Name = "buttonMainVolgende";
            this.buttonMainVolgende.Size = new System.Drawing.Size(108, 27);
            this.buttonMainVolgende.TabIndex = 16;
            this.buttonMainVolgende.Text = "Volgende";
            this.buttonMainVolgende.UseVisualStyleBackColor = true;
            // 
            // buttonMainDetails
            // 
            this.buttonMainDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainDetails.Location = new System.Drawing.Point(841, 196);
            this.buttonMainDetails.Name = "buttonMainDetails";
            this.buttonMainDetails.Size = new System.Drawing.Size(108, 27);
            this.buttonMainDetails.TabIndex = 17;
            this.buttonMainDetails.Text = "Details";
            this.buttonMainDetails.UseVisualStyleBackColor = true;
            // 
            // buttonMainTvg
            // 
            this.buttonMainTvg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMainTvg.Location = new System.Drawing.Point(841, 242);
            this.buttonMainTvg.Name = "buttonMainTvg";
            this.buttonMainTvg.Size = new System.Drawing.Size(108, 27);
            this.buttonMainTvg.TabIndex = 18;
            this.buttonMainTvg.Text = "Toevoegen";
            this.buttonMainTvg.UseVisualStyleBackColor = true;
            // 
            // listViewOPOs
            // 
            this.listViewOPOs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            opos,
            this.naam,
            this.studiepunten,
            this.resultaat,
            this.situering,
            this.status});
            this.listViewOPOs.FullRowSelect = true;
            this.listViewOPOs.GridLines = true;
            this.listViewOPOs.HideSelection = false;
            this.listViewOPOs.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.listViewOPOs.Location = new System.Drawing.Point(19, 80);
            this.listViewOPOs.Name = "listViewOPOs";
            this.listViewOPOs.Size = new System.Drawing.Size(780, 265);
            this.listViewOPOs.TabIndex = 19;
            this.listViewOPOs.UseCompatibleStateImageBehavior = false;
            this.listViewOPOs.View = System.Windows.Forms.View.Details;
            this.listViewOPOs.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // opos
            // 
            opos.Text = "Opos";
            opos.Width = 0;
            // 
            // naam
            // 
            this.naam.Text = "Naam";
            this.naam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.naam.Width = 155;
            // 
            // studiepunten
            // 
            this.studiepunten.Text = "Studiepunten";
            this.studiepunten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.studiepunten.Width = 155;
            // 
            // resultaat
            // 
            this.resultaat.Text = "Resultaat";
            this.resultaat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.resultaat.Width = 155;
            // 
            // situering
            // 
            this.situering.Text = "Situering";
            this.situering.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.situering.Width = 155;
            // 
            // status
            // 
            this.status.Text = "Status";
            this.status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.status.Width = 155;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 1055);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelLogin);
            this.Controls.Add(this.panelRegistreer);
            this.Name = "Form1";
            this.Text = "Student Database";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelLogin.ResumeLayout(false);
            this.panelLogin.PerformLayout();
            this.panelRegistreer.ResumeLayout(false);
            this.panelRegistreer.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonLoginLog;
        private System.Windows.Forms.Label labelnaamLogin;
        private System.Windows.Forms.Label labelPassLogin;
        private System.Windows.Forms.TextBox textBoxPassLog;
        private System.Windows.Forms.TextBox textBoxNaamLog;
        private System.Windows.Forms.Label labelNieuw;
        private System.Windows.Forms.Button buttonRegistreerLog;
        private System.Windows.Forms.Label labelErrorLog;
        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.Panel panelRegistreer;
        private System.Windows.Forms.Label labelErrorReg;
        private System.Windows.Forms.Button buttonRegistreerReg;
        private System.Windows.Forms.TextBox textBoxNaamReg;
        private System.Windows.Forms.TextBox textBoxPassReg;
        private System.Windows.Forms.Label labelPassReg;
        private System.Windows.Forms.Label labelNaamReg;
        private System.Windows.Forms.Label labelTitleLog;
        private System.Windows.Forms.Label labelTitleReg;
        private System.Windows.Forms.Button buttonTerugReg;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Label labelTitleMain;
        private System.Windows.Forms.Label labelMainOPOsTitle;
        private System.Windows.Forms.Button buttonMainLog;
        private System.Windows.Forms.Button buttonMainVolgende;
        private System.Windows.Forms.Button buttonMainVorige;
        private System.Windows.Forms.Button buttonMainTvg;
        private System.Windows.Forms.Button buttonMainDetails;
        private System.Windows.Forms.ListView listViewOPOs;
        private System.Windows.Forms.ColumnHeader naam;
        private System.Windows.Forms.ColumnHeader studiepunten;
        private System.Windows.Forms.ColumnHeader resultaat;
        private System.Windows.Forms.ColumnHeader situering;
        private System.Windows.Forms.ColumnHeader status;
    }
}

