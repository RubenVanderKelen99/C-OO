﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp.Logica
{
    public class OLA
    {
        private int resultaat;
        public OLA(string naam, int maximumPunten)
        {
            if (string.IsNullOrWhiteSpace(naam)) throw new ArgumentNullException();
            this.Naam = naam;
            this.MaximumPunten = maximumPunten;
        }

        public String Naam { get; }

        public int MaximumPunten { get; }

        public int Resultaat
        {
            get
            {
                return resultaat;
            }
            set
            {
                if (resultaat <= MaximumPunten) throw new ArgumentException();
                resultaat = value;
            }
        }

    }
}
