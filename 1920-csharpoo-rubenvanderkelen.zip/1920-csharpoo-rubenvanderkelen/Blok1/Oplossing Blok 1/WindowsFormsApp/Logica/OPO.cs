﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp.Logica
{
    public enum Situering
    {
        A,
        B,
        C,
        D,
        NA
    }

    public enum Status
    {
        Opgenomen,
        Geslaagd,
        Tekort,
        Uitgeschreven
    }
    public class OPO
    {
        private int resultaat;
        private Situering situering;
        private Status status;
        private List<OLA> olas;

        public OPO(string naam, int studiepunten, int maximumPunten)
        {
            if (string.IsNullOrWhiteSpace(naam)) throw new ArgumentNullException();
            this.Naam = naam;
            this.Studiepunten = studiepunten;
            this.MaximumPunten = maximumPunten;
            this.situering = Logica.Situering.NA;
            this.status = Logica.Status.Opgenomen;

        }

        public String Naam { get; }

        public int Studiepunten { get; }

        public int MaximumPunten { get; }

        public int Resultaat
        {
            get
            {
                return resultaat;
            }
            set
            {
                if (resultaat <= MaximumPunten) throw new ArgumentException();
                resultaat = value;
            }
        }

        public String Situering
        {
            get
            {
                return situering.ToString();
            }
            set
            {
                situering = GetSitueringen(value);
            }
        }

        private Situering GetSitueringen(String situering)
        {
            if (situering == "A" || situering == "B" || situering == "C" || situering == "D")
            {
                switch (situering)
                {
                    case "A":
                        return Logica.Situering.A;
                    //break;
                    case "B":
                        return Logica.Situering.B;
                    //break;
                    case "C":
                        return Logica.Situering.C;
                    //break;
                    case "D":
                        return Logica.Situering.D;
                    //break;
                    default:
                        return Logica.Situering.NA;
                        //break;
                }
            }
            else throw new ArgumentException();
        }

        public String Status
        {
            get
            {
                return status.ToString();
            }
            set
            {
                status = GetStatusen(value);
            }
        }

        private Status GetStatusen(String status)
        {
            if (status == "Opgenomen" || status == "Geslaagd" || status == "Tekort" || status == "Uitgeschreven")
            {
                switch (status)
                {
                    case "Opgenomen":
                        return Logica.Status.Opgenomen;
                    //break;
                    case "Geslaagd":
                        return Logica.Status.Geslaagd;
                    //break;
                    case "Tekort":
                        return Logica.Status.Tekort;
                    //break;
                    case "Uitgeschreven":
                        return Logica.Status.Uitgeschreven;
                    //break;
                    default:
                        return Logica.Status.Opgenomen;
                        //break;
                }
            }
            else throw new ArgumentException();
        }


        public List<OLA> OLAs
        {
            get
            {
                return olas;
            }
            set
            {
                if (!(value.GetType().IsGenericType) || !(value is IList<OLA>)) throw new ArgumentException();
                olas = value;
            }
        }
    }
}
