﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WindowsFormsApp.Logica
{
    public class FetchDataPath
    {
        private string _projectDirectory = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;

        public string ProjectDirectory
        {
            get
            {
                return _projectDirectory;
            }
            private set
            {
                _projectDirectory = value;
            }
        }
        public FetchDataPath(String fileName)
        {
            String filePath = _projectDirectory + @"\Data\" + fileName;
            //if (!Directory.Exists(filePath)) throw new DirectoryNotFoundException("Fout bij het ophalen van de data");
            ProjectDirectory = filePath;
        }

    }
}
