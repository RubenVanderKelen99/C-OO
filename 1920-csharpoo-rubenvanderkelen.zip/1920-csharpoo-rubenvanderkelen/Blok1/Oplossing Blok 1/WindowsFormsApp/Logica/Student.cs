﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp.Logica
{
    interface IWriteable
    {
        string WriteDetails();
        void RewriteDetails();
    }

    //bij inloggen kijken of student al bestaat via IComparable
    //beter: via overwrite compareTo
    interface IComparable
    {

    }

    public class Student : IWriteable
    {
        private string organisatie;
        private string klas;
        private string studentenNummer;
        private int jaar;
        private List<OPO> opos;

        public Student()
        {

        }

        public Student(string naam, string wachtwoord)
        {
            if (string.IsNullOrWhiteSpace(naam)) throw new ArgumentNullException("Naam");
            if (string.IsNullOrWhiteSpace(wachtwoord)) throw new ArgumentNullException("Wachtwoord");
            this.Naam = naam;
            this.Wachtwoord = wachtwoord;
            this.Jaar = 2019;
        }

        public Student(Student bestaandeStudent, int jaar)
        {
            this.Naam = bestaandeStudent.Naam;
            this.Wachtwoord = bestaandeStudent.Wachtwoord;
            this.Jaar = jaar;
        }

        public string WriteDetails()
        {
            string output = $"Naam: {Naam}";
            if (!(string.IsNullOrWhiteSpace(organisatie)))
            {
                output += $" Organisatie: {organisatie}";
            }
            if (!(string.IsNullOrWhiteSpace(klas)))
            {
                output += $" Organisatie: {klas}";
            }
            if (!(string.IsNullOrWhiteSpace(studentenNummer)))
            {
                output += $" Organisatie: {studentenNummer}";
            }
            return output;
        }

        public void RewriteDetails()
        {
            throw new NotImplementedException();
        }

        public String Naam { get; }

        public String Wachtwoord { get; private set; }

        public int Jaar { get; set; }

        public String Organisatie
        {
            get
            {
                return organisatie;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value)) throw new ArgumentNullException();
                organisatie = value;

            }
        }

        public String Klas
        {
            get
            {
                return klas;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value)) throw new ArgumentNullException();
                klas = value;
            }

        }

        public String StudentenNummer
        {
            get
            {
                return studentenNummer;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value)) throw new ArgumentNullException();
                studentenNummer = value;
            }

        }

        public List<OPO> OPOs
        {
            get
            {
                return opos;
            }
            set
            {
                if (!(value.GetType().IsGenericType) || !(value is IList<OPO>)) throw new ArgumentException();
                opos = value;
            }
        }



    }
}
