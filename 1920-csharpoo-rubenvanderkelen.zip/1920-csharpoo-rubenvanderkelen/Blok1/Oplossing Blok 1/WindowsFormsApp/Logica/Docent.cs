﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp.Logica
{
    public class Docent : Student
    {
        private string _docentNaam;

        public String DocentNaam
        {
            get
            {
                return _docentNaam;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value)) throw new ArgumentNullException();
                if (value == this.Naam) throw new ArgumentException("Naam van student en docent gelijk");
                _docentNaam = value;
            }
        }
    }
}
