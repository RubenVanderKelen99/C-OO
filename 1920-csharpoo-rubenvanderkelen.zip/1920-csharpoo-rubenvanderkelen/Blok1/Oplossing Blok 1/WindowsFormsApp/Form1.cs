﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp.Logica;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        public Student actieveGebruiker = new Student();
        public Form1()
        {
            InitializeComponent();
            textBoxPassLog.PasswordChar = '*';
            textBoxPassReg.PasswordChar = '*';
            panelLogin.Enabled = true;
            panelLogin.BringToFront();
        }
        
        //maak correct studentobject aan: nakijken in txtfile of deze bestaat: zo heb ik ook list opos en daarin de list ola's
        private void ButtonLoginLog_Click(object sender, EventArgs e)
        {
            string naam = textBoxNaamLog.Text;
            string wachtwoord = textBoxPassLog.Text;
            if (CheckNaamEnPass(naam, wachtwoord))
            {
                labelErrorLog.Visible = false;
                try
                {
                    Student gebruiker = new Student(naam, wachtwoord);
                    EmptyUserTextBoxes();
                    StartSession(gebruiker);
                }
                catch (Exception ex)
                {
                    labelErrorLog.Visible = true;
                    labelErrorLog.Text = $"Error: {ex.Message} ";
                }
                finally
                {
                    EmptyUserTextBoxes();
                }
            }
            else
            {
                labelErrorLog.Visible = true;
                labelErrorLog.Text = "Onjuiste gebruikersgegevens";
                textBoxPassLog.Text = "";
            }
        }

        private bool CheckNaamEnPass(string naam, string wachtwoord)
        {
            try
            {
                FetchDataPath studentPath = new FetchDataPath("Student.txt");
                string path = studentPath.ProjectDirectory;
                return StudentExists(naam, wachtwoord, path);
            }
            catch (Exception e)
            {
                labelErrorLog.Visible = true;
                labelErrorLog.Text = e.Message;
                return false;
            }
        }

        private bool StudentExists(string naam, string wachtwoord, string path)
        {
            StreamReader sr = new StreamReader(path);
            string lijn = "";
            //while (!(String.IsNullOrEmpty(sr.ReadLine())))
            while ((lijn = sr.ReadLine()) != null)
            {
                string[] woorden = lijn.Split('*');
                if (woorden[0] == naam)
                {
                    if (woorden[1] == wachtwoord)
                    {
                        sr.Close();
                        return true;
                    }
                }
            }
            sr.Close();
            return false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ButtonRegistreerLogin_Click(object sender, EventArgs e)
        {
            EmptyUserTextBoxes();
            panelLogin.Enabled = false;
            panelRegistreer.Enabled = true;
            panelRegistreer.BringToFront();
        }

        private void TextBoxPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void LabelPass_Click(object sender, EventArgs e)
        {

        }

        private void ButtonRegistreerReg_Click(object sender, EventArgs e)
        {
            string naam = textBoxNaamReg.Text;
            string wachtwoord = textBoxPassReg.Text;
            labelErrorReg.Visible = false;
            if (!CheckNaamEnPass(naam, wachtwoord))
            {
                try
                {
                    Student nieuweGebruiker = new Student(naam, wachtwoord);
                    EmptyUserTextBoxes();
                    GenerateUserFiles(nieuweGebruiker);
                    SaveUser(nieuweGebruiker);
                    StartSession(nieuweGebruiker);
                }
                catch (Exception ex)
                {
                    labelErrorReg.Visible = true;
                    labelErrorReg.Text = $"Error: {ex.Message} ";
                }
                finally
                {
                    EmptyUserTextBoxes();
                }
            }
            else
            {
                labelErrorReg.Visible = true;
                labelErrorReg.Text = "Error: die gebruiker bestaat al";
            }
        }

        private void ButtonTerugReg_Click(object sender, EventArgs e)
        {
            EmptyUserTextBoxes();
            panelRegistreer.Enabled = false;
            panelLogin.Enabled = true;
            panelLogin.BringToFront();
        }

        private void SaveUser(Student gebruiker)
        {
            FetchDataPath studentPath = new FetchDataPath("Student.txt");
            string path = studentPath.ProjectDirectory;
            StreamWriter sw = new StreamWriter(path, append:true);
            sw.WriteLine($"{gebruiker.Naam}*{gebruiker.Wachtwoord}");
            sw.Close();
        }

        private void GenerateUserFiles(Student gebruiker)
        {
            FetchDataPath studentFilesPath = new FetchDataPath("Studenten");
            string path = System.IO.Path.Combine(studentFilesPath.ProjectDirectory, gebruiker.Naam);
            StreamWriter userFile = new StreamWriter($"{path}.txt");
            userFile.WriteLine("");
            userFile.Close();
            /*StreamWriter sw = File.CreateText($@"{studentFilesPath.ProjectDirectory}\{gebruiker.Naam}");
            sw.WriteLine("test");
            sw.Close();*/
        }

        private void EmptyUserTextBoxes()
        {
            textBoxNaamLog.Text = "";
            textBoxPassLog.Text = "";
            textBoxNaamReg.Text = "";
            textBoxPassReg.Text = "";
        }

        //TODO set tab controls voor main
        private void StartSession(Student gebruiker)
        {
            panelLogin.Enabled = false;
            panelRegistreer.Enabled = false;
            panelMain.Enabled = true;
            panelMain.BringToFront();
            this.actieveGebruiker = gebruiker;
            labelTitleMain.Text = $"Welkom {actieveGebruiker.Naam}";
            FetchDataPath OPOFilesPath = new FetchDataPath("Studenten");
            string path = System.IO.Path.Combine(OPOFilesPath.ProjectDirectory, actieveGebruiker.Naam);
            using (BinaryReader reader = new BinaryReader(File.OpenRead(path)))
            {
                //C#00*3*20*16*B*Geslaagd
                while (reader.PeekChar() != null)
                {

                }
                reader.ReadString();
                reader.ReadInt32();
                reader.ReadInt32();
            }
            /*for(int i = 0; i <= 1; i++)
            {
                ListViewItem rij = new ListViewItem();
                rij.SubItems.Add(gebruiker.Naam);
                rij.SubItems.Add(gebruiker.Wachtwoord);
                listViewOPOs.Items.Add(rij);
            }*/
        }

        private void EndSession()
        {
            panelMain.Enabled = false;
            panelLogin.Enabled = true;
            panelLogin.BringToFront();
            this.actieveGebruiker = new Student();
        }

        private void buttonMainLog_Click(object sender, EventArgs e)
        {
            EndSession();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
