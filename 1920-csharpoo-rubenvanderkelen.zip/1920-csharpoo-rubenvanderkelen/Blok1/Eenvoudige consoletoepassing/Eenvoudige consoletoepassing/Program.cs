﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eenvoudige_consoletoepassing
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            Console.Write("Geef een woord/zin: ");
            input = Console.ReadLine();
            Console.WriteLine("Hier is je woord/zin: " + input);
            Console.ReadKey();
        }
    }
}
