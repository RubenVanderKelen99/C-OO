﻿using System.Threading;

namespace AsyncDemo
{
    public class Worker
    {
        public int CalculateTheAnswer()
        {
            Thread.Sleep(3000);
            return 42;
        }
    }
}
