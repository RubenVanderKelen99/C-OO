﻿using System;
using System.Windows.Forms;

namespace AsyncDemo
{
    public partial class MainForm : Form
    {
        private readonly Worker worker;
        public MainForm()
        {
            InitializeComponent();
            worker = new Worker();
        }

        private void OnStartButtonClick(object sender, EventArgs e)
        {
            startButton.Enabled = false;
            resultTextBox.Text = string.Empty;
            int result = worker.CalculateTheAnswer();
            resultTextBox.Text = $"{result}";
            startButton.Enabled = true;
        }
    }
}
