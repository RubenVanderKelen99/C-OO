﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncDemo
{
    public class Worker
    {

        public event Action<int> ResultCalculated;
        public void CalculateTheAnswer()
        {
            var job = Task<int>.Run(() => { return CalculateIt(); });
            job.ContinueWith((j) => { ResultCalculated?.Invoke(j.Result); },
                            TaskScheduler.FromCurrentSynchronizationContext());
        }

        private int CalculateIt()
        {
            Thread.Sleep(3000);
            return 42;
        }


    }
}
