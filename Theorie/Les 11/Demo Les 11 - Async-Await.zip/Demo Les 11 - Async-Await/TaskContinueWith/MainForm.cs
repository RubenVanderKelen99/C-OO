﻿using System;
using System.Windows.Forms;

namespace AsyncDemo
{
    public partial class MainForm : Form
    {
        private readonly Worker worker;
        public MainForm()
        {
            InitializeComponent();
            worker = new Worker();
            worker.ResultCalculated += OnWorkerResultCalculated;
        }

        private void OnWorkerResultCalculated(int result)
        {
            resultTextBox.Text = $"{result}";
            startButton.Enabled = true;
        }

        private void OnStartButtonClick(object sender, EventArgs e)
        {
            resultTextBox.Text = string.Empty;
            startButton.Enabled = false;
            worker.CalculateTheAnswer();
        }
    }
}
