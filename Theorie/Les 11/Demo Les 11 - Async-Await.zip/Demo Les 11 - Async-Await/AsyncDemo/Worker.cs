﻿using System.Threading;
using System.Threading.Tasks;

namespace AsyncDemo
{
    public class Worker
    {
        public async Task<int> CalculateTheAnswerAsync()
        {
            return await Task<int>.Run(() => { return CalculateIt(); }).ConfigureAwait(false);

            // alternative: allow await to return on another thread context 
            // (may cause problems with Ui operations that have thread affinity.
            //
            // return await Task<int>.Run(() => { return CalculateIt(); }).ConfigureAwait(false);;

        }

        private int CalculateIt()
        {
            Thread.Sleep(1000);
            return 42;
        }

        public async Task<int> DoSomethingAsync()
        {
            await Task.Delay(1000);
            return 2 * 42;
        }

    }

}
