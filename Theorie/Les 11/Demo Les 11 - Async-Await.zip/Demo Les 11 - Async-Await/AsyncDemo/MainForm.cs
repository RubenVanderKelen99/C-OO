﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncDemo
{
    public partial class MainForm : Form
    {
        private readonly Worker worker;
        public MainForm()
        {
            InitializeComponent();
            worker = new Worker();

            #region async Lambda

            this.lambdaButton.Click += async (sender,args) =>
            {
                var job = worker.DoSomethingAsync();
                resultTextBox.Text = "waiting";
                SetButtonState(false);
                resultTextBox.Text = $"{await job}";                

                SetButtonState(true);
            };

            #endregion async Lambda
        }

        private async void OnStartButtonClick(object sender, EventArgs e)
        {
            resultTextBox.Text = string.Empty;
            SetButtonState(false);
            int result1 = await worker.CalculateTheAnswerAsync();
            int result2 = await worker.DoSomethingAsync();


            #region important remark

            // warning: Bad code!
            //
            // int x = worker.CalculateTheAnswerAsync().Result;
            //
            // that next line would cause a deadlock because 'Result' blocks
            // the calling thread while the async method in 'CalculateTheAnswer'
            // tries to continue on the calling thread after 'await'
            //
            // solution:
            // extend the 'await' statement with '.ConfigureAwait(false);'
            //

            #endregion

            resultTextBox.Text = $"{result1}, {result2}";
            SetButtonState(true);
        }
              
        private void SetButtonState(bool enabled)
        {
            startButton.Enabled = enabled;
            lambdaButton.Enabled = enabled;
        }
    }
}
