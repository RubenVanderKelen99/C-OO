﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace AsyncDemo
{
    public partial class MainForm : Form
    {
        private readonly SynchronizationContext context;
        private readonly Worker worker;
        public MainForm()
        {
            InitializeComponent();
            context = SynchronizationContext.Current;
            worker = new Worker();
            worker.ResultCalculated += OnWorkerResultCalculated;
        }

        private void OnWorkerResultCalculated(int result)
        {
            context.Post((r) =>
            {
                resultTextBox.Text = $"{r}";
                startButton.Enabled = true;
            }, result);
        }

        private void StartButtonClick(object sender, EventArgs e)
        {
            resultTextBox.Text = string.Empty;
            startButton.Enabled = false;
            worker.CalculateTheAnswer();
        }
    }
}
