﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncDemo
{
    public class Worker
    {
        public event Action<int> ResultCalculated;
        public void CalculateTheAnswer()
        {
            Task.Run(() => CalculateIt());
        }

        private void CalculateIt()
        {
            Thread.Sleep(3000);
            ResultCalculated?.Invoke(42);
        }
    }
}
