﻿using System;
using System.Threading;

namespace SimpleEventDemo
{
    public class Counter : ICounter
    {
        public event Action<int> CountChanged;
        public event Action CountFinished;

        public void Count()
        {
            for (int i = 0; i < 10; i++)
            {
                CountChanged?.Invoke(i);
                Thread.Sleep(500);
            }
            CountFinished?.Invoke();
        }
    }
}
