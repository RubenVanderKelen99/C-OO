﻿using System;
using System.Windows.Forms;

namespace SimpleEventDemo
{
    public partial class MainForm : Form
    {
        private readonly ICounter counter;

        public MainForm(ICounter counter)
        {
            InitializeComponent();
            this.counter = counter;
            counter.CountChanged += OnCounterCountChanged;
            counter.CountFinished += OnCounterCountFinished;
        }

        private void OnCounterCountFinished()
        {
            countTextBox.Text = string.Empty;
            startButton.Enabled = true;
        }

        private void OnCounterCountChanged(int count)
        {
            countTextBox.Text = $"{count}";
            countTextBox.Refresh();
        }

        private void StartButtonClick(object sender, EventArgs e)
        {
            startButton.Enabled = false;
            counter.Count();
        }
    }
}
