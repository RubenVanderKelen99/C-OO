﻿using System;

namespace SimpleEventDemo
{
    public interface ICounter
    {
        event Action<int> CountChanged;
        event Action CountFinished;

        void Count();
    }
}