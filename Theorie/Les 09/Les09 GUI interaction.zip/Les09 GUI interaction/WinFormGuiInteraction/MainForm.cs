﻿using BackendDemo;
using System;
using System.Threading;
using System.Windows.Forms;

namespace WinFormGuiInteraction
{
    public partial class MainForm : Form
    {
        private readonly IBackendWorker worker;
        private readonly SynchronizationContext uiContext;
        public MainForm(IBackendWorker worker)
        {
            InitializeComponent();
            this.worker = worker;
            uiContext = SynchronizationContext.Current;
            worker.BackendEvent += OnWorkerBackEvent;
            SetRunningState(false);
        }


        private void SetRunningState(bool running)
        {
            stopButton.Enabled = running;
            startButton.Enabled = !running;
        }

        private void OnStartButtonClick(object sender, EventArgs e)
        {
            SetRunningState(true);
            worker.Start();
        }

        private void OnStopButtonClick(object sender, EventArgs e)
        {
            worker.Stop();
            SetRunningState(false);
        }

        private void OnWorkerBackEvent(int count)
        {
            // The following statement would cause an InvalidOperationException 
            // because of cross-thread operation on winforms control
            //
            // outputTextBox.Text = count.ToString();

            // Instead schedule the action on the UI synchronisation context.
             uiContext.Post((c) => outputTextBox.Text = count.ToString(), null);

            // which is equivallent to the following:            //
            // uiContext.Post((c) => outputTextBox.Text = c.ToString(), count);

        }

        private void OnMainFormClosing(object sender, FormClosingEventArgs e)
        {
            // Make sure backend does not call eventhandler on this form after it has been closed
            worker.BackendEvent -= OnWorkerBackEvent;
            // and stop the backend worker (just in case the user didn't stop it)
            worker.Stop();
        }
    }
}
