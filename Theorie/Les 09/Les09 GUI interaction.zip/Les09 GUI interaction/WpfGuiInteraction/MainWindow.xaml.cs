﻿using BackendDemo;
using System.Threading;
using System.Windows;

namespace WpfGuiInteraction
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly IBackendWorker worker;
        private readonly SynchronizationContext uiContext;

        public MainWindow(IBackendWorker worker)
        {
            this.worker = worker;
            InitializeComponent();
            uiContext = SynchronizationContext.Current;
            worker.BackendEvent += OnWorkerBackEvent;
            SetRunningState(false);
        }

        private void SetRunningState(bool running)
        {
            stopButton.IsEnabled = running;
            startButton.IsEnabled = !running;
        }


        private void OnStartClick(object sender, RoutedEventArgs e)
        {
            SetRunningState(true);
            worker.Start();
        }

        private void OnStopClick(object sender, RoutedEventArgs e)
        {
            worker.Stop();
            SetRunningState(false);
        }

        private void OnWorkerBackEvent(int count)
        {
            // The following statement would cause an InvalidOperationException 
            // because of cross-thread operation on winforms control
            //
            // outputTextBox.Text = count.ToString();

            // Instead schedule the action on the UI synchronisation context.
            uiContext.Post((c) => outputTextBox.Text = count.ToString(), null);

            // which is equivallent to the following:            //
            // uiContext.Post((c) => outputTextBox.Text = c.ToString(), count);
        }

    }
}
