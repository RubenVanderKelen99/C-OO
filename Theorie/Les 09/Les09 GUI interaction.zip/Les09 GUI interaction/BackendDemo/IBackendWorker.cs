﻿using System;

namespace BackendDemo
{
    public interface IBackendWorker
    {
        event Action<int> BackendEvent;
        void Start();
        void Stop();

    }
}
