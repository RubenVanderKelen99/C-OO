﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace BackendDemo
{
    public class BackendWorker : IBackendWorker
    {
        private CancellationTokenSource cancellationTokenSource;

        public event Action<int> BackendEvent;

        public void Start()
        {
            // stop previously started worker task if necessary
            Stop();
            // dispose existing cancellationTokenSource if necessary
            cancellationTokenSource?.Dispose();

            cancellationTokenSource = new CancellationTokenSource();
            var cancelToken = cancellationTokenSource.Token;
            Task.Run(() => Work(cancelToken), cancelToken);

        }

        public void Stop()
        {
            cancellationTokenSource?.Cancel();
        }

        private void Work(CancellationToken cancelToken)
        {
            int count = 0;
            while (!cancelToken.IsCancellationRequested)
            {
                // simulate long-running compute intensive work
                Thread.Sleep(500);
                count++;
                BackendEvent?.Invoke(count);
            }
        }
    }
}
