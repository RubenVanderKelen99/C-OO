﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatePiDataEntities
{
    public struct PiResult
    {
        // value calculated for Pi
        public decimal Value { get; set; }

        // NrOfIterations used in calculating Pi
        public long Iterations { get; set; }
        
        // Difference with previously calculated value for Pi
        public decimal Delta { get; set; }
    }
}
