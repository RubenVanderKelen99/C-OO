﻿using Globals;
using System;
using System.Threading;
using System.Windows.Forms;

namespace CalculatePiGUI
{
    public partial class MainForm : Form
    {
        private readonly ICalculatePiLogic logic;
        private readonly SynchronizationContext uiContext;

        public MainForm(ICalculatePiLogic logic)
        {
            InitializeComponent();
            this.logic = logic;
            uiContext = SynchronizationContext.Current;
            logic.PiValue1Changed += OnLogicPiValue1ChangedHandler;
            logic.PiValue2Changed += OnLogicPiValue2ChangedHandler;
            logic.PiValue3Changed += OnLogicPiValue3ChangedHandler;
            pauzeButton.Enabled = false;
            startButton.Enabled = true;
        }

        private void OnLogicPiValue3ChangedHandler(PiResult result)
        {
            uiContext.Post((dummy) =>
            {
                CirclePiTextBox.Text = result.Value.ToString();
                circleDeltaTextBox.Text = result.Delta.ToString();
                circleIterationsTextBox.Text = $"{result.Iterations:N0}";
            }, null);
        }

        private void OnLogicPiValue2ChangedHandler(PiResult result)
        {
            uiContext.Post((dummy) =>
            {
                LeibnizPiTextBox.Text = result.Value.ToString();
                LeibnizDeltaTextBox.Text = result.Delta.ToString();
                LeibnizIterationsTextBox.Text = $"{result.Iterations:N0}";
            }, null);
        }

        private void OnLogicPiValue1ChangedHandler(PiResult result)
        {
            uiContext.Post((dummy) =>
            {
                BbfPiTextBox.Text = result.Value.ToString();
                BbfDeltaTextBox.Text = result.Delta.ToString();
                BbfIterationsTextBox.Text = $"{result.Iterations:N0}";
            }, null);
        }

        private void OnMainFormFormClosing(object sender, FormClosingEventArgs e)
        {
            logic.Close();
        }

        private void StartButtonClick(object sender, EventArgs e)
        {
            pauzeButton.Enabled = true;
            startButton.Enabled = false;
            logic.Start();
        }

        private void PauzeButtonClick(object sender, EventArgs e)
        {
            pauzeButton.Enabled = false;
            startButton.Enabled = true;
            logic.Pause();
        }

        private void ResetButtonClick(object sender, EventArgs e)
        {
            logic.Reset();
        }
    }
}
