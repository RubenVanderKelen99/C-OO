﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Globals;


namespace CalculatePiBBF
{
    /// <summary>
    /// Calculates Pi using the Bailey-BorWein-Plouffe formula (https://en.wikipedia.org/wiki/Bailey%E2%80%93Borwein%E2%80%93Plouffe_formula):
    ///  
    /// Pi = Sum (for k = 0 to infinity) of (1/(16^k))*((4/(8*k+1)) - (2/(8k+4)) - (1/(8k+5)) - (1/(8k+6)))
    /// 
    /// </summary>
    public class PiBBFCalculator : IPiCalculator
    {
        
        private PiResult result;
        private decimal powerOfSixteen;

        public PiBBFCalculator()
        {
            Status = CalculatorStatus.ResetPaused;
            var progress = new Progress<PiResult>( (p) =>
            {
                if (PiValueChanged != null) PiValueChanged(p);
            });
            Task.Run(() => { CalculatePi(progress); });
        }

        public CalculatorStatus Status { get; set; }
        

        public event Action<PiResult> PiValueChanged;       


        private void CalculatePi(IProgress<PiResult> progress)
        {
            // Initialise Calculation
            while (Status != CalculatorStatus.Closing)
            {
                Thread.Sleep(50);
                switch (Status)
                {
                    case CalculatorStatus.Running:
                        {
                            if (result.Iterations <30)
                            {
                                CalculateNextValue();
                                progress.Report(result);
                            }
                            break;
                        }
                    case CalculatorStatus.ResetRunning:
                        {
                            InitCalculation();
                            progress.Report(result);
                            Status = CalculatorStatus.Running;
                            break;
                        }
                    case CalculatorStatus.ResetPaused:
                        {
                            InitCalculation();
                            progress.Report(result);
                            Status = CalculatorStatus.Paused;
                            break;
                        }
                    case CalculatorStatus.Paused:
                    default:
                        {
                            Thread.Sleep(50);
                            break;
                        }                 
                }

            }
        }

        private void InitCalculation()
        {
            result = new PiResult()
            {
                Value = 0,
                Delta = 0,
                Iterations = 0
            };
            powerOfSixteen = 1;
        }

        private void CalculateNextValue()
        {
            // CalculatePi
            var k = result.Iterations;
            result.Delta = powerOfSixteen * ((4 / (8M * k + 1)) - (2 / (8M*k + 4)) -(1 / (8M*k + 5)) -(1 / (8M*k + 6)));
            powerOfSixteen /= 16;
            result.Iterations++;
            result.Value += result.Delta;
        }

    }
}
