﻿using System;

namespace Globals
{

    public interface ICalculatePiLogic
    {
        void Start();
        void Pause();
        void Reset();
        void Close();

        event Action<PiResult> PiValue1Changed;

        event Action<PiResult> PiValue2Changed;

        event Action<PiResult> PiValue3Changed;

    }
}
