﻿using System;

namespace Globals
{

    // enum used for communication with Task
    public enum CalculatorStatus { Running, ResetRunning, ResetPaused, Paused, Closing }

    public interface IPiCalculator
    {
        /// <summary>
        /// set or get the current status for the Pi calculator
        /// </summary>
        CalculatorStatus Status { get; set; }

        /// <summary>
        /// Prepare & start the task in 'Pauzed' mode. To be called from the GUI thread.
        /// </summary>
        void PrepareTask();

        /// <summary>
        /// PiValueChanged is called whenever a new value for Pi is calculated or after a Reset
        /// </summary>
        event Action<PiResult> PiValueChanged;

    }
}
