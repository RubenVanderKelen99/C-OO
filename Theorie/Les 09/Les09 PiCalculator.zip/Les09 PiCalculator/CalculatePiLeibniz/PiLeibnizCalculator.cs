﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using CalculatePiBackendInterface;
using CalculatePiDataEntities;

namespace CalculatePiLeibniz
{
    /// <summary>
    /// Calculates Pi using the Leibniz (https://en.wikipedia.org/wiki/Leibniz_formula_for_%CF%80)
    ///  
    /// Pi = 4*(1-1/3+1/5-1/7+1/9- ...)
    /// 
    /// </summary>
    public class PiLeibnizCalculator : IPiCalculator
    {

        private PiResult result;
        private DateTime time;


        public PiLeibnizCalculator()
        {
            time = DateTime.Now;
            Status = CalculatorStatus.ResetPaused;
            var progress = new Progress<PiResult>((p) =>
            {
                if (PiValueChanged != null) PiValueChanged(p);
            });
            Task.Run(() => { CalculatePi(progress); });
        }

        public CalculatorStatus Status { get; set; }


        public event Action<PiResult> PiValueChanged;


        private void CalculatePi(IProgress<PiResult> progress)
        {
            // Initialise Calculation
            while (Status != CalculatorStatus.Closing)
            {
                switch (Status)
                {
                    case CalculatorStatus.Running:
                        {
                            CalculateNextValue();
                            var thisTime = DateTime.Now;
                            if ((thisTime - time).Milliseconds > 20)
                            {
                                time = thisTime;
                                progress.Report(result);
                            }
                            break;
                        }
                    case CalculatorStatus.ResetRunning:
                        {
                            InitCalculation();
                            progress.Report(result);
                            Status = CalculatorStatus.Running;
                            break;
                        }
                    case CalculatorStatus.ResetPaused:
                        {
                            InitCalculation();
                            progress.Report(result);
                            Status = CalculatorStatus.Paused;
                            break;
                        }
                    case CalculatorStatus.Paused:
                    default:
                        {
                            Thread.Sleep(50);
                            break;
                        }
                }

            }
        }

        private void InitCalculation()
        {
            result = new PiResult()
            {
                Value = 0,
                Delta = 0,
                Iterations = 0
            };

        }

        private void CalculateNextValue()
        {
            for (int i = 0; i < 2000; i++)
            {
                // CalculatePi
                var k = result.Iterations;
                if (result.Iterations % 2 == 0)
                {
                    result.Delta = 4M / (result.Iterations * 2 + 1);
                }
                else
                {
                    result.Delta = -1 * 4M / (result.Iterations * 2 + 1);
                }
                result.Iterations++;
                result.Value += result.Delta;
            }
        }


    }
}
