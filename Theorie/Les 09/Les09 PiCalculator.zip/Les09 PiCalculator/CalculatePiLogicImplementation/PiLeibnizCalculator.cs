﻿using Globals;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace CalculatePiLogicImplementation
{
    /// <summary>
    /// Calculates Pi using the Leibniz (https://en.wikipedia.org/wiki/Leibniz_formula_for_%CF%80)
    ///  
    /// Pi = 4*(1-1/3+1/5-1/7+1/9- ...)
    /// 
    /// </summary>
    public class PiLeibnizCalculator : IPiCalculator
    {

        private PiResult result;
        private DateTime time;

        private Task calculator;

        public CalculatorStatus Status { get; set; }

        public event Action<PiResult> PiValueChanged;

        public void PrepareTask()
        {
            if (calculator == null)
            {
                Status = CalculatorStatus.Paused;
                calculator = Task.Run(() => { CalculatePi(); });
                while (calculator.Status != TaskStatus.Running) Thread.Sleep(10);
            }
        }

        private void CalculatePi()
        {
            // Initialise Calculation
            while (Status != CalculatorStatus.Closing)
            {
                switch (Status)
                {
                    case CalculatorStatus.Running:
                        {
                            CalculateNextValue();
                            var thisTime = DateTime.Now;
                            if ((thisTime - time).TotalMilliseconds > 20)
                            {
                                time = thisTime;
                                PiValueChanged?.Invoke(result);
                            }
                            break;
                        }
                    case CalculatorStatus.ResetRunning:
                        {
                            InitCalculation();
                            PiValueChanged?.Invoke(result);
                            Status = CalculatorStatus.Running;
                            break;
                        }
                    case CalculatorStatus.ResetPaused:
                        {
                            InitCalculation();
                            PiValueChanged?.Invoke(result);
                            Status = CalculatorStatus.Paused;
                            break;
                        }
                    case CalculatorStatus.Paused:
                    default:
                        {
                            Thread.Sleep(50);
                            break;
                        }
                }
            }
        }

        private void InitCalculation()
        {
            result = new PiResult()
            {
                Value = 0,
                Delta = 0,
                Iterations = 0
            };
        }

        private void CalculateNextValue()
        {
            for (int i = 0; i < 2000; i++)
            {
                // CalculatePi
                if (result.Iterations % 2 == 0)
                {
                    result.Delta = 4M / (result.Iterations * 2 + 1);
                }
                else
                {
                    result.Delta = -1 * 4M / (result.Iterations * 2 + 1);
                }
                result.Iterations++;
                result.Value += result.Delta;
            }
        }


    }
}
