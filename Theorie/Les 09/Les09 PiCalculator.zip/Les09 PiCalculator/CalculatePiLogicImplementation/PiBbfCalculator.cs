﻿using Globals;
using System;
using System.Threading;
using System.Threading.Tasks;


namespace CalculatePiLogicImplementation
{
    /// <summary>
    /// Calculates Pi using the Bailey-BorWein-Plouffe formula (https://en.wikipedia.org/wiki/Bailey%E2%80%93Borwein%E2%80%93Plouffe_formula):
    ///  
    /// Pi = Sum (for k = 0 to infinity) of (1/(16^k))*((4/(8*k+1)) - (2/(8k+4)) - (1/(8k+5)) - (1/(8k+6)))
    /// 
    /// </summary>
    public class PiBbfCalculator : IPiCalculator
    {

        private PiResult result;
        private decimal powerOfSixteen;
        private Task calculator;

        public CalculatorStatus Status { get; set; }

        public event Action<PiResult> PiValueChanged;

        public void PrepareTask()
        {
            if (calculator == null)
            {
                Status = CalculatorStatus.Paused;
                InitCalculation();
                calculator = Task.Run(() => { CalculatePi(); });
                while (calculator.Status != TaskStatus.Running) Thread.Sleep(10);
            }
        }

        private void CalculatePi()
        {
            while (Status != CalculatorStatus.Closing)
            {
                Thread.Sleep(50);
                switch (Status)
                {
                    case CalculatorStatus.Running:
                        {
                            if (result.Iterations < 30)
                            {
                                CalculateNextValue();
                                PiValueChanged?.Invoke(result);
                            }
                            break;
                        }
                    case CalculatorStatus.ResetRunning:
                        {
                            InitCalculation();
                            PiValueChanged?.Invoke(result);
                            Status = CalculatorStatus.Running;
                            break;
                        }
                    case CalculatorStatus.ResetPaused:
                        {
                            InitCalculation();
                            PiValueChanged?.Invoke(result);
                            Status = CalculatorStatus.Paused;
                            break;
                        }
                    case CalculatorStatus.Paused:
                    default:
                        {
                            Thread.Sleep(50);
                            break;
                        }
                }

            }
        }

        private void InitCalculation()
        {
            result = new PiResult()
            {
                Value = 0,
                Delta = 0,
                Iterations = 0
            };
            powerOfSixteen = 1;
        }

        private void CalculateNextValue()
        {
            // CalculatePi
            long k = result.Iterations;
            result.Delta = powerOfSixteen * ((4 / ((8M * k) + 1)) - (2 / ((8M * k) + 4)) - (1 / ((8M * k) + 5)) - (1 / ((8M * k) + 6)));
            powerOfSixteen /= 16;
            result.Iterations++;
            result.Value += result.Delta;
        }
    }
}
