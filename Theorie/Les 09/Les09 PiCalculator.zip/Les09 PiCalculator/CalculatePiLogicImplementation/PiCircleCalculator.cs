﻿using Globals;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace CalculatePiLogicImplementation
{

    /// <summary>
    /// Calculates Pi using the formula for the area of a circle and random numbers
    /// (http://maciejczyzewski.me/2015/01/10/monte-carlo-method-calculating-pi.html)
    ///  
    /// </summary>
    public class PiCircleCalculator : IPiCalculator
    {

        private PiResult result;
        private decimal pointsInCircle;
        private Random random;
        private DateTime time;
        private Task calculator;

        public CalculatorStatus Status { get; set; }

        public event Action<PiResult> PiValueChanged;

        public void PrepareTask()
        {
            random = new Random();
            if (calculator == null)
            {
                Status = CalculatorStatus.Paused;
                InitCalculation();
                calculator = Task.Run(() => { CalculatePi(); });
                while (calculator.Status != TaskStatus.Running) Thread.Sleep(10);
            }
        }

        private void CalculatePi()
        {
            while (Status != CalculatorStatus.Closing)
            {
                switch (Status)
                {
                    case CalculatorStatus.Running:
                        {
                            CalculateNextValue();
                            var thisTime = DateTime.Now;
                            if ((thisTime - time).TotalMilliseconds > 20)
                            {
                                time = thisTime;
                                PiValueChanged?.Invoke(result);
                            }
                            break;
                        }
                    case CalculatorStatus.ResetRunning:
                        {
                            InitCalculation();
                            PiValueChanged?.Invoke(result);
                            Status = CalculatorStatus.Running;
                            break;
                        }
                    case CalculatorStatus.ResetPaused:
                        {
                            InitCalculation();
                            PiValueChanged?.Invoke(result);
                            Status = CalculatorStatus.Paused;
                            break;
                        }
                    case CalculatorStatus.Paused:
                    default:
                        {
                            Thread.Sleep(50);
                            break;
                        }
                }

            }
        }

        private void InitCalculation()
        {
            result = new PiResult()
            {
                Value = 0,
                Delta = 0,
                Iterations = 0
            };
            pointsInCircle = 0;
        }

        private void CalculateNextValue()
        {
            for (int i = 0; i < 2000; i++)
            {
                // Calculate Pi
                double x = random.NextDouble();
                double y = random.NextDouble();
                if ((x * x + y * y) <= 1) pointsInCircle++;
                result.Iterations++;
                decimal oldvalue = result.Value;
                result.Value = 4M * pointsInCircle / result.Iterations;
                result.Delta = result.Value - oldvalue;
            }
        }
    }
}
