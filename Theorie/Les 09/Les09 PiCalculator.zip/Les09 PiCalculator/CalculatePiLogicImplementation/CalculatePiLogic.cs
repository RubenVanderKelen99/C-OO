﻿using Globals;
using System;


namespace CalculatePiLogicImplementation
{
    public class CalculatePiLogic : ICalculatePiLogic
    {
        private readonly IPiCalculator piBbfCalc;
        private readonly IPiCalculator piLeibnizCalc;
        private readonly IPiCalculator piCircleCalc;
        private bool tasksStarted;

        public event Action<PiResult> PiValue1Changed;
        public event Action<PiResult> PiValue2Changed;
        public event Action<PiResult> PiValue3Changed;

        public CalculatePiLogic(IPiCalculator piBbfCalc,
                                IPiCalculator piLeibnizCalc,
                                IPiCalculator piCircleCalc)
        {
            this.piBbfCalc = piBbfCalc;
            this.piBbfCalc.PiValueChanged += OnPiBbfCalcPiValueChangedHandler;
            this.piLeibnizCalc = piLeibnizCalc;
            this.piLeibnizCalc.PiValueChanged += OnPiLeibnizCalcPiValueChangedHandler;
            this.piCircleCalc = piCircleCalc;
            this.piCircleCalc.PiValueChanged += OnPiCircleCalcPiValueChangedHandler;
            tasksStarted = false;
        }

        private void OnPiCircleCalcPiValueChangedHandler(PiResult result)
        {
            PiValue3Changed?.Invoke(result);
        }

        private void OnPiLeibnizCalcPiValueChangedHandler(PiResult result)
        {
            PiValue2Changed?.Invoke(result);
        }

        private void OnPiBbfCalcPiValueChangedHandler(PiResult result)
        {
            PiValue1Changed?.Invoke(result);
        }

        public void Close()
        {
            piBbfCalc.Status = CalculatorStatus.Closing;
            piLeibnizCalc.Status = CalculatorStatus.Closing;
            piCircleCalc.Status = CalculatorStatus.Closing;
        }

        public void Pause()
        {
            piBbfCalc.Status = CalculatorStatus.Paused;
            piLeibnizCalc.Status = CalculatorStatus.Paused;
            piCircleCalc.Status = CalculatorStatus.Paused;
        }

        public void Reset()
        {
            if (piBbfCalc.Status == CalculatorStatus.Running)
            {
                piBbfCalc.Status = CalculatorStatus.ResetRunning;
                piLeibnizCalc.Status = CalculatorStatus.ResetRunning;
                piCircleCalc.Status = CalculatorStatus.ResetRunning;
            }
            else
            {
                piBbfCalc.Status = CalculatorStatus.ResetPaused;
                piLeibnizCalc.Status = CalculatorStatus.ResetPaused;
                piCircleCalc.Status = CalculatorStatus.ResetPaused;
            }
        }

        public void Start()
        {
            if (!tasksStarted) CreateTasks();
            piBbfCalc.Status = CalculatorStatus.Running;
            piLeibnizCalc.Status = CalculatorStatus.Running;
            piCircleCalc.Status = CalculatorStatus.Running;
        }

        private void CreateTasks()
        {
            piBbfCalc.PrepareTask();
            piCircleCalc.PrepareTask();
            piLeibnizCalc.PrepareTask();
            tasksStarted = true;
        }
    }
}
