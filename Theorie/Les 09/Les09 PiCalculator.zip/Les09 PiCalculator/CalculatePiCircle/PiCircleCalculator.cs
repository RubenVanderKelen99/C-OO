﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using CalculatePiBackendInterface;
using CalculatePiDataEntities;

namespace CalculatePiCircle
{

    /// <summary>
    /// Calculates Pi using the formula for the area of a circle and random numbers
    /// (http://maciejczyzewski.me/2015/01/10/monte-carlo-method-calculating-pi.html)
    ///  
    /// Pi = 4*(1-1/3+1/5-1/7+1/9- ...)
    /// 
    /// </summary>
    public class PiCircleCalculator:IPiCalculator
    {

        private PiResult result;
        private decimal pointsInCircle;
        private Random random;
        private DateTime time;

        public PiCircleCalculator()
        {
            random = new Random();
            time = DateTime.Now;
            Status = CalculatorStatus.ResetPaused;
            var progress = new Progress<PiResult>((p) =>
            {
                if (PiValueChanged != null) PiValueChanged(p);
            });
            Task.Run(() => { CalculatePi(progress); });
        }

        public CalculatorStatus Status { get; set; }


        public event Action<PiResult> PiValueChanged;


        private void CalculatePi(IProgress<PiResult> progress)
        {
            // Initialise Calculation
            while (Status != CalculatorStatus.Closing)
            {
                switch (Status)
                {
                    case CalculatorStatus.Running:
                        {
                            CalculateNextValue();
                            var thisTime = DateTime.Now;
                            if ((thisTime - time).Milliseconds > 20)
                            {
                                time = thisTime;
                                progress.Report(result);
                            }
                            break;
                        }
                    case CalculatorStatus.ResetRunning:
                        {
                            InitCalculation();
                            progress.Report(result);
                            Status = CalculatorStatus.Running;
                            break;
                        }
                    case CalculatorStatus.ResetPaused:
                        {
                            InitCalculation();
                            progress.Report(result);
                            Status = CalculatorStatus.Paused;
                            break;
                        }
                    case CalculatorStatus.Paused:
                    default:
                        {
                            Thread.Sleep(50);
                            break;
                        }
                }

            }
        }

        private void InitCalculation()
        {
            result = new PiResult()
            {
                Value = 0,
                Delta = 0,
                Iterations = 0
            };
            pointsInCircle = 0;

        }

        private void CalculateNextValue()
        {
            for (int i = 0; i < 2000; i++)
            {
                // Calculate Pi
                var x = random.NextDouble();
                var y = random.NextDouble();
                if ((x * x + y * y) <= 1) pointsInCircle++;
                result.Iterations++;
                decimal oldvalue = result.Value;
                result.Value = 4M * pointsInCircle / result.Iterations;
                result.Delta = result.Value - oldvalue;
            }           
        }



    }
}
