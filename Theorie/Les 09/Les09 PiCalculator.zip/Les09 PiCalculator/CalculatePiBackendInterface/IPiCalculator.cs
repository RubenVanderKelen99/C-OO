﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatePiDataEntities;

namespace CalculatePiBackendInterface
{

    // enum used for communication with Task
    public enum CalculatorStatus { Running, ResetRunning, ResetPaused, Paused, Closing }

    public interface IPiCalculator
    {
        /// <summary>
        /// set or get the current status for teh Pi calculator
        /// </summary>
        CalculatorStatus Status { get; set; }

        /// <summary>
        /// PiValueChanged is called whenever a new value for Pi is calculated or after a Reset
        /// </summary>
        event Action<PiResult> PiValueChanged;

    }
}
