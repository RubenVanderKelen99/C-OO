﻿using static System.Console;

namespace Demo_Les_9
{
    internal class Program
    {

        private static void PrintMenu()
        {
            WriteLine();
            WriteLine();
            WriteLine("Democode C# OO - Les O8");
            WriteLine();
            WriteLine("1.  Task Demo");
            WriteLine("2.  Task parameter Demo");
            WriteLine("3.  Task Result Demo");
            WriteLine("4.  Task Waiting Demo");
            WriteLine("5.  Task Cancellation Demo");
            WriteLine("0.  Exit");
            WriteLine();
            Write("Geef je keuze in: ");
        }

        private static void Main()
        {
            bool exit = false;

            while (!exit)
            {
                PrintMenu();
                string input = ReadLine();
                WriteLine();
                switch (input[0])
                {
                    case '0':
                        {
                            exit = true;
                            break;
                        }
                    case '1':
                        {
                            new TaskDemo().Run();
                            break;
                        }
                    case '2':
                        {
                            new TaskParameterDemo().Run();
                            break;
                        }
                    case '3':
                        {
                            new TaskResultDemo().Run();
                            break;
                        }

                    case '4':
                        {
                            new TaskWaitingDemo().Run();
                            break;
                        }
                    case '5':
                        {
                            new TaskCancellationDemo().Run();
                            break;
                        }

                    default:
                        {
                            // WriteLine("Invalid input, try again...");
                            break;
                        }
                }
            }


        }
    }
}
