﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Demo_Les_9
{
    internal class TaskParameterDemo
    {
        public void DoSomething(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"    Concurrent task: loop nr. {i}");
                Thread.Sleep(500);
            }
        }
        public void Run()
        {
            // running on UI thread

            int nrOfIterations = 8;
            var job = Task.Run(() => { DoSomething(nrOfIterations); });
            nrOfIterations = 3;
            Console.WriteLine("task started...");

            // execute code concurrent with the job task here...
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Main thread looping");
                Thread.Sleep(200);
            }
            Console.WriteLine("Waiting for task to finish...");

            job.Wait();
            Console.WriteLine("task ended.");
        }
    }
}
