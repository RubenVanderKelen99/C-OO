﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Demo_Les_9
{
    internal class TaskWaitingDemo
    {
        public static void PrintChar(char a, int delay)
        {
            for (int i = 0; i < 10; i++)
            {
                Console.Write(a);
                Thread.Sleep(delay);
            }
        }

        public void Run()
        {
            // running on UI thread

            var job1 = Task.Run(() => { PrintChar('#', 300); });
            var job2 = Task.Run(() => { PrintChar('!', 500); });
            var job3 = Task.Run(() => { PrintChar('O', 700); });
            Console.WriteLine("task started...");

            // execute code concurrent with the job task here...
            while (!job1.Wait(500)) Console.WriteLine("\n Waiting for job1");
            Console.WriteLine("task 1 finished, waiting for 2 & 3...");
            Task.WaitAll(new Task[] { job2, job3 });
            Console.WriteLine("\n all tasks finished. \n");
        }
    }
}
