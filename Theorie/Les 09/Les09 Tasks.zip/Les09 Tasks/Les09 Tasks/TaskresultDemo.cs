﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo_Les_9
{
    class TaskResultDemo
    {
        public long Factorial(int number)
        {
            if (number <= 1) return 1;
            else return number * Factorial(number - 1);                    
        }

        public void Run()
        {
            // running on UI thread

            Task<long> job = Task.Run(() => { return Factorial(20); });
            Console.WriteLine("task started...");

            // execute code concurrent with the job task here...
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Main thread looping");
                Thread.Sleep(200);
            }
            Console.WriteLine("Waiting for task to finish...");
            long result = job.Result;

            Console.WriteLine($"task ended: 20! = {result}.\n");
        }
    }
}
