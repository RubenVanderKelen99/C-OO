﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Demo_Les_9
{
    internal class TaskCancellationDemo
    {

        public static void DoSomething(int delay, CancellationToken token)
        {
            int i = 0;
            while (!token.IsCancellationRequested)
            {
                i++;
                Console.WriteLine($"    Waiting for cancellation: loop nr. {i}");
                Thread.Sleep(delay);
            }
        }

        public void Run()
        {
            using (var cancelSource = new CancellationTokenSource())
            {
                var cancelToken = cancelSource.Token;

                Task.Run(() => { DoSomething(1000, cancelToken); }, cancelToken);
                Console.WriteLine("Task started. Press <enter> to stop it.");
                Console.ReadLine();

                cancelSource.Cancel();
            }
            Console.WriteLine("Task finished.\n");
        }
    }
}
