﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo_Les_9
{
    public class TaskDemo
    {
        public void DoSomething()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"    Concurrent task: loop nr. {i}");
                Thread.Sleep(500);
            }            
        }
        public void Run()
        {
            // running on UI thread
            var job = Task.Run((Action)DoSomething);
            Console.WriteLine("task started...");
          
            // execute code concurrent with the job task here...
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Main thread looping");
                Thread.Sleep(200);
            }
            Console.WriteLine("Waiting for task to finish...");

            job.Wait();
            Console.WriteLine("task ended.");            
        }
    }

}
