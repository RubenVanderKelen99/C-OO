﻿using Logica;
using System.Windows;
using System.Windows.Controls;

namespace WpfGemeenteZoeker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly PostcodeLogica logica;

        public MainWindow()
        {
            InitializeComponent();
            logica = new PostcodeLogica();
        }

        private void QueryTextChanged(object sender, TextChangedEventArgs e)
        {
            ResultList.ItemsSource = logica.GetMatchingResults(QueryText.Text);
        }
    }
}
