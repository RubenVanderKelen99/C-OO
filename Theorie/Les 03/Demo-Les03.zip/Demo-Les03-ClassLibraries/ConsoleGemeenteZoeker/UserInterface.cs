﻿using Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleGemeenteZoeker
{
    public class UserInterface
    {
        private readonly PostcodeLogica logica;

        public UserInterface()
        {
            logica = new PostcodeLogica();
        }

        public void Run()
        {
            ShowStartBanner();
            RunQueries();
        }

        private void RunQueries()
        {
            string query=string.Empty;
            do
            {
                Console.Write(">");
                query = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(query))
                {
                    ShowResultForQuery(query);
                }
            }
            while (!string.IsNullOrWhiteSpace(query));
            
        }

        private void ShowResultForQuery(string query)
        {
            Console.WriteLine();
            foreach (string line in logica.GetMatchingResults(query))
            {
                Console.WriteLine(line);
            }
            Console.WriteLine();
        }

        private void ShowStartBanner()
        {
            Console.WriteLine("Gemeentezoeker");
            Console.WriteLine("--------------\n");
            Console.WriteLine("Geef een zoekterm (of <enter> om te eindigen)\n");
        }               

    }
}
