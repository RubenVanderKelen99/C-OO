﻿using Datalaag;
using Globals;
using System.Collections.Generic;

namespace Logica
{
    public class PostcodeLogica
    {
        private readonly DataProvider dataProvider;

        public PostcodeLogica()
        {
            dataProvider = new DataProvider();
        }

        public List<string> GetMatchingResults(string query)
        {
            var matches = new List<ZipInfo>();
            foreach (var zipInfo in dataProvider.GemeenteLijst)
            {
                if (zipInfo.ToString().ToUpper().Contains(query.ToUpper())) matches.Add(zipInfo);
            }
            matches.Sort();
            var result = new List<string>();
            foreach (var zipInfo in matches)
            {
                result.Add(zipInfo.ToString());
            }
            return result;

            //// alternative implmentation using Linq

            //return dataProvider.GemeenteLijst
            //         .Where(g => g.ToString().ToUpper().Contains(query.ToUpper()))
            //         .OrderBy(g => g.Gemeente).Select(g => g.ToString()).ToList();

        }
    }
}
