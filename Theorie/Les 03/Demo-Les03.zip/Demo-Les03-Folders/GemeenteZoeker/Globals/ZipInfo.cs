﻿using System;

namespace GemeenteZoeker.Globals
{
    public struct ZipInfo : IComparable<ZipInfo>
    {
        public int Zipcode { get; }
        public string Gemeente { get; }
        public string Provincie { get; }

        public ZipInfo(int zipcode, string gemeente, string provincie)
        {
            Zipcode = zipcode;
            Gemeente = gemeente;
            Provincie = provincie;
        }

        public override string ToString()
        {
            return $"{Zipcode} - {Gemeente} ({Provincie})";
        }

        public int CompareTo(ZipInfo other)
        {
            return Gemeente.CompareTo(other.Gemeente);
        }
    }
}
