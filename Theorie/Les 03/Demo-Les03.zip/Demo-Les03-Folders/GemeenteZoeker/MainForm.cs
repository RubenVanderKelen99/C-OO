﻿
using System;
using System.Windows.Forms;
using GemeenteZoeker.Logica;

namespace GemeenteZoeker
{
    public partial class MainForm : Form
    {
        private readonly PostcodeLogica logica;

        public MainForm()
        {
            InitializeComponent();
            logica = new PostcodeLogica();
        }

        private void ZoekTextChanged(object sender, EventArgs e)
        {
            resultBox.Lines = logica.GetMatchingResults(zoekBox.Text).ToArray();
        }
    }
}
