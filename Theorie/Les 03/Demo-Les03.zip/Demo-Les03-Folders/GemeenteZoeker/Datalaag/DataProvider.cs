﻿
using System.Collections.Generic;
using System.IO;
using GemeenteZoeker.Globals;

namespace GemeenteZoeker.Datalaag
{
    public class DataProvider
    {
        private const string filename = @"resources\zipcodes_alpha_nl.csv";

        public List<ZipInfo> GemeenteLijst { get; }

        public DataProvider()
        {            
            GemeenteLijst = ReadGemeenteInfo(filename);
        }

        private List<ZipInfo> ReadGemeenteInfo(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            var result = new List<ZipInfo>();
            foreach (string line in lines)
            {
                string[] lineParts = line.Split(';');
                if (lineParts.Length > 0)
                {
                    result.Add(new ZipInfo(zipcode: int.Parse(lineParts[0]),
                                            gemeente: lineParts[1].Trim(),
                                            provincie: (lineParts.Length > 2) ? lineParts[2] : string.Empty
                                           ));
                }
            }
            return result;
        }
    }
}
