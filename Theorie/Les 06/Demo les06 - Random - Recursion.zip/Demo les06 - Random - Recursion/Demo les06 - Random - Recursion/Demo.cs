﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;


namespace RandomDemo
{
    public class Demo
    {

        public void ShowBadRandom()
        {
            Write("Bad random:"); 
            for (int i = 0; i<10; i++)
            {
                var random = new Random();
                Write($"{random.Next(10)} ");
            }
            WriteLine();
        }

        public void ShowGoodRandom()
        {
            Write("Good random:");
            var random = new Random();
            for (int i = 0; i<10; i++)            {
                
                Write($"{random.Next(10)} ");
            }
            WriteLine();
        }

        public void ShowRepeatableRandom()
        {
            WriteLine("Repeatable random:\n");

            for (int count = 0; count<5; count++)
            {
                var random = new Random(5);
                for (int i = 0; i<10; i++)
                {
                    Write($"{random.Next(10)} ");
                }
                WriteLine();
                Thread.Sleep(100);
            }            
        }

        public void PrintNumbers(int start, int end)
        {
            if (start==end)
            {
                Console.WriteLine(end);
            }
            else
            {
                Console.Write($"{start},");
                PrintNumbers(start+1, end);
            }
        }
        
        public int Power(int baseNr, int exponent)
        {
            if (exponent==1) return baseNr;
            else
            {
                return baseNr*Power(baseNr, exponent-1);
            }
        }
    }
}
