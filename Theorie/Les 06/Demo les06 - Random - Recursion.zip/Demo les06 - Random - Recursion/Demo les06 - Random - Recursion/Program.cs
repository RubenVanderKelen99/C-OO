﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace RandomDemo
{
    class Program
    {

        private static void PrintMenu()
        {
            WriteLine();
            WriteLine();
            WriteLine("Democode C# OO - Les 6");
            WriteLine();
            WriteLine("1.  Show bad Random");
            WriteLine("2.  Show Good Random");
            WriteLine("3.  show repeatable Random");
            WriteLine("4.  Recursively print numbers");
            WriteLine("5.  recursively calculate power");
            WriteLine("0.  Exit");
            WriteLine();
            Write("Geef je keuze in: ");
        }

        static void Main()
        {

            bool exit = false;
            var d = new Demo();
            while (!exit)
            {
                PrintMenu();
                string input = ReadLine();
                WriteLine();
                switch (input[0])
                {
                    case '0':
                        {
                            exit=true;
                            break;
                        }
                    case '1':
                        {
                            d.ShowBadRandom();
                            break;
                        }
                    case '2':
                        {
                            d.ShowGoodRandom();
                            break;
                        }
                    case '3':
                        {
                            d.ShowRepeatableRandom();
                            break;
                        }
                    case '4':
                        {
                            d.PrintNumbers(3,9);
                            break;
                        }
                    case '5':
                        {
                            WriteLine($"\n2 ^ 10 = {d.Power(2, 10)}\n");
                            break;
                        }

                    default:
                        {
                            WriteLine("Invalid input, try again...");
                            break;
                        }
                }
            }
        }
    }
}
