﻿using System;

namespace Les08LambdaDemo
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] testArray = new int[] { 1, 2, 3, 4, 5, 6 };
            var processor = new ArrayProcessor(testArray);
            processor.Write();
            processor.Process(i => i + 1);
            processor.Write();
            processor.Process(Bewerking.Verdubbel);
            processor.Write();
            processor.ShortProcess(Bewerking.VolgendeMachtVanTwee);
            processor.Write();
            processor.ShortProcess(Bewerking.Inverteer);
            processor.Write();
            Console.WriteLine("\nPress <Enter> to continue...");
            Console.ReadLine();
        }
    }
}
