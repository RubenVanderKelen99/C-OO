﻿namespace Les08LambdaDemo
{
    public enum Bewerking { Verdubbel, Inverteer, ZetOpNul, VolgendeMachtVanTwee }
}
