﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Les08LambdaDemo
{
    public class ArrayProcessor
    {
        private int[] array;

        private Dictionary<Bewerking, Func<int, int>> operations;


        public ArrayProcessor(int[] array)
        {
            this.array = array;
            InitOperations();
        }

        private int Invert(int i)
        {
            return -i;
        }

        public void Write()
        {
            var sb = new StringBuilder($"{array[0]}");
            for (int i = 1; i < array.Length; i++)
            {
                sb.Append($", {array[i]}");
            }
            Console.WriteLine(sb);
        }

        public void Process(Func<int, int> operation)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = operation(array[i]);
            }
        }



        public void Process(Bewerking bewerking)
        {
            switch (bewerking)
            {
                case Bewerking.Verdubbel:
                    Process(i => i * 2);
                    break;
                case Bewerking.Inverteer:
                    Process(Invert);
                    break;
                case Bewerking.ZetOpNul:
                    Process(i => 0);
                    break;
                case Bewerking.VolgendeMachtVanTwee:
                    Process(i =>
                        {
                            int macht = 1;
                            while (macht < i) macht *= 2;
                            return macht;
                        });
                    break;
                default:
                    break;
            }
        }

        private void InitOperations()
        {
            operations = new Dictionary<Bewerking, Func<int, int>>
            {
                { Bewerking.Inverteer, Invert },
                { Bewerking.Verdubbel, i => i*2 },
                { Bewerking.ZetOpNul, i => 0 },
                { Bewerking.VolgendeMachtVanTwee, i =>
                        {
                            int macht = 1;
                            while (macht < i) macht *= 2;
                            return macht;
                        }
                }
            };
        }

        public void ShortProcess(Bewerking bewerking)
        {
            Process(operations[bewerking]);
        }


    }
}
