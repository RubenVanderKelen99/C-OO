﻿using static System.Console;

namespace Les08Demo
{
    internal class Program
    {

        private static void PrintMenu()
        {
            WriteLine();
            WriteLine();
            WriteLine("Democode C# OO - Les O7");
            WriteLine();
            WriteLine("1.  Delegate Demo");
            WriteLine("2.  Predefined Delegate Demo");
            WriteLine("3.  Action Delegate Demo");
            WriteLine("4.  Events Demo");
            WriteLine("0.  Exit");
            WriteLine();
            Write("Geef je keuze in: ");
        }

        private static void Main(string[] args)
        {
            bool exit = false;

            while (!exit)
            {
                PrintMenu();
                string input = ReadLine();
                WriteLine();
                switch (input[0])
                {
                    case '0':
                        {
                            exit = true;
                            break;
                        }
                    case '1':
                        {
                            new DelegateDemo().Run();
                            break;
                        }
                    case '2':
                        {
                            new PredefinedDelegateDemo().Run();
                            break;
                        }
                    case '3':
                        {
                            new ActionDelegateDemo().Run();
                            break;
                        }

                    case '4':
                        {
                            new EventsDemo().Run();
                            break;
                        }

                    default:
                        {
                            WriteLine("Invalid input, try again...");
                            break;
                        }
                }
            }


        }
    }
}
