﻿using System;

namespace Les08Demo
{

    public class Counter
    {
        public delegate void CountChangedEvent(int count);

        public event CountChangedEvent CountChanged;

        //Same effect: public event Action<int> CountChanged;

        private int count = 0;
        public int Count
        {
            get { return count; }
            set
            {
                count = value;
                if (CountChanged != null) CountChanged(value);
            }
        }
    }

    public class CountObserver
    {
        public CountObserver(Counter c)
        {
            c.CountChanged += CountChangedEventHandler;
        }
        public void CountChangedEventHandler(int count)
        {
            Console.WriteLine($" new count value: {count}");
        }
    }

    internal class EventsDemo
    {
        public void Run()
        {
            Console.WriteLine(" Demo for events \n");

            var counter = new Counter();
            var countObserver = new CountObserver(counter);
            counter.CountChanged += (x) => { Console.WriteLine($" From Demo 04 class: {x}"); };

            counter.Count += 1;
            counter.Count = 5;

            Console.WriteLine();
        }



    }
}
