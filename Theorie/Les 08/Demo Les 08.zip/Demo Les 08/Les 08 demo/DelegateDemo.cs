﻿using System;

namespace Les08Demo
{

    public delegate int Calculate(int i1, int i2);

    public class DelegateDemo
    {
        private readonly int a = 5;
        private readonly int b = 2;

        private int Sum(int x, int y)
        {
            return x + y;
        }

        private int Product(int x, int y)
        {
            return x * y;
        }

        private int Max(int x, int y)
        {
            return (x > y) ? x : y;
        }

        /// <summary>
        /// Performs a binary operation on a & b and prints out the result.
        /// </summary>
        /// <param name="message"> message to print out</param>
        /// <param name="calculate">function to execute on a & b </param>
        private void WriteResult(string message, Calculate calculate)
        {
            int result = calculate(a, b);
            Console.WriteLine($" {message} : {result}");
        }

        public void Run()
        {
            Console.WriteLine(" Demo for function parameter \n");

            // a delegate can be instantiated in two ways:
            Calculate operation = Max;
            var anotherOperation = new Calculate(Sum);
            // ... and be used as a the method
            int x = operation(2, 3);

            Console.WriteLine($" a : {a}, b : {b}\n");

            //pass a delegate instance as a parameter
            WriteResult("Maximum", operation);
            WriteResult("Sum", anotherOperation);


            // a suitable method can be passed immediately as a param
            WriteResult("Product", Product);

            Console.WriteLine();
        }

    }
}
