﻿using System;

namespace Les08Demo
{
    internal class Logger
    {
        private readonly string text;

        public Logger(string text)
        {
            this.text = text;
        }

        public void DisplayText(Action<string> display)
        {
            display(text);
        }
    }

    internal class ActionDelegateDemo
    {
        private void DecoratedWrite(string message)
        {
            Console.WriteLine($" Logged at {DateTime.Now.ToShortTimeString()}: {message}");
        }
        private void SimpleWrite(string message)
        {
            Console.WriteLine(message);
        }

        public void Run()
        {
            Console.WriteLine(" Demo for Action Delegate \n");

            var logger = new Logger(" Text to Log");

            logger.DisplayText(SimpleWrite);
            logger.DisplayText(DecoratedWrite);

            Console.WriteLine();
        }

    }


}
