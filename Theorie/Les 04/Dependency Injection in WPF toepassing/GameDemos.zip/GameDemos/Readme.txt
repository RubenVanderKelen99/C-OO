In deze solution staan twee versies van hetzelfde (eenvoduig) spel:

TimerGameDemo: 

- Implementeert de 'game-loop' aan de hand van een hardware-timer.
- Het game-verloop is iets minder transparant.
- De Timer heeft een resolutie van 1ms (nauwkeuriger kan niet) en er is geen garantie dat
  het interval tussen twee iteraties van de game-loop (= Ticks) niet langer is.
  De latency na een userinteractie kan dus gemakkelijk oplopen tot 1ms of meer.
- Tussen twee 'Ticks'  wordt de CPU niet belast.

WhileGameDemo:

- Implementeert de 'game-loop' met een while-lus waarin tijd vrij gemaakt wordt
  voor het verwerken van (userinteractie)-events via 'Application.DoEvents();
- Het game-verloop is duidlijk zichtbaar in de code.
- De game-loop wordt continue uitgevoerd, zodat de latency na een userinteractie 
  zeer klein zal zijn (en berekeningen voor het spel met een grote tijdsnauwkeurigheid 
  uitgevoerd kunnen worden.
- Doordat de game-loop continue uitgevoerd wordt, zal de CPU hier vrij zwaar belast
  worden (ook als er niets te berkenen valt).

Opmerking: Om de voorbeeldcode zo eenvoudig mogelijk te maken wordt er niet gewerkt
           met een afzonderlijk klasse-object (daarvoor zouden events of delegates gebruikt
		   moeten worden). Ook wordt er niet met een klasse-bibliotheek gewerkt (zou wel
		   handig zijn om de 'Disc'-klasse op ��nplaats onder te brengen in plaats van twee
		   kopies te voorzien).

Opmerking 2: Om het spel meer uitdagend te maken, kan je de waarde van 'maxDiscLifeTime' in
             'MainForm' verkleinen (bv.: 'TimeSpan maxDiscLifeTime = TimeSpan.FromMilliseconds(500);').