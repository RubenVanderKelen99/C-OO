﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WhileGameDemo
{
    public partial class MainForm : Form
    {


        public MainForm()
        {
            InitializeComponent();
            gameBox.Image=new Bitmap(gameBox.Width, gameBox.Height);
        }


        // user actions

        private void OnStartButtonClick(object sender, EventArgs e)
        {
            Playgame();
        }

        private void OnGameBoxMouseClick(object sender, MouseEventArgs e)
        {
            mouseClickedLocation=e.Location;
        }


        // Output form Game

        private void SetScore(int score)
        {
            scoreTextBox.Text=$"{score:D2}/{nrOfDiscs:D2} ({score*1m/(nrOfDiscs>0?nrOfDiscs:1):P0})";
        }

        private void SetProgress(int percentage)
        {
            progressBar.Value=percentage;
        }

        private void ShowDisc(Disc disc)
        {
            using (var brush = new SolidBrush(Color.Red))
            using (var g = Graphics.FromImage(gameBox.Image))
            {
                g.FillEllipse(brush, disc.BoundingBox);
            };
            gameBox.Invalidate(true);
        }

        private void ClearBox()
        {
            using (var g = Graphics.FromImage(gameBox.Image))
            {
                g.Clear(Color.WhiteSmoke);
            };
            gameBox.Invalidate(true);
        }


        private void ClearUI()
        {
            startButton.Enabled=true;
            progressBar.Visible=false;
        }

        // Fields used for Game logic

        TimeSpan gameDuration = TimeSpan.FromSeconds(30);
        TimeSpan maxDiscWaitTime = TimeSpan.FromSeconds(1);
        TimeSpan maxDiscLifeTime = TimeSpan.FromSeconds(1);
        private Random rnd = new Random();
        private Point limits;
        private bool gameAborted;
        private Point mouseClickedLocation = new Point();
        private int score;
        private int nrOfDiscs;
        private DateTime gameStartTime;
        private DateTime nextDiscDue;
        private Disc disc;
       
                
        private void Playgame()
        {
            startButton.Enabled=false;
            progressBar.Visible=true;
            InitGame();
            DoGameloop();
            FinishGame();
            ClearUI();
        }

        private void InitGame()
        {
            ResetMouseClickedLocation();
            limits=new Point(gameBox.Width, gameBox.Height);
            gameAborted=false;
            score=0;
            disc=null;
            nrOfDiscs=0;
            nextDiscDue=DateTime.Now.AddMilliseconds(rnd.Next((int)maxDiscWaitTime.TotalMilliseconds));
            gameStartTime=DateTime.Now;
        }

        private void ResetMouseClickedLocation()
        {
            mouseClickedLocation.X=-1;
            mouseClickedLocation.Y=-1;
        }

        private void DoGameloop()
        {
            while (((DateTime.Now-gameStartTime)<gameDuration) && !gameAborted)
            {
                Application.DoEvents();
                if (disc==null)
                {
                    if (DateTime.Now>nextDiscDue)
                    {
                        disc=new Disc(limits.X, limits.Y, rnd);
                        nrOfDiscs++;
                        ShowDisc(disc);                        
                    }
                }
                else
                {
                    if (disc.Age > maxDiscLifeTime)
                    {
                        ResetDisc();                       
                    }
                    else if (disc.IsHit(mouseClickedLocation))
                    {
                        UpdateScore(disc.Age);
                        ResetDisc();
                    }
                }
                UpdateUi();
            }
        }

        private void UpdateScore(TimeSpan age)
        {
            score++;
        }

        private void ResetDisc()
        {
            disc=null;
            nextDiscDue =DateTime.Now.AddMilliseconds(rnd.Next((int)maxDiscWaitTime.TotalMilliseconds)); ;
            ClearBox();
        }

        private void UpdateUi()
        {
            int progress = (int)((DateTime.Now-gameStartTime).Ticks*100/gameDuration.Ticks);
            SetProgress(progress<=100 ? progress : 100);
            SetScore(score);
        }

        private void FinishGame()
        {
            if (disc==null) return;
            ClearBox();
        }

        private void MainFormFormClosing(object sender, FormClosingEventArgs e)
        {
            gameAborted=true;
        }
    }
}
