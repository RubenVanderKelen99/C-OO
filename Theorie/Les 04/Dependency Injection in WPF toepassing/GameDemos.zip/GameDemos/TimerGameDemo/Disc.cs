﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimerGameDemo
{
    public class Disc
    {
        public const int Radius = 20;
        private readonly DateTime creationTime;
                
        public Point Location { get; set; }
        public TimeSpan Age { get => DateTime.Now-creationTime; }

        public Rectangle BoundingBox => new Rectangle(Location.X-Radius,Location.Y-Radius,Radius*2,Radius*2);

        public Disc(int maxX, int maxY, Random rnd)
        {
            this.Location=GetRandomLocation(maxX, maxY, rnd);
            creationTime=DateTime.Now;
        }

        private Point GetRandomLocation(int maxX, int maxY, Random rnd)
        {
            int X = Radius+rnd.Next(maxX-Radius*2);
            int Y = Radius+rnd.Next(maxY-Radius*2);
            return new Point(X, Y);
        }

        public bool IsHit(Point location)
        {
            return (this.DistanceSqr(location)<Radius*Radius);
        }

        private int DistanceSqr(Point location)
        {
            return (this.Location.X-location.X)*(this.Location.X-location.X)
                +(this.Location.Y-location.Y)*(this.Location.Y-location.Y);
        }


    }
}
