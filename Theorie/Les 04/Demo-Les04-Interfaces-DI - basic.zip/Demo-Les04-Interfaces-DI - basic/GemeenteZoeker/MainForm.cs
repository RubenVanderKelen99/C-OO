﻿
using Globals;
using System;
using System.Windows.Forms;

namespace GemeenteZoeker
{
    public partial class MainForm : Form
    {
        private readonly IDataProvider dataProvider;

        public MainForm(IDataProvider dataProvider)
        {
            InitializeComponent();
            this.dataProvider = dataProvider;
        }

        private void ZoekTextChanged(object sender, EventArgs e)
        {
            var result = dataProvider.GetMatchingResults(zoekBox.Text);
            resultBox.Lines = result?.ConvertAll(z => z.ToString()).ToArray();
        }
    }
}
