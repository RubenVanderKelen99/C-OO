﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Globals
{
    public class ZipInfo : IComparable<ZipInfo>
    {
        public int Zipcode { get; }
        public string Gemeente { get; }
        public string ExtraInfo { get; }

        public ZipInfo(int zipcode, string gemeente, string extraInfo)
        {
            this.Zipcode = zipcode;
            this.Gemeente = gemeente;
            this.ExtraInfo = extraInfo;
        }

        public override string ToString()
        {
            return $"{Zipcode} - {Gemeente} ({ExtraInfo})";
        }

        public int CompareTo(ZipInfo other)
        {
            return this.Gemeente.CompareTo(other.Gemeente);
        }
    }
}
