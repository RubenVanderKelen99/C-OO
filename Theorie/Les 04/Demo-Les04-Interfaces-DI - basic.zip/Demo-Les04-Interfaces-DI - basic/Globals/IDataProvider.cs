﻿using System.Collections.Generic;
using Globals;

namespace Globals
{
    public interface IDataProvider
    {
        List<ZipInfo> GetMatchingResults(string query);
    }
}