﻿using Globals;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datalaag
{


    internal class WebZipInfo: ZipInfo
    {

        public WebZipInfo(Postcode postcode)
               :base(Convert.ToInt32( postcode.postcode_deelgemeente),
                     postcode.naam_deelgemeente,
                     $"{postcode.region} - {postcode.longitude},{postcode.latitude}" )
        { }

    }

    internal class Postcode
    {
        public string postcode_deelgemeente { get; set; }
        public string naam_deelgemeente { get; set; }
        public string taal { get; set; }
        public string region { get; set; }
        public string longitude { get; set; }
        public string latitude { get; set; }
    }
}
