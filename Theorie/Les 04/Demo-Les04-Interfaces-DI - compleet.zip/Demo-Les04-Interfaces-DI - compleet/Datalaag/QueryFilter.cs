﻿using Globals;
using System.Collections.Generic;
using System.Linq;

namespace Datalaag
{
    public class QueryFilter : IDataProvider
    {

        private readonly IDataProvider dataprovider;

        public QueryFilter(IDataProvider dataprovider)
        {
            this.dataprovider = dataprovider;
        }
        public List<ZipInfo> GetMatchingResults(string query)
        {
            return dataprovider.GetMatchingResults(query).Where(z => z.ExtraInfo.ToUpper().Contains("VL")).ToList();

        }
    }
}
