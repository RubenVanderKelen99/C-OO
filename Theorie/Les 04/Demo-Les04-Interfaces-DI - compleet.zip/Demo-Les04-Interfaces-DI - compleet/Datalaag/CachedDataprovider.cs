﻿using Globals;
using System.Collections.Generic;

namespace Datalaag
{
    public class CachedDataprovider : IDataProvider
    {
        private readonly IDataProvider dataProvider;
        private readonly Dictionary<string, List<ZipInfo>> cache;

        public CachedDataprovider(IDataProvider dataProvider)
        {
            this.dataProvider = dataProvider;
            cache = new Dictionary<string, List<ZipInfo>>();
        }

        public List<ZipInfo> GetMatchingResults(string query)
        {
            if (!cache.ContainsKey(query)) cache.Add(query, dataProvider.GetMatchingResults(query));
            return cache[query];
        }
    }
}
