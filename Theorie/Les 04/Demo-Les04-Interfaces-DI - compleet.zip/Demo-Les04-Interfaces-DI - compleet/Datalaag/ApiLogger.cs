﻿using Globals;
using System;
using System.Collections.Generic;

namespace Datalaag
{
    public class ApiLogger : IDataProvider
    {

        private readonly IDataProvider dataprovider;

        public ApiLogger(IDataProvider dataprovider)
        {
            this.dataprovider = dataprovider;
        }

        public List<ZipInfo> GetMatchingResults(string query)
        {
            LogApiQuery(query);
            return dataprovider.GetMatchingResults(query);
        }

        private void LogApiQuery(string query)
        {
            Console.WriteLine($"{DateTime.Now.ToShortTimeString()} - {query}");
        }
    }
}
