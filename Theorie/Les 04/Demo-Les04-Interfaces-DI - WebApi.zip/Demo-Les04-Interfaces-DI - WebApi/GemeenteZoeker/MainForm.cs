﻿
using Datalaag;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GemeenteZoeker
{
    public partial class MainForm : Form
    {
        private readonly DataProvider dataProvider;

        public MainForm()
        {
            InitializeComponent();
            dataProvider = new DataProvider();
        }

        private void ZoekTextChanged(object sender, EventArgs e)
        {

            var result = dataProvider.GetMatchingResults(zoekBox.Text);
            resultBox.Lines = result?.ConvertAll(z => z.ToString()).ToArray();
        }
    }
}
