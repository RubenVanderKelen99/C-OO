﻿using Globals;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Datalaag
{
    public class DataProvider
    {

        private const string baseUri = "https://www.opzoeken-postcode.be/";

        public DataProvider()
        {            
        }
        
        public List<ZipInfo> GetMatchingResults(string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return new List<ZipInfo>();
            using (var httpClient = new HttpClient { BaseAddress = new Uri($"{baseUri}{query}.json") })
            {
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string parameters = string.Empty;
                var response = httpClient.GetAsync(parameters).Result;
                response.EnsureSuccessStatusCode();
                return  response.Content.ReadAsAsync<List<WebZipInfo>>().Result?.ConvertAll(x => (ZipInfo)x); 
            }
        }
    }
}
