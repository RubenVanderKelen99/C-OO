﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Demo_Les_10
{
    internal class ParallelLoopDemo
    {

        public void Run()
        {
            var list = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            Console.Write("\n Regular for loop: ");
            for (int i = 0; i < list.Count; i++)
            {
                Console.Write($"{list[i]},");
            }

            Console.Write("\n Parallel.For loop: ");
            Parallel.For(0, list.Count, (i) =>
            {
                Console.Write($"{list[i]},");
            });

            Console.Write("\n Parallel.Foreach loop: ");
            Parallel.ForEach(list, (element) =>
            {
                Console.Write($"{element},");
            });

            Console.WriteLine();
        }

        public void BreakDemo()
        {
            Parallel.For(0, 30, (index, state) =>
            {
                Console.Write($" {index}");
                if (index == 5) state.Stop();
            });                       
            Console.WriteLine();
        }

    }
}
