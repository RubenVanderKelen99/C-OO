﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Les_10
{
    class TaskCompetitionDemo
    {
        public void Run()
        {
            const long MAX = 500000;
            int Count = 0;

            var job = Task.Run(() =>
            {
                for (long i = 0; i < MAX; i++)
                {
                    Count--;
                }
            });

            for (long i = 0; i < MAX; i++)
            {
                Count++;
            }
            job.Wait();
            Console.WriteLine("Count Value: " + Count.ToString());
        }
    }
}
