﻿using System;
using System.Threading.Tasks;

namespace Demo_Les_10
{
    internal class TaskSynchronizationDemo
    {

        private static void NoLockDemo()
        {
            const long MAX = 500000;
            int Count = 0;

            var job = Task.Run(() =>
            {
                for (long i = 0; i < MAX; i++)
                {
                    Count--;
                }
            });

            for (long i = 0; i < MAX; i++)
            {
                Count++;
            }
            job.Wait();
            Console.WriteLine("Count Value (no lock): " + Count.ToString());
        }
        private static void LockDemo()
        {
            const long MAX = 500000;
            int Count = 0;
            object mutex = new object();
            var job = Task.Run(() =>
            {
                for (long i = 0; i < MAX; i++)
                {
                    lock (mutex)
                    {
                        Count--;
                    }
                }
            });
            for (long i = 0; i < MAX; i++)
            {
                lock (mutex)
                {
                    Count++;
                }
            }
            job.Wait();
            Console.WriteLine("Count Value (with lock): " + Count.ToString());
        }

        public void Run()
        {
            NoLockDemo();
            LockDemo();
        }

    }
}
