﻿using System;
using static System.Console;

namespace Demo_Les_10
{
    internal class Program
    {

        private static void PrintMenu()
        {
            WriteLine();
            WriteLine();
            WriteLine("Democode C# OO - Les O8");
            WriteLine();
            WriteLine("1.  Task Competition Demo");
            WriteLine("2.  Task Synchronisation Demo");
            WriteLine("3.  Concurrent use of generic List Demo");
            WriteLine("4.  Concurrent use of immutable List Demo");
            WriteLine("5.  Bad concurrent use of immutable List Demo");
            WriteLine("6.  Parallel Loop Demo");
            WriteLine("7.  Parallel Loop Break Demo");
            
            WriteLine("0.  Exit");
            WriteLine();
            Write("Geef je keuze in: ");
        }

        private static void Main()
        {
            bool exit = false;

            while (!exit)
            {
                PrintMenu();
                string input = ReadLine();
                WriteLine();
                switch (input[0])
                {
                    case '0':
                        {
                            exit = true;
                            break;
                        }
                    case '1':
                        {
                            new TaskCompetitionDemo().Run();
                            break;
                        }

                    case '2':
                        {
                            new TaskSynchronizationDemo().Run();
                            break;
                        }
                    case '3':
                        {
                            try { ImmutableCollectionDemo.GenericListConcurrentUseDemo(); }
                            catch (InvalidOperationException e) { Console.WriteLine($"Exception: {e.Message}"); }
                            break;
                        }
                    case '4':
                        {
                            ImmutableCollectionDemo.ImmutableListConcurrentUseDemo();
                            break;
                        }
                    case '5':
                        {
                            ImmutableCollectionDemo.ImmutableListConcurrentUseSyncDemo();
                            break;
                        }
                    case '6':
                        {
                            new ParallelLoopDemo().Run();
                            break;
                        }
                    case '7':
                        {
                            new ParallelLoopDemo().BreakDemo();
                            break;
                        }
                    

                    default:
                        {
                            // WriteLine("Invalid input, try again...");
                            break;
                        }
                }
            }


        }
    }
}
