﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Les_10
{
    public class ImmutableCollectionDemo
    {
        public static void GenericListConcurrentUseDemo()
        {
            // this will result in an exception as the background task is changing the 
            // list while the foreground thread is iterating over it.
            
            var list = new List<int>();
            Task.Run(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    list.Add(i);
                }
            });
            // wait for task to add at least 10 numbers
            while (list.Count <10) ;
            foreach (int item in list)
            {
                Console.Write($" {item}");
            }
            Console.WriteLine();        
        }

        public static void ImmutableListConcurrentUseDemo()
        {
            var list = ImmutableList<int>.Empty;

            Task.Run(() =>
            {
                for (int i = 0; i < 1000; i++)
                {
                    list = list.Add(i);
                }
            });
            // wait for task to add at least 10 numbers
            while (list.Count < 10) ;
            foreach (int item in list)
            {
                Console.Write($" {item}");
            }
            Console.WriteLine();
        }
        public static void ImmutableListConcurrentUseSyncDemo()
        {
            var list = ImmutableList<int>.Empty;

            // Bad code! 
            // Two tasks change the ImmutableList reference concurrently
            // Since there is no synchronisation, results are unpredictable

            Task.Run(() =>
            {
                for (int i = 0; i < 1000; i +=2)
                {
                    list = list.Add(i);
                }
            });
            Task.Run(() =>
            {
                for (int i = 1; i < 1000; i += 2)
                {
                    list = list.Add(i);
                }
            });
            // wait for task to add at least 10 numbers
            while (list.Count < 100) ;
            foreach (int item in list.Sort())
            {
                Console.Write($" {item}");
            }
            Console.WriteLine();
        }


    }
}
