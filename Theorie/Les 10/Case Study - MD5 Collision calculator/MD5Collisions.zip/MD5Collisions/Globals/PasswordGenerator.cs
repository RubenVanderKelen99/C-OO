﻿using System.Collections;
using System.Collections.Generic;

namespace Globals
{
    public class PasswordGenerator : IEnumerable<string>
    {
        private readonly int passwordLength;
        
        public ulong MaxCount { get; }

        public PasswordGenerator(int passwordLength)
        {
            this.passwordLength = passwordLength;
            ulong result = 1;
            for (int i = 0; i < passwordLength; i++)
            {
                result *= 26;
            }
            MaxCount = result;
        }

        public IEnumerator<string> GetEnumerator()
        {
            foreach (string password in GetPasswords(0, new char[passwordLength]))
            {
                yield return password;
            }
        }

        // Not used, just needed for IEnumerable implementation
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        private IEnumerable<string> GetPasswords(int index, char[] password)
        {
            if (index == passwordLength)
            {
                yield return new string(password);
            }
            else
            {
                for (char c = 'A'; c <= 'Z'; c++)
                {
                    password[index] = c;
                    foreach (string result in GetPasswords(index + 1, password))
                    {
                        yield return result;
                    }
                }
            }
        }
    }
}
