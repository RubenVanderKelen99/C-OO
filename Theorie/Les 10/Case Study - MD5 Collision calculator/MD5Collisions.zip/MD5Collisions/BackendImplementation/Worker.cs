﻿using Globals;
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BackendImplementation
{
    public class Worker : IWorker
    {
        public event Action<string> CollisionFound;
        public event Action<ulong> ProgressChanged;
        public event Action Stalled;

        private CancellationTokenSource cancelSource;
        private MD5 md5;

        public void Abort()
        {
            cancelSource.Cancel();
        }

        public void GetCollisions(string hash, ConcurrentQueue<string> buffer)
        {
            md5 = MD5.Create();
            cancelSource = new CancellationTokenSource();
            var cancelToken = cancelSource.Token;
            
            Task.Run(() => { Work(hash, buffer, cancelToken); }, cancelToken);
        }


        private void Work(
                            string hash,
                            ConcurrentQueue<string> buffer,
                            CancellationToken cancelToken)
        {
            var timer = new Stopwatch();
            timer.Restart();
            ulong count = 0;
            Console.WriteLine("worker started.");
            while (!cancelToken.IsCancellationRequested)
            {
                if (buffer.Count() == 0)
                {
                    Stalled?.Invoke(); 
                    Thread.Sleep(5);
                }
                if (buffer.TryDequeue(out string pw))
                {
                    count++;
                    //if (MD5Calculator.GetHash(pw) == hash)
                    if (GetHash(pw) == hash)
                    {
                        CollisionFound?.Invoke(pw);
                    }
                }
                if (!cancelToken.IsCancellationRequested)
                {
                    if (timer.ElapsedMilliseconds > 100)
                    {
                        ProgressChanged?.Invoke(count);
                        count = 0;
                        timer.Restart();
                    }
                }
            }
            ProgressChanged?.Invoke(count);
            Console.WriteLine("worker stopped.");
        }

        private string GetHash(string text)
        {
            byte[] data = md5.ComputeHash(Encoding.UTF8.GetBytes(text));
            var sBuilder = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }
            return sBuilder.ToString();
        }
    }
}
