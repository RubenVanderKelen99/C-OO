﻿using Globals;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BackendImplementation
{
    public class Generator : IGenerator
    {
        public event Action GeneratorFinished;
        public event Action<ulong> PasswordsGeneratedReport;
        public event Action Stalled;

        private PasswordGenerator pwGenerator;
        private CancellationTokenSource cancelSource;

        public void Abort()
        {
            cancelSource?.Cancel();
        }

        public void Close()
        {
            cancelSource?.Cancel();
        }

        public ulong MaxCount()
        {
            return pwGenerator.MaxCount;
        }

        public ConcurrentQueue<string> Start(int passWordLength, int maxQueueLength)
        {
            pwGenerator = new PasswordGenerator(passWordLength);
            var queue = new ConcurrentQueue<string>();
            cancelSource = new CancellationTokenSource();
            var cancelToken = cancelSource.Token;

            Task.Run(() => { GeneratePassWords(queue, pwGenerator, maxQueueLength, cancelToken); }, cancelToken);
            return queue;
        }

        // background task
        private void GeneratePassWords(
                                        ConcurrentQueue<string> queue,
                                        PasswordGenerator generator,
                                        int maxQueueLength,
                                        CancellationToken cancelToken)
        {
            var time = DateTime.Now;
            ulong count = 0;
            // will run in background task
            foreach (string pw in generator)
            {
                if (cancelToken.IsCancellationRequested) break;
                while ((queue.Count() >= maxQueueLength) && (!cancelToken.IsCancellationRequested))
                {
                    Stalled?.Invoke();
                    Thread.Sleep(5);
                }
                queue.Enqueue(pw);
                count++;
                var thisTime = DateTime.Now;
                if ((thisTime - time).Ticks / TimeSpan.TicksPerMillisecond > 50)
                {
                    time = thisTime;
                    // in background task
                    PasswordsGeneratedReport?.Invoke(count);
                }
            }
            if (!cancelToken.IsCancellationRequested) GeneratorFinished?.Invoke(); 
        }
    }
}
