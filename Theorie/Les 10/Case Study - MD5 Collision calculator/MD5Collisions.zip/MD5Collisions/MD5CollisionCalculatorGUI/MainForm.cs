﻿using Globals;
using System;
using System.Threading;
using System.Windows.Forms;

namespace MD5CollisionCalculatorGUI
{
    public partial class MainForm : Form
    {

        private readonly IMD5CollisionCalculator calculator;
        private readonly SynchronizationContext uiContext;

        public MainForm(IMD5CollisionCalculator md5Calculator)
        {
            InitializeComponent();
            uiContext = SynchronizationContext.Current;
            DisableRunningUI();
            calculator = md5Calculator;
            workerNumericUpDown.Value = calculator.NrOfWorkerTasks;
            calculator.PercentageTestedReport += OnCalculatorProgressChanged;
            calculator.CollisionFound += OnCalculatorCollisionFound;
            calculator.StatisticsUpdated += OnCalculatorStatisticsUpdated;
        }

        private void OnCalculatorStatisticsUpdated()
        {
            uiContext.Post((c) =>
            {
                hashesPerSecondTextBox.Text = $"{calculator.PassWordsTestedPerSecond:N0}";
                runningTimeTextBox.Text = calculator.TimeRunning.ToString(@"dd\.hh\:mm\:ss");
                leftTimeTextBox.Text = calculator.EstimatedTimeLeft.ToString(@"dd\.hh\:mm\:ss");
                generatorStallsTextBox.Text = $"{calculator.GeneratorStallsperSecond:N0}";
                workerStallsTextBox.Text = $"{calculator.WorkerStallsPerSecond:N0}";
            }, null);
        }

        private void OnCalculatorCollisionFound(string collision)
        {
            uiContext.Post((c) =>
            {
                collisionTextBox.Text = collision;
            }, null);
        }

        private void OnCalculatorProgressChanged(decimal percent)
        {
            uiContext.Post((c) =>
            {
                progressBar.Value = (int)percent;
                progressTextBox.Text = $"{percent:F}%";
                if (percent >= 100)
                {
                    DisableRunningUI();
                }
            }, null);
        }

        private void EnableRunningUI()
        {
            abortButton.Enabled = true;
            hashButton.Enabled = false;
            startButton.Enabled = false;
            progressTextBox.Enabled = true;
            progressBar.Enabled = true;
            runningTimeTextBox.Enabled = true;
            leftTimeTextBox.Enabled = true;
            workerStallsTextBox.Enabled = true;
            generatorStallsTextBox.Enabled = true;
            combinationsTextBox.Enabled = true;
            collisionTextBox.Text = "";
        }


        private void DisableRunningUI()
        {
            abortButton.Enabled = false;
            hashButton.Enabled = true;
            startButton.Enabled = true;
            progressTextBox.Enabled = false;
            progressBar.Enabled = false;
            progressBar.Value = 0;
            runningTimeTextBox.Enabled = false;
            leftTimeTextBox.Enabled = false;
            leftTimeTextBox.Text = string.Empty;
            workerStallsTextBox.Enabled = false;
            generatorStallsTextBox.Enabled = false;
            combinationsTextBox.Enabled = false;
        }

        private void HashButtonClick(object sender, EventArgs e)
        {
            passwordTextBox.Text = passwordTextBox.Text.ToUpper();
            hashTextBox.Text = calculator.GetMD5Hash(passwordTextBox.Text);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            calculator.PercentageTestedReport -= OnCalculatorProgressChanged;
            calculator.CollisionFound -= OnCalculatorCollisionFound;
            calculator.StatisticsUpdated -= OnCalculatorStatisticsUpdated;
            calculator.Close();
        }

        private void OnAbortButtonClick(object sender, EventArgs e)
        {
            DisableRunningUI();
            calculator.Abort();
        }

        private void OnWorkerNumericUpDownValueChanged(object sender, EventArgs e)
        {
            calculator.NrOfWorkerTasks = (int)workerNumericUpDown.Value;
        }

        private void OnStartButtonClick(object sender, EventArgs e)
        {
            EnableRunningUI();
            calculator.StartCalculatingMD5Collision(hashTextBox.Text, passwordTextBox.Text.Length);
            combinationsTextBox.Text = $"{calculator.NrOfCombinations:N0}";
        }

        private void OnPasswordTextBoxTextChanged(object sender, EventArgs e)
        {
            hashTextBox.Text = string.Empty;
        }
    }
}
