﻿namespace MD5CollisionCalculatorGUI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.hashTextBox = new System.Windows.Forms.TextBox();
            this.hashButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.abortButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.collisionTextBox = new System.Windows.Forms.TextBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.progressTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.leftTimeTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.generatorStallsTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.workerStallsTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.workerNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.runningTimeTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.combinationsTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.hashesPerSecondTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.workerNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordTextBox.Location = new System.Drawing.Point(98, 32);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(258, 24);
            this.passwordTextBox.TabIndex = 0;
            this.passwordTextBox.TextChanged += new System.EventHandler(this.OnPasswordTextBoxTextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Hash:";
            // 
            // hashTextBox
            // 
            this.hashTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hashTextBox.Location = new System.Drawing.Point(98, 71);
            this.hashTextBox.Name = "hashTextBox";
            this.hashTextBox.Size = new System.Drawing.Size(258, 24);
            this.hashTextBox.TabIndex = 3;
            // 
            // hashButton
            // 
            this.hashButton.Location = new System.Drawing.Point(399, 32);
            this.hashButton.Name = "hashButton";
            this.hashButton.Size = new System.Drawing.Size(141, 27);
            this.hashButton.TabIndex = 4;
            this.hashButton.Text = "Calculate Hash";
            this.hashButton.UseVisualStyleBackColor = true;
            this.hashButton.Click += new System.EventHandler(this.HashButtonClick);
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(399, 70);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(141, 29);
            this.startButton.TabIndex = 5;
            this.startButton.Text = "Search Collision";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.OnStartButtonClick);
            // 
            // abortButton
            // 
            this.abortButton.Location = new System.Drawing.Point(399, 152);
            this.abortButton.Name = "abortButton";
            this.abortButton.Size = new System.Drawing.Size(139, 29);
            this.abortButton.TabIndex = 6;
            this.abortButton.Text = "Abort";
            this.abortButton.UseVisualStyleBackColor = true;
            this.abortButton.Click += new System.EventHandler(this.OnAbortButtonClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Collision:";
            // 
            // collisionTextBox
            // 
            this.collisionTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collisionTextBox.Location = new System.Drawing.Point(98, 153);
            this.collisionTextBox.Name = "collisionTextBox";
            this.collisionTextBox.Size = new System.Drawing.Size(258, 24);
            this.collisionTextBox.TabIndex = 8;
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(99, 198);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(441, 22);
            this.progressBar.Step = 1;
            this.progressBar.TabIndex = 9;
            // 
            // progressTextBox
            // 
            this.progressTextBox.Location = new System.Drawing.Point(19, 199);
            this.progressTextBox.Name = "progressTextBox";
            this.progressTextBox.ReadOnly = true;
            this.progressTextBox.Size = new System.Drawing.Size(73, 20);
            this.progressTextBox.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 244);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Time running:";
            // 
            // leftTimeTextBox
            // 
            this.leftTimeTextBox.Location = new System.Drawing.Point(368, 241);
            this.leftTimeTextBox.Name = "leftTimeTextBox";
            this.leftTimeTextBox.ReadOnly = true;
            this.leftTimeTextBox.Size = new System.Drawing.Size(172, 20);
            this.leftTimeTextBox.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 279);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "generator stalls/sec:";
            // 
            // generatorStallsTextBox
            // 
            this.generatorStallsTextBox.Location = new System.Drawing.Point(123, 276);
            this.generatorStallsTextBox.Name = "generatorStallsTextBox";
            this.generatorStallsTextBox.ReadOnly = true;
            this.generatorStallsTextBox.Size = new System.Drawing.Size(145, 20);
            this.generatorStallsTextBox.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "worker stalls/sec:";
            // 
            // workerStallsTextBox
            // 
            this.workerStallsTextBox.Location = new System.Drawing.Point(123, 314);
            this.workerStallsTextBox.Name = "workerStallsTextBox";
            this.workerStallsTextBox.ReadOnly = true;
            this.workerStallsTextBox.Size = new System.Drawing.Size(145, 20);
            this.workerStallsTextBox.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(409, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 17);
            this.label7.TabIndex = 17;
            this.label7.Text = "# Workers:";
            // 
            // workerNumericUpDown
            // 
            this.workerNumericUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.workerNumericUpDown.Location = new System.Drawing.Point(492, 111);
            this.workerNumericUpDown.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.workerNumericUpDown.Name = "workerNumericUpDown";
            this.workerNumericUpDown.Size = new System.Drawing.Size(47, 23);
            this.workerNumericUpDown.TabIndex = 18;
            this.workerNumericUpDown.ValueChanged += new System.EventHandler(this.OnWorkerNumericUpDownValueChanged);
            // 
            // runningTimeTextBox
            // 
            this.runningTimeTextBox.Location = new System.Drawing.Point(121, 241);
            this.runningTimeTextBox.Name = "runningTimeTextBox";
            this.runningTimeTextBox.ReadOnly = true;
            this.runningTimeTextBox.Size = new System.Drawing.Size(147, 20);
            this.runningTimeTextBox.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(285, 244);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Time left (max):";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(283, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "# combinations:";
            // 
            // combinationsTextBox
            // 
            this.combinationsTextBox.Location = new System.Drawing.Point(366, 314);
            this.combinationsTextBox.Name = "combinationsTextBox";
            this.combinationsTextBox.ReadOnly = true;
            this.combinationsTextBox.Size = new System.Drawing.Size(172, 20);
            this.combinationsTextBox.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(285, 279);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "hashes/sec:";
            // 
            // hashesPerSecondTextBox
            // 
            this.hashesPerSecondTextBox.Location = new System.Drawing.Point(368, 276);
            this.hashesPerSecondTextBox.Name = "hashesPerSecondTextBox";
            this.hashesPerSecondTextBox.ReadOnly = true;
            this.hashesPerSecondTextBox.Size = new System.Drawing.Size(172, 20);
            this.hashesPerSecondTextBox.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 359);
            this.Controls.Add(this.hashesPerSecondTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.combinationsTextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.runningTimeTextBox);
            this.Controls.Add(this.workerNumericUpDown);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.workerStallsTextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.generatorStallsTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.leftTimeTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.progressTextBox);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.collisionTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.abortButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.hashButton);
            this.Controls.Add(this.hashTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.passwordTextBox);
            this.Name = "Form1";
            this.Text = "MD5 Collision Calculator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.workerNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox hashTextBox;
        private System.Windows.Forms.Button hashButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button abortButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox collisionTextBox;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.TextBox progressTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox leftTimeTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox generatorStallsTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox workerStallsTextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown workerNumericUpDown;
        private System.Windows.Forms.TextBox runningTimeTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox combinationsTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox hashesPerSecondTextBox;
    }
}

