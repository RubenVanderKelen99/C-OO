﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Globals;

namespace LogicImplementation
{
    public class MD5CollisionCalculator : IMD5CollisionCalculator
    {
        private const int maxQueueLength = 1000000;

        private readonly IGenerator generator;
        private readonly Func<IWorker> getWorker;
        private readonly List<IWorker> workerList;
        private readonly object mutex;

        private bool running;
        private int nrOfWorkerTasks;
        private ConcurrentQueue<string> queue;
        private string hash;
        private Timer timer;
        private ulong nrOfPassWordsProcessed;
        private DateTime previousTime;
        private ulong nrOfNewPassWordsProcessed;
        private long generatorStalls;
        private DateTime lastGeneratorStallTime;
        private long workerStalls;
        private DateTime lastWorkerStallTime;
        private DateTime timeStarted;

        public int NrOfWorkerTasks
        {
            get
            {
                return nrOfWorkerTasks;
            }

            set
            {
                if (running)
                {
                    while (value > nrOfWorkerTasks)
                    {
                        AddWorker();
                        nrOfWorkerTasks++;
                    }
                    while (value < nrOfWorkerTasks)
                    {
                        RemoveWorker();
                        nrOfWorkerTasks--;
                    }
                }
                nrOfWorkerTasks = value;
            }
        }

        public TimeSpan EstimatedTimeLeft
        {
            get
            {
                ulong nrOfPassWordsLeft = generator.MaxCount() - nrOfPassWordsProcessed;
                ulong secondsLeft = PassWordsTestedPerSecond != 0 ? nrOfPassWordsLeft / (ulong)PassWordsTestedPerSecond : 0;
                var timeLeft = new TimeSpan((long)(secondsLeft * TimeSpan.TicksPerSecond));
                return timeLeft;
            }
        }


        public long WorkerStallsPerSecond
        {
            get
            {
                var thisTime = DateTime.Now;
                long result = 0;
                if ((thisTime - lastWorkerStallTime).Ticks != 0)
                {
                    result = workerStalls * TimeSpan.TicksPerSecond / (thisTime - lastWorkerStallTime).Ticks;
                }
                lastWorkerStallTime = thisTime;
                workerStalls = 0;
                return result;
            }
        }

        public long GeneratorStallsperSecond
        {
            get
            {
                var thisTime = DateTime.Now;
                long result = 0;
                if ((thisTime - lastWorkerStallTime).Ticks != 0)
                {
                    result = generatorStalls * TimeSpan.TicksPerSecond / (thisTime - lastGeneratorStallTime).Ticks;
                }
                lastGeneratorStallTime = thisTime;
                generatorStalls = 0;
                return result;
            }
        }

        public TimeSpan TimeRunning
        {
            get
            {
                return DateTime.Now - timeStarted;
            }
        }

        public ulong NrOfCombinations
        {
            get
            {
                return running ? generator.MaxCount() : 0;
            }
        }

        public long PassWordsTestedPerSecond { get; private set; }

        public event Action<string> CollisionFound;
        public event Action<decimal> PercentageTestedReport;
        public event Action StatisticsUpdated;

        public MD5CollisionCalculator(IGenerator generator, Func<IWorker> getWorker)
        {
            this.generator = generator;
            this.getWorker = getWorker;
            nrOfWorkerTasks = 1;
            running = false;
            mutex = new object();
            workerList = new List<IWorker>();            
            generator.GeneratorFinished += OnGeneratorGeneratorFinished;
            generator.Stalled += OnGeneratorStalled;            
        }
           

        public void Abort()
        {
            generator.Abort();
            while (workerList.Count > 0) RemoveWorker();
            timer.Change(Timeout.Infinite, Timeout.Infinite);
            running = false;
        }

        public void Close()
        {
            generator.GeneratorFinished -= OnGeneratorGeneratorFinished;
            generator.Stalled -= OnGeneratorStalled;
            generator.Close();
            foreach (var worker in workerList)
            {
                worker.Stalled -= OnWorkerStalled;
                worker.CollisionFound -= OnWorkerCollisionFound;
                worker.ProgressChanged -= OnWorkerProgressChanged;
                worker.Abort();
            }
        }

        public void StartCalculatingMD5Collision(string hash, int passwordLength)
        {
            this.hash = hash;
            nrOfPassWordsProcessed = 0;
            nrOfNewPassWordsProcessed = 0;
            var thisTime = DateTime.Now;
            previousTime = thisTime;
            generatorStalls = 0;
            lastGeneratorStallTime= thisTime;
            workerStalls = 0;;
            lastWorkerStallTime = thisTime;
            timeStarted = thisTime;
            IProgress<int> progress = new Progress<int>((dummy) => { TimerTick(); });
            timer = new Timer((dummy) => { progress.Report(0); }, null, Timeout.Infinite, Timeout.Infinite);
            timer.Change(200, 200);

            // start generator
            queue = generator.Start(passwordLength,maxQueueLength);
            running = true;
            // and start workers
            for (int i = 0; i < NrOfWorkerTasks; i++)
            {
                AddWorker();
            }
        }

        private void AddWorker()
        {
            var worker = getWorker();
            worker.Stalled += OnWorkerStalled;
            worker.CollisionFound += OnWorkerCollisionFound;
            worker.ProgressChanged += OnWorkerProgressChanged;
            worker.GetCollisions(hash, queue);
            workerList.Add(worker);           
        }

        private void RemoveWorker()
        {
            workerList[0].Abort();
            workerList.RemoveAt(0);          
        }

        private void OnWorkerCollisionFound(string passWord)
        {
            CollisionFound?.Invoke(passWord);
        }

        private void TimerTick()
        {
            var thisTime = DateTime.Now;
            if ((thisTime - previousTime).Ticks != 0)
            {
                PassWordsTestedPerSecond = (long)(nrOfNewPassWordsProcessed * TimeSpan.TicksPerSecond / (ulong)(thisTime - previousTime).Ticks);
            }
            lock (mutex)
            {
                nrOfNewPassWordsProcessed = 0;
            }
            previousTime = thisTime;
            StatisticsUpdated?.Invoke();
        }

        private void OnWorkerProgressChanged(ulong hashesCalculated)
        {
            lock (mutex)
            {
                nrOfPassWordsProcessed += hashesCalculated;
                nrOfNewPassWordsProcessed += hashesCalculated;                
                PercentageTestedReport?.Invoke(100M*nrOfPassWordsProcessed/generator.MaxCount());
            }
        }

        private void OnWorkerStalled()
        {
            Interlocked.Increment(ref workerStalls);       
        }

        private void OnGeneratorStalled()
        {
           Interlocked.Increment(ref generatorStalls);          
        }

        private void OnGeneratorGeneratorFinished()
        {
            while (queue.Count > 0) Thread.Sleep(2);            
            Abort();
        }

        public string GetMD5Hash(string text)
        {
            return MD5Calculator.GetHash(text); 
        }
    }
}
