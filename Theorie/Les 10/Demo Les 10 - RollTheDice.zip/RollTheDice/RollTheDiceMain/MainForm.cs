﻿using Globals;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;

namespace RollTheDiceMain
{
    public partial class MainForm:Form
    {
        private readonly ILogic logic;
        private readonly SynchronizationContext context;
        private long totalIterations = 0;
        private readonly Timer timer;
        private DateTime previousTimerEvent;
        private long previousIterations;

        public MainForm(ILogic logic)
        {
            this.logic = logic;
            context = SynchronizationContext.Current;
            timer = new Timer
            {
                Interval = 1000
            };
            timer.Tick += TimerTick;
            InitializeComponent();
            SetRunningState(false);
            iterationsTextBox.Text = "0";
            valuesTextBox.Text = string.Empty;
            logic.ValuesChanged += OnLogicValuesChanged;
        }

        private void TimerTick(object sender, EventArgs e)
        {
            var interval = DateTime.Now - previousTimerEvent;
            long delta = totalIterations - previousIterations;
            speedLabel.Text = $"( {delta/interval.TotalSeconds:N0}/s )";
            previousIterations = totalIterations;
            previousTimerEvent = DateTime.Now;
        }

        private void OnLogicValuesChanged(long iterations)
        {
            context.Post(
                 (dummy) =>
                 {
                     totalIterations += iterations;                    
                     iterationsTextBox.Text = $"  {totalIterations:N0}";
                     valuesTextBox.Lines = ConvertValuesToStringArray(logic.Values, totalIterations);
                 }
                 , null);
        }

        private static string[] ConvertValuesToStringArray(ConcurrentDictionary<int, long> values, long iterations)
        {
            var list = new List<string>();
            for(int i = 3; i < 19; i++)
            {
                list.Add($"{i,3}: {(double)values[i] / iterations,6:P2} ({values[i],11:N0})");
            }
            return list.ToArray();
        }

        private void SetRunningState(bool running)
        {
            startButton.Enabled = !running;
            stopButton.Enabled = running;
        }

        private void OnstartButtonClick(object sender, EventArgs e)
        {
            SetRunningState(true);
            logic.Start();
            previousTimerEvent = DateTime.Now;
            previousIterations = 0;
            timer.Start();
        }

        private void StopButtonClick(object sender, EventArgs e)
        {
            logic.Stop();
            SetRunningState(false);
            timer.Stop();
            speedLabel.Text = string.Empty;
        }

        private void OnMainFormClosing(object sender, FormClosingEventArgs e)
        {
            timer.Dispose();
        }
    }
}
