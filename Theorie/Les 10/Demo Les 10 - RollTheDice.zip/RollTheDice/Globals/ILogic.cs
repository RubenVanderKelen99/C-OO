﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Globals
{
    public interface ILogic
    {
        ConcurrentDictionary<int,long> Values { get;}

        void Start();

        void Stop();

        void Calculate(CancellationToken token);

        event Action<long> ValuesChanged;

    }
}
