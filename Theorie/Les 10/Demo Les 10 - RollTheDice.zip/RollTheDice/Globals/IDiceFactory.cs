﻿namespace Globals
{
    public interface IDiceFactory
    {
        IDice CreateDice();
    }
}