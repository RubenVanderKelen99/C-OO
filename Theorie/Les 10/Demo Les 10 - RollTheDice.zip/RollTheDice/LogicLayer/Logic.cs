﻿using Globals;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;

namespace LogicLayer
{
    public class Logic:ILogic
    {
        const int nrOfTasks = 3;
        const int interval = 100;
        private CancellationTokenSource cancelSource;
        private readonly IDiceFactory diceFactory;
        private Task[] tasks;

        public ConcurrentDictionary<int, long> Values { get; private set; }

        public event Action<long> ValuesChanged;

        public Logic(IDiceFactory diceFactory)
        {
            this.diceFactory = diceFactory;
            ResetValues();
        }

        private void ResetValues()
        {
            Values = new ConcurrentDictionary<int, long>();
            for(int i = 3; i < 19; i++)
            {
                Values.TryAdd(i, 0);
            }
        }

        public void Start()
        {
            ResetValues();
            cancelSource = new CancellationTokenSource();
            var cancelToken = cancelSource.Token;
            tasks = new Task[nrOfTasks];
            for (int i = 0; i < nrOfTasks; i++)
            {
                tasks[i] = Task.Run(() => Calculate(cancelToken), cancelToken);
            }
        }

        public void Stop()
        {   
            cancelSource?.Cancel();
            Task.WaitAll(tasks);
        }

        
        public void Calculate(CancellationToken token)
        {
            var dice = diceFactory.CreateDice();
            long iterations=0;
            var time = DateTime.Now;
            while(!token.IsCancellationRequested)
            {
                int newValue = dice.SingleValue() + dice.SingleValue() + dice.SingleValue();
                Values[newValue]++;
                iterations++;
                if((DateTime.Now - time).TotalMilliseconds > interval)
                {
                    time = DateTime.Now;
                    ValuesChanged?.Invoke(iterations);
                    iterations = 0;
                }
            }
            ValuesChanged?.Invoke(iterations);
        }        
    }
}
