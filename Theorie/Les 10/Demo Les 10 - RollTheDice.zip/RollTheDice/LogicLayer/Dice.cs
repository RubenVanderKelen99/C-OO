﻿using Globals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicLayer
{
    public class Dice:IDice
    {
        private readonly Random random;
               
        public Dice()
        {
            random = new Random();
        }
               
        public int SingleValue()
        {          
            return random.Next(1, 7);
        }
    }
}
