﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Globals;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;

namespace UnitTests
{
    public static class TestValues
    {
        private static List<string> nodeList = new List<string>();
        private static Random random = new Random();

        public static string GetUniqueName()
        {
            string name;
            do
            {
                name = GetName();
            } while (nodeList.Contains(name));
            nodeList.Add(name);
            return name;
        }

        private static string GetName()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string digits = "0123456789";
            string textPart = new string(Enumerable.Repeat(chars, 4).Select(s => s[random.Next(s.Length)]).ToArray());
            string digitPart = new string(Enumerable.Repeat(digits, 3).Select(s => s[random.Next(s.Length)]).ToArray());
            return textPart + digitPart;
        }

        public static int GetRandomScore()
        {
            return random.Next(11);
        }
    }


    [TestClass]
    public class GlobalTests
    {
        #region auxiliary methods

        private void CheckProperty(Type t, string propName, Type[] propTypes, bool hasGetter, bool hasSetter)
        {
            var props = t.GetProperties();
            var prop = props.Where(p => p.Name == propName).FirstOrDefault();
            Assert.IsNotNull(prop, $"{t.GetType().Name} has no public \"{propName}\" property");
            Assert.IsTrue(Array.Exists(propTypes, p => p.Name == prop.PropertyType.Name),
                              $"{t.FullName}: property {propName} is a {prop.PropertyType.Name}");
            Assert.IsTrue((prop.CanRead == hasGetter), $"{t.Name}: property \"{propName}\" has {(prop.CanRead ? "a" : "no")} public Getter ");
            Assert.IsTrue((prop.CanWrite == hasSetter), $"{t.Name}: property \"{propName}\" has {(prop.CanWrite ? "a" : "no")} public Setter ");

        }

        private void CheckMethod(Type t, string methodName, Type[] returnTypes, Type[] parameterTypes)
        {
            var methods = t.GetMethods();
            // check if method exists with right signature
            var method = methods.Where(m =>
            {
                if (m.Name != methodName) return false;
                var parameters = m.GetParameters();
                if ((parameterTypes == null || parameterTypes.Length == 0)) return parameters.Length == 0;
                if (parameters.Length != parameterTypes.Length) return false;
                for (int i = 0; i < parameterTypes.Length; i++)
                {
                    // if (parameters[i].ParameterType != parameterTypes[i])
                    if (!parameters[i].ParameterType.IsAssignableFrom(parameterTypes[i]))
                        return false;
                }
                return true;
            }).FirstOrDefault();
            Assert.IsNotNull(method, $"{t.FullName} has no public \"{methodName}\" method with the right signature");

            // check returnType
            Assert.IsTrue(Array.Exists(returnTypes, r => r.Name == method.ReturnType.Name),
                              $"{t.FullName}: method \"{methodName}\" returns a \"{method.ReturnType.Name}\"");
        }

        #endregion auxiliary methods


        [TestMethod, Timeout(500)]
        public void TestEnumOccurence()
        {
            var expectedValues = new string[] { "Obscure", "Common", "Popular" };
            var x = typeof(Occurence);
            Assert.IsTrue((x.IsEnum), $"\"Grades\" is not an enum type.");
            var values = Enum.GetNames(x).ToList();
            Assert.IsTrue((values.Count == expectedValues.Length),
                              $"Enum type \"Grades\" should have {expectedValues.Length} values, not {values.Count}.");
            foreach (var value in expectedValues)
            {
                Assert.IsTrue((values.Contains(value)), $"Enum type \"Grades\" should contain \"{value}\" as a value.");
            }
        }

        [TestMethod, Timeout(500)]
        public void TestMovieScoreCtor()
        {
            Type x = typeof(MovieScore);
            var constructor = x.GetConstructor(new Type[] { });
            Assert.IsNull(constructor,
                $"\"nMovieScore\" has a default constructor (not allowed)!");
            constructor = x.GetConstructor(new Type[] { typeof(string), typeof(int) });
            Assert.IsNotNull(constructor,
                $"\"nMovieScore\" does not contain an constructor with parameters of type \'string\' & \'int\'.");
            // check if can be instantiated with valid parameters;
            var dummy = new MovieScore("test", 1);
            Assert.IsTrue((dummy.NrOfVotes == 1),
                              $"\"NrOfVotes\" property for \"MovieScore\" has wrong value after instantiation: expected 1, was \"{dummy.NrOfVotes}\" )");
            // check if exceptions are thrown with invalid params
            try
            {
                dummy = new MovieScore("test", -1);
                Assert.Fail($"Constructor for \"nMovieScore\" does not throw ArgumentOutOfRangeException for negative scores.");
            }
            catch (ArgumentOutOfRangeException)
            {
                // this is expected, no problem                
            }
            catch (AssertFailedException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                Assert.Fail($"Constructor for \"nMovieScore\" with negative score throws {e.GetType().Name} instead of ArgumentOutOfRangeException !");
            }

            try
            {
                dummy = new MovieScore("test", 11);
                Assert.Fail($"Constructor for \"nMovieScore\" does not throw ArgumentOutOfRangeException for score > 10.");
            }
            catch (ArgumentOutOfRangeException)
            {
                // this is expected, no problem                
            }
            catch (AssertFailedException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                Assert.Fail($"Constructor for \"nMovieScore\" with score > 10 throws {e.GetType().Name} instead of ArgumentOutOfRangeException !");
            }

        }

        [TestMethod, Timeout(500)]
        public void TestMovieProperties()
        {
            var testName = TestValues.GetUniqueName();
            var dummy = new MovieScore(testName, 5);
            Assert.IsTrue((dummy.Name == testName),
                              $"\"Name\" property for \"MovieScore\" does not return the value passed to the constructor (expected \"{testName}\", was \"{dummy.Name}\" )");
      
            int testScore = TestValues.GetRandomScore();
            dummy = new MovieScore(testName, testScore);
            Assert.IsTrue((dummy.TotalScore is int),
                              $"\"TotalScore\" property for \"MovieScore\" is of type \"{dummy.TotalScore.GetType().Name}\", should be \"int\" )");
            Assert.IsTrue((Math.Abs(dummy.TotalScore - testScore) < 0.001),
                              $"\"TotalScore\" property for \"MovieScore\" does not return the value passed to the constructor (expected \"{testScore}\", was \"{dummy.TotalScore}\" )");
            Assert.IsTrue((dummy.AverageScore is double),
                              $"\"AverageScore\" property for \"MovieScore\" is of type \"{dummy.AverageScore.GetType().Name}\", should be \"double\" )");
            Assert.IsTrue((Math.Abs(dummy.AverageScore - testScore) < 0.001),
                              $"\"AverageScore\" property for \"MovieScore\" does not return the value passed to the constructor (expected \"{1.0 * testScore:F1}\", was \"{dummy.AverageScore:F1}\" )");

        }

        [TestMethod, Timeout(500)]
        public void TestMovieScorePopularityProperty()
        {
            int[] scoreList = new int[] { 2, 4, 6, 7, 11,13 };
            var popularityList = new Occurence[] { Occurence.Obscure, Occurence.Obscure, Occurence.Common, Occurence.Common, Occurence.Popular, Occurence.Popular };
            for (int i = 0; i < scoreList.Length; i++)
            {
                var testName = TestValues.GetUniqueName();
                var dummy = new MovieScore(testName, TestValues.GetRandomScore());
                for (var j = 0; j < scoreList[i]-1; j++)
                {
                    dummy.AddVote(TestValues.GetRandomScore());                    
                }
                Assert.IsTrue((dummy.Popularity == popularityList[i]),
                                  $"\"Popularity\" property for \"MovieScore\" has wrong value for popularity of {dummy.NrOfVotes}: is \"{dummy.Popularity}\", should be \"{popularityList[i]}\" )");
            }
        }
                
        [TestMethod, Timeout(500)]
        public void TestMovieScoreAddScoreMethod()
        {
            int[] testScores = new int[10];
            for (int i = 0; i < testScores.Length; i++)
            {
                testScores[i] = TestValues.GetRandomScore();
            }
            var dummy = new MovieScore(TestValues.GetUniqueName(), testScores[0]);
            for (int i = 1; i < testScores.Length; i++)
            {
                dummy.AddVote(testScores[i]);
                Assert.IsTrue((dummy.NrOfVotes == i + 1),
                              $"\"AddScore\" method for \"MovieScore\" does not increment NrOfParticipants: expected {i + 1}, was \"{dummy.NrOfVotes}\" )");
            }
            Assert.IsTrue(((dummy.AverageScore - testScores.Average(i => (float)i) < 0.001)),
                              $"\"Score\" property for \"MovieScore\" has wrong value after calling \"AddScore\": expected \"{testScores.Average(i => (float)i):F1}\", was \"{dummy.AverageScore:F1}\" )");
            Assert.IsTrue((dummy.TotalScore == testScores.Sum()),
                              $"\"Score\" property for \"MovieScore\" has wrong value after calling \"AddScore\": expected \"{testScores.Sum()}\", was \"{dummy.TotalScore}\" )");

        }

        [TestMethod, Timeout(500)]
        public void TestMovieScoreCompareToMethod()
        {
            var vote1 = new MovieScore(TestValues.GetUniqueName(), 2);
            var vote2 = new MovieScore(TestValues.GetUniqueName(), 5);
            var vote3 = new MovieScore(TestValues.GetUniqueName(), 5);
            var vote4 = new MovieScore(TestValues.GetUniqueName(), 8);

            Assert.IsTrue((vote1.CompareTo(vote2) == vote1.TotalScore.CompareTo(vote2.TotalScore)),
                  $"\"CompareTo\" method for \"MovieScore\" returns wrong value: \"{vote1.TotalScore}\" & \"{vote2.TotalScore}\" returns \"{vote1.CompareTo(vote2)}\": expected \"{vote1.TotalScore.CompareTo(vote2.TotalScore)}\" )");
            Assert.IsTrue((vote2.CompareTo(vote3) == vote2.TotalScore.CompareTo(vote3.TotalScore)),
                  $"\"CompareTo\" method for \"MovieScore\" returns wrong value: \"{vote2.TotalScore}\" & \"{vote3.TotalScore}\" returns \"{vote2.CompareTo(vote3)}\": expected \"{vote2.TotalScore.CompareTo(vote3.TotalScore)}\" )");
            Assert.IsTrue((vote3.CompareTo(vote4) == vote3.TotalScore.CompareTo(vote4.TotalScore)),
                  $"\"CompareTo\" method for \"MovieScore\" returns wrong value: \"{vote3.TotalScore}\" & \"{vote4.TotalScore}\" returns \"{vote3.CompareTo(vote4)}\": expected \"{vote3.TotalScore.CompareTo(vote4.TotalScore)}\" )");

        }

        [TestMethod, Timeout(500)]
        public void TestMovieScoreToStringMethod()
        {
            var name = TestValues.GetUniqueName();
            int[] testScores = new int[12];
            for (int i = 0; i < testScores.Length; i++)
            {
                testScores[i] = TestValues.GetRandomScore();
            }
            var dummy = new MovieScore(name, testScores[0]);
            for (int i = 1; i < testScores.Length; i++)
            {
                dummy.AddVote(testScores[i]);
            }
            var text = dummy.ToString();
            var total = testScores.Sum();
            Assert.IsTrue((text.ToLower().Contains(name.ToLower())),
                             $"result from \"ToString\" method for \"MovieScore\" does not contain name: \"{dummy.ToString()}\", name was \"{name}\".");
            Assert.IsTrue((text.Contains($"{total}")),
                             $"result from \"ToString\" method for \"MovieScore\" does not contain score: \"{dummy.ToString()}\", score was \"{total}\".");           
            Assert.IsTrue((text.Contains($"{dummy.Popularity}")),
                             $"result from \"ToString\" method for \"MovieScore\" does not contain grade: \"{dummy.ToString()}\", grade was \"{dummy.Popularity}\".");
            Assert.IsTrue((text.Contains($"{dummy.NrOfVotes}")),
                             $"result from \"ToString\" method for \"MovieScore\" does not contain number of particopants: \"{dummy.ToString()}\", is missing \"{dummy.NrOfVotes}\".");
        }

       
    }
}
