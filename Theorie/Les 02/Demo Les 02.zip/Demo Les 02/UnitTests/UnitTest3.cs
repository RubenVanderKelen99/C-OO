﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Globals;
using DataLayer;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using MovieRankingMain;

namespace UnitTests
{


    [TestClass]
    public class Architectuur
    {
       
        #region auxiliary methods

        private void CheckProperty(Type t, string propName, Type[] propTypes, bool hasGetter, bool hasSetter)
        {
            var props = t.GetProperties();
            var prop = props.Where(p => p.Name == propName).FirstOrDefault();
            Assert.IsNotNull(prop, $"{t.GetType().Name} has no public \"{propName}\" property");
            Assert.IsTrue(Array.Exists(propTypes, p => p.Name == prop.PropertyType.Name),
                              $"{t.FullName}: property {propName} is a {prop.PropertyType.Name}");
            Assert.IsTrue((prop.CanRead == hasGetter), $"{t.Name}: property \"{propName}\" has {(prop.CanRead ? "a" : "no")} public Getter ");
            Assert.IsTrue((prop.CanWrite == hasSetter), $"{t.Name}: property \"{propName}\" has {(prop.CanWrite ? "a" : "no")} public Setter ");

        }

        private void CheckMethod(Type t, string methodName, Type[] returnTypes, Type[] parameterTypes)
        {
            var methods = t.GetMethods();
            // check if method exists with right signature
            var method = methods.Where(m =>
            {
                if(m.Name != methodName) return false;
                var parameters = m.GetParameters();
                if((parameterTypes == null || parameterTypes.Length == 0)) return parameters.Length == 0;
                if(parameters.Length != parameterTypes.Length) return false;
                for(int i = 0; i < parameterTypes.Length; i++)
                {
                    // if (parameters[i].ParameterType != parameterTypes[i])
                    if(!parameters[i].ParameterType.IsAssignableFrom(parameterTypes[i]))
                        return false;
                }
                return true;
            }).FirstOrDefault();
            Assert.IsNotNull(method, $"{t.FullName} has no public \"{methodName}\" method with the right signature");

            // check returnType
            Assert.IsTrue(Array.Exists(returnTypes, r => r.Name == method.ReturnType.Name),
                              $"{t.FullName}: method \"{methodName}\" returns a \"{method.ReturnType.Name}\"");
        }


        #endregion auxiliary methods


        [TestMethod, Timeout(500)]
        public void TestGlobalStructure()
        {
            Type x = typeof(MainForm);
            ConstructorInfo constructor = x.GetConstructor(new Type[] { typeof(IDataAccess) });
            Assert.IsNotNull(constructor,
                $"Constructor for \"MainForm\" does not take IDataAccess parameter.");
            constructor = x.GetConstructor(new Type[] { });
            Assert.IsNull(constructor,
                $"\"MainForm\" has a default constructor (not allowed).");
        
            var fields = typeof(MainForm).GetFields();
            var OK = (fields.Where(f => f.FieldType == typeof(IDataAccess)).Count() == 0);
            Assert.IsTrue(OK, $"\"MainForm\" uses a public field to store \"IDataAccess\" reference (must be private).");
            fields = typeof(MainForm).GetFields(BindingFlags.NonPublic |
                         BindingFlags.Instance);
            OK = (fields.Where(f => f.FieldType == typeof(IDataAccess)).Count() > 0);
            Assert.IsTrue(OK, $"\"MainForm\" does not have a private field to store ILogic reference).");

            IDataAccess dal = new DataAccessImplementation() as IDataAccess;
            Assert.IsNotNull(dal,
                $"DataAccessLayerTests - Class \"DataAccessImplementation\" does not implement interface \"IDataAccess\".");

            x = typeof(IDataAccess);
            Assert.IsNotNull(x, $"interface \"IDataAccess\" not declared!");
            CheckMethod(x, "ImportVotes", new Type[] { typeof(void) }, new Type[] { typeof(string) });
            CheckMethod(x, "AddMovieVote", new Type[] { typeof(void) }, new Type[] { typeof(string), typeof(int) });
            CheckProperty(x, "SortedMovieList", new Type[] { typeof(List<MovieScore>) }, true, false);

        }
    }
}
