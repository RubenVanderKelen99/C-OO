﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Globals;
using DataLayer;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Collections.Generic;

namespace UnitTests
{
    [TestClass]
    public class DataAccessLayerTests

    {
       
      
        [TestMethod, Timeout(500)]
        public void TestAddCourseScoreMethodWorks()
        {
            IDataAccess dal = new DataAccessImplementation();
            Assert.IsNotNull(dal.SortedMovieList,
               $"DataAccessLayerTests - property \"SortedMovieList\" is null after instantiation.");
            Assert.IsTrue((dal.SortedMovieList.Count == 0),
                $"DataAccessLayerTests - property \"SortedMovieList\" is not empty after instantiation.");

            var testName1 = TestValues.GetUniqueName();
            var testScore1A = TestValues.GetRandomScore();
            var testScore1B = TestValues.GetRandomScore();
            var testName2 = TestValues.GetUniqueName();
            var testScore2 = TestValues.GetRandomScore();
            dal.AddMovieVote(testName1, testScore1A);
            Assert.IsTrue((dal.SortedMovieList.Count == 1),
                $"DataAccessLayerTests - property \"SortedMovieList\" has wrong number of entries after adding one movie vote: expected {1}, was {dal.SortedMovieList.Count()}.");
            dal.AddMovieVote(testName1, testScore1B);
            Assert.IsTrue((dal.SortedMovieList.Count == 1),
                $"DataAccessLayerTests - property \"SortedMovieList\" has wrong number of entries after adding two votes for same movie: expected {1}, was {dal.SortedMovieList.Count()}.");
            Assert.IsTrue((dal.SortedMovieList.First().NrOfVotes == 2),
                $"DataAccessLayerTests - property \"SortedMovieList\" has wrong number of votes in entry after adding two votes for same movie: expected {2}, was {dal.SortedMovieList.First().NrOfVotes}.");
            Assert.IsTrue((dal.SortedMovieList.First().TotalScore == (testScore1A+testScore1B)),
                $"DataAccessLayerTests - property \"SortedMovieList\" has wrong TotalScore in entry after adding two votes for same movie: expected {(testScore1A + testScore1B)}, was {dal.SortedMovieList.First().TotalScore}.");
            dal.AddMovieVote(testName2, testScore2);
            Assert.IsTrue((dal.SortedMovieList.Count == 2),
                $"DataAccessLayerTests - property \"SortedMovieList\" has wrong number of entries after adding two different movies: expected {2}, was {dal.SortedMovieList.Count()}.");
        }

        [TestMethod, Timeout(500)]
        public void TestAddCourseScoreMethodIsCaseInsensitive()
        {
            IDataAccess dal = new DataAccessImplementation();
            var testName = TestValues.GetUniqueName().ToUpper();
            var testScore = TestValues.GetRandomScore();
            dal.AddMovieVote(testName, testScore);
            dal.AddMovieVote(testName.ToLower(), testScore);
            Assert.IsFalse((dal.SortedMovieList.Count == 2),
                $"DataAccessLayerTests - property \"SortedCourseList\" method \"AddCourseScore\" is case sensitive for course name.");
        }

        [TestMethod, Timeout(500)]
        public void TestImportScoresMethod()
        {
            const string filename = "testdata.csv";
            var testName = TestValues.GetUniqueName();
            var testScore = TestValues.GetRandomScore();
            if (testScore > 8) testScore -= 2;

            string[] lines = new string[10];
            lines[0] = $"{testName}, {testScore}";
            for (int i = 1; i < lines.Length; i++)
            {
                lines[i] = $"{TestValues.GetUniqueName()}, {TestValues.GetRandomScore()}";
            }
            lines[5] = $"{testName}, {testScore+2}";
            File.WriteAllLines(filename, lines);

            IDataAccess dal = new DataAccessImplementation();
            dal.ImportVotes(filename);
            Assert.IsTrue((dal.SortedMovieList.Count == lines.Length-1),
                $"DataAccessLayerTests - property \"SortedMovieList\" has wrong number of entries after adding movie votes: expected {lines.Length - 1}, was {dal.SortedMovieList.Count()}.");
            var names = dal.SortedMovieList.Select(r => r.Name.ToLower());
            for (int i = 0; i < lines.Length; i++)
            {
                var name = lines[i].Split(',')[0].ToLower();
                Assert.IsTrue((names.Contains(name)),
                            $"DataAccessLayerTests - after importing file, a moviee name is missing from property \"SortedMovieList\": expected {name}.");
            }
            var result = dal.SortedMovieList.Where(r => r.Name.ToLower() == testName.ToLower()).First();
            Assert.IsTrue((Math.Abs(result.AverageScore - testScore - 1) < 0.001),
                $"DataAccessLayerTests - after importing file, property \"SortedMovieList\" returns wrong average score for a movie (\"{testName}\"): was {result.AverageScore:F1}, expected {testScore + 1.0:F1}.");
        }

        [TestMethod, Timeout(500)]
        public void TestSortedCourseListpropertyIsSorted()
        {
            IDataAccess dal = new DataAccessImplementation();
            var testName = TestValues.GetUniqueName();
            var testScore = TestValues.GetRandomScore();
            dal.AddMovieVote(testName, testScore);
            for (int i = 1; i < 10; i++)
            {
                dal.AddMovieVote(TestValues.GetUniqueName(), TestValues.GetRandomScore());
            }           
                       
            var scores = dal.SortedMovieList.Select(r => r.TotalScore).ToArray();
            for (int i = 1; i < scores.Length; i++)
            {
                Assert.IsTrue((scores[i].CompareTo(scores[i-1]) <= 0),
                $"DataAccessLayerTests - property \"SortedMovieList\" is not sorted in descending order on TotalScores.");
            }


        }

       
    }
}
