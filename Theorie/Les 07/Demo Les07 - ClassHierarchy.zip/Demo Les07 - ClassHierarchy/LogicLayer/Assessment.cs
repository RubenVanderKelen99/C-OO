﻿using Globals.Entities;
using Globals.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LogicLayer
{
    public class Assessment : IAsssessment
    {
        private readonly List<QuestionBase> questions;

        public IReadOnlyList<QuestionBase> Questions => questions.AsReadOnly();
        public int MaxScore { get; }
        public int ActualScore
        {
            get
            {
                int score = 0;
                foreach (var question in questions) score += question.Score;
                return score;
            }
        }

        public Assessment(IQuestionStore questionStore)
        {
            // create assessment questionList by choosing a number of questions from each category randomly
            // for the demo: just select first question for each category

            questions = new List<QuestionBase>();
            foreach (var category in questionStore.QuestionPool.Keys)
            {
                var question = questionStore.QuestionPool[category].First();
                questions.Add(question);
            }

            MaxScore = 0;
            foreach (var question in questions) MaxScore += question.MaxScore;
        }

    }
}
