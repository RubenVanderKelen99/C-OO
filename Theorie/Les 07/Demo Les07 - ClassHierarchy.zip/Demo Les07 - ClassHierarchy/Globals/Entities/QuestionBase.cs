﻿using Globals.Enums;
using Newtonsoft.Json;

namespace Globals.Entities
{
    public abstract class QuestionBase
    {
        // 'Score' & 'AnswerText' should not be serialized to the questionFile 
        // since they are not ment to be filled in when reading from file.

        // example of a 'readonly' property: can only be initialized from the constructor 
        public Category Category { get; }
        public int MaxScore { get; }

        [JsonIgnore]
        public virtual int Score { get; protected set; }

        // example of a 'readonly' property: can only be initialized from the constructor 
        public string QuestionText { get; }

        [JsonIgnore]
        public abstract string AnswerText { get; set; }

        public QuestionBase(Category category, string questionText, int maxScore)
        {
            Category = category;
            QuestionText = questionText;
            MaxScore = maxScore;
        }

        public virtual void ResetScore()
        {
            Score = 0;
        }
    }
}
