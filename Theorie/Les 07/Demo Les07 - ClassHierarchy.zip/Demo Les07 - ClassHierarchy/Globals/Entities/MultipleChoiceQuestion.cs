﻿using Globals.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Globals.Entities
{
    public class MultipleChoiceQuestion : QuestionBase
    {
        // correctIndex should be private, but read from questionfile, so make it a Jsonproperty
        [JsonProperty]
        private readonly int correctIndex;

        private int selectedIndex;
        private bool answerSet = false;

        public IReadOnlyList<string> QuestionItems { get; }

        public override string AnswerText
        {
            get => answerSet ? QuestionItems[SelectedIndex] : string.Empty;
            set => throw new InvalidOperationException("AnswerText for MultipleChoice Question cannot be set externally");
        }

        [JsonIgnore]
        public int SelectedIndex
        {
            get => selectedIndex;
            set
            {
                answerSet = true;
                selectedIndex = value;
                base.Score = SelectedIndex == correctIndex ? MaxScore : 0;
            }
        }

        public MultipleChoiceQuestion(Category category,
                                      string questionText,
                                      int maxScore,
                                      List<string> questionItems,
                                      int correctIndex) : base(category, questionText, maxScore)
        {
            QuestionItems = questionItems.AsReadOnly();
            this.correctIndex = correctIndex;
        }

        public override void ResetScore()
        {
            base.ResetScore();
            answerSet = false;
            selectedIndex = 0;
        }

    }
}
