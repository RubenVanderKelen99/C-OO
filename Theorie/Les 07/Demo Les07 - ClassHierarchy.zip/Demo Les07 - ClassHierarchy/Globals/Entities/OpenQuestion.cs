﻿using Globals.Enums;

namespace Globals.Entities
{
    public class OpenQuestion : QuestionBase
    {
        public override string AnswerText { get; set; }

        public OpenQuestion(Category category, string questionText, int maxScore) : base(category, questionText, maxScore)
        {
        }

        public void SetScore(int score)
        {
            base.Score = score;
        }
    }
}
