﻿using Globals.Entities;
using Globals.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Globals.Interfaces
{
    public interface IQuestionStore
    {
        ReadOnlyDictionary<Category, List<QuestionBase>> QuestionPool { get; }
    }
}
