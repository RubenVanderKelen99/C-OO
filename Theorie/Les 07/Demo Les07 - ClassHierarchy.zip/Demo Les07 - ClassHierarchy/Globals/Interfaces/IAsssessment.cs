﻿using Globals.Entities;
using System.Collections.Generic;

namespace Globals.Interfaces
{
    public interface IAsssessment
    {
        IReadOnlyList<QuestionBase> Questions { get; }
        int MaxScore { get; }
        int ActualScore { get; }

    }
}
