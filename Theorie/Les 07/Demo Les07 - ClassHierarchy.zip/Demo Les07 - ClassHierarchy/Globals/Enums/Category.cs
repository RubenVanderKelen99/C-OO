﻿namespace Globals.Enums
{
    public enum Category
    {
        Easy,
        Medium,
        Hard
    }
}
