﻿using Globals.Entities;
using Globals.Enums;
using Globals.Interfaces;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;

namespace DataLayer
{
    public class QuestionStore : IQuestionStore
    {
        private const string questionFilename = "questions.json";

        private Dictionary<Category, List<QuestionBase>> questionPool;
        private ReadOnlyDictionary<Category, List<QuestionBase>> readOnlyQuestionPool;
        public ReadOnlyDictionary<Category, List<QuestionBase>> QuestionPool => readOnlyQuestionPool;

        public QuestionStore()
        {
            if (!File.Exists(questionFilename)) CreateQuestions();
            ReadQuestions();

        }

        private void ReadQuestions()
        {
            var formatter = new JsonSerializer { TypeNameHandling = TypeNameHandling.Auto };
            using (var file = new StreamReader(questionFilename))
            {
                questionPool = (Dictionary<Category, List<QuestionBase>>)formatter.Deserialize(file, typeof(Dictionary<Category, List<QuestionBase>>));
            }
            readOnlyQuestionPool = new ReadOnlyDictionary<Category, List<QuestionBase>>(questionPool);
        }

        private void StoreQuestions()
        {
            var formatter = new JsonSerializer { TypeNameHandling = TypeNameHandling.Auto }; ;
            using (var file = File.CreateText(questionFilename))
            {
                formatter.Serialize(file, questionPool);
                file.Flush();
            }
        }



        private void CreateQuestions()
        {
            GenerateQuestions();
            StoreQuestions();
        }


        private void GenerateQuestions()
        {
            questionPool = new Dictionary<Category, List<QuestionBase>>
            {
                {
                    Category.Easy, new List<QuestionBase>
                    {
                        new OpenQuestion(Category.Easy,"Geef om het even welk antwoord:",10) ,
                    }
                },
                {
                    Category.Medium,new List<QuestionBase>
                    {
                        new MultipleChoiceQuestion(Category.Medium,"Wat is geen priemgetal?",
                                                   10,
                                                   new List<string>{"5","12","17" },
                                                   1)
                    }
                },
                {
                    Category.Hard,new List<QuestionBase>
                    {
                        new OpenQuestion(Category.Hard,"Wat is het antwoord op de ultieme vraag over het leven, het universum en alles?",10),
                        new MultipleChoiceQuestion(Category.Hard,"Voor welk probleem wordt een beslissingsboom gebruikt bij Machine Learning?",
                                                   10,
                                                   new List<string>{"Regressie","Clustering","Kwalificatie" },
                                                   2)
                    }
                }
            };
        }
    }
}
