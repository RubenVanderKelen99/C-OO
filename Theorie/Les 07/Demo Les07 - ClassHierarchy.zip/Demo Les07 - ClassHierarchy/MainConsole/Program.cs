﻿using DataLayer;
using Globals.Interfaces;
using LogicLayer;
using MainConsole.ConsoleUi;

namespace MainConsole
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            IQuestionStore questionStore = new QuestionStore();
            IAsssessment assessment = new Assessment(questionStore);
            var session = new AssessmentConsoleUi(assessment);
            session.Run();
        }
    }
}
