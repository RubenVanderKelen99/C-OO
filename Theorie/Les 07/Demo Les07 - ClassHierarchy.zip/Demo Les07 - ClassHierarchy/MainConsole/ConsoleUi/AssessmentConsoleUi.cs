﻿using Globals.Entities;
using Globals.Interfaces;
using MainConsole.Entities;
using MainConsole.Interfaces;
using System;
using System.Collections.Generic;

namespace MainConsole.ConsoleUi
{
    public class AssessmentConsoleUi
    {
        private readonly IAsssessment assessment;
        private List<IPresentationModel> questionList = new List<IPresentationModel>();

        public AssessmentConsoleUi(IAsssessment assessment)
        {
            this.assessment = assessment;
            ConstructQuestionPresentationList();
        }

        private void ConstructQuestionPresentationList()
        {
            foreach (var question in assessment.Questions)
            {
                switch (question)
                {
                    case OpenQuestion q:
                        {
                            questionList.Add(new OpenQuestionPresentationModel(q));
                            break;
                        }

                    case MultipleChoiceQuestion q:
                        {
                            questionList.Add(new MultipleChoiceQuestionPresentationModel(q));
                            break;
                        }

                    default: break;
                }
            }
        }

        public void Run()
        {
            ShowStartBanner();
            TakeAssessment();
            ShowEndBanner();
        }

        private void TakeAssessment()
        {
            foreach (var question in questionList)
            {
                question.PresentQuestion();
                question.GetAnswer();
            }
        }

        private void ShowEndBanner()
        {
            // this is for demo only: open questions are not scored, so will return score of 0

            Console.WriteLine($"\nje score is: {assessment.ActualScore}/{assessment.MaxScore}\n");
            Console.WriteLine("<enter> om af te sluiten");
            Console.ReadLine();
        }

        private void ShowStartBanner()
        {
            Console.WriteLine("Demo assessment");
            Console.WriteLine("===============\n");
        }
    }
}
