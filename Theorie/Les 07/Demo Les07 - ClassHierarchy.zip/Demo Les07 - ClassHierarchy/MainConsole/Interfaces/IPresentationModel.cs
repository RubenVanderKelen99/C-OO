﻿namespace MainConsole.Interfaces
{
    public interface IPresentationModel
    {
        void PresentQuestion();
        void GetAnswer();
    }
}
