﻿using Globals.Entities;
using System;

namespace MainConsole.Entities
{
    public class MultipleChoiceQuestionPresentationModel : QuestionPresentationModelBase
    {
        private MultipleChoiceQuestion question;
        public MultipleChoiceQuestionPresentationModel(MultipleChoiceQuestion question) : base(question)
        {
            this.question = base.Question as MultipleChoiceQuestion;
        }

        public override void PresentQuestion()
        {
            Console.WriteLine($"{question.QuestionText}\n\n");
            for (int i = 0; i < question.QuestionItems.Count; i++)
            {
                Console.WriteLine($"{i + 1} : {question.QuestionItems[i]}");
            }
        }
        public override void GetAnswer()
        {
            int index = 0; ;
            string answer;
            do
            {
                Console.Write("\n Geef een volgnummer in: ");
                answer = Console.ReadLine();
            }
            while ((!int.TryParse(answer, out index) || (index < 0) || (index > question.QuestionItems.Count)));
            question.SelectedIndex = index - 1;
            Console.WriteLine("\n");
        }
    }
}
