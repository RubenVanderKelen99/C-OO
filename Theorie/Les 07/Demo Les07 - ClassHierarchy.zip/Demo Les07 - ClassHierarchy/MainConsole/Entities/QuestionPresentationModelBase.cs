﻿using Globals.Entities;
using MainConsole.Interfaces;
using System;

namespace MainConsole.Entities
{
    public abstract class QuestionPresentationModelBase : IPresentationModel
    {
        public QuestionBase Question { get; }

        public QuestionPresentationModelBase(QuestionBase question)
        {
            Question = question;
        }

        public abstract void GetAnswer();

        public virtual void PresentQuestion()
        {
            Console.WriteLine(Question.QuestionText);
            Console.WriteLine();
        }

    }
}
