﻿using Globals.Entities;
using System;

namespace MainConsole.Entities
{
    public class OpenQuestionPresentationModel : QuestionPresentationModelBase
    {
        public OpenQuestionPresentationModel(OpenQuestion question) : base(question)
        {
        }

        public override void GetAnswer()
        {
            Console.Write("? ");
            Question.AnswerText = Console.ReadLine();
            Console.WriteLine("\n");
        }

    }
}
