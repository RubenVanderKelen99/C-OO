﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace FileIO
{
    class Program
    {
        
        static void Main()
        {
          new ConsoleUi().Run();
        }
    }
}
