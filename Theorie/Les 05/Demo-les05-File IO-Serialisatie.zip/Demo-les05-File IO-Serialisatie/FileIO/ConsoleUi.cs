﻿using static System.Console;

namespace FileIO
{
    public class ConsoleUi
    {
        public void Run()
        {
            bool exit = false;
            while (!exit)
            {
                PrintMenu();
                string input = ReadLine();
                WriteLine();
                switch (input[0])
                {
                    case '0':
                        {
                            exit = true;
                            break;
                        }
                    case '1':
                        {
                            var demo1 = new InfoDemo();
                            demo1.DriveInfoDemo();
                            demo1.DirectoryInfoDemo();
                            demo1.FileInfoDemo();
                            break;
                        }
                    case '2':
                        {
                            var demo2 = new StreamDemo();
                            demo2.StreamReaderDemo1();
                            break;
                        }
                    case '3':
                        {
                            var demo3 = new SerializeDemo();
                            demo3.InitializeSerialisationDemo();
                            demo3.BinarySerializeDemo();
                            break;
                        }
                    case '4':
                        {
                            var demo3 = new SerializeDemo();
                            demo3.InitializeSerialisationDemo();
                            demo3.XMLSerializerDemo();
                            break;
                        }
                    case '5':
                        {
                            var demo3 = new SerializeDemo();
                            demo3.InitializeSerialisationDemo();
                            demo3.JSONSerializerDemo();
                            break;
                        }

                    default:
                        {
                            WriteLine("Invalid input, try again...");
                            break;
                        }
                }
            }
        }
        
        private void PrintMenu()
        {
            WriteLine();
            WriteLine();
            WriteLine("Democode C# OO - Les O2");
            WriteLine();
            WriteLine("1.  Demo for DriveInfo, DirectoryInfo, FileInfo");
            WriteLine("2.  Streamreader Demo");
            WriteLine("3.  Demo for binary serialisation");
            WriteLine("4.  Demo for XML serialisation");
            WriteLine("5.  Demo for JSON serialisation");
            WriteLine("0.  Exit");
            WriteLine();
            Write("Geef je keuze in: ");
        }



    }
}
