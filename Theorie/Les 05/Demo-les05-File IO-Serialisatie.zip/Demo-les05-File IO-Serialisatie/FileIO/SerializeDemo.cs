﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace FileIO
{
    [Serializable]
    public class Course
    {
        public enum CourseCategorie { lecture, lab, project }
        public string Name { get; set; }
        public CourseCategorie Category { get; set; }

    }

    [Serializable]
    public class Student
    {
        public string Name { get; set; }
        public List<Course> Courses { get; set; }
    }


    public class SerializeDemo
    {
        public List<Student> Studenten { get; set; }

        public void InitializeSerialisationDemo()
        {
            Console.WriteLine("Generating 2 students and 3 courses...\n");
            var Courses = new Course[]
            {
                new Course() { Name = "Math",  Category = Course.CourseCategorie.lecture },
                new Course() { Name = "Programming",  Category = Course.CourseCategorie.lab },
                new Course() { Name = "Project",  Category = Course.CourseCategorie.project }
            };
            Studenten = new List<Student>()
            {
                new Student() { Name = "John", Courses= new List<Course>() {Courses[0], Courses[2]} },
                new Student() { Name = "Alice", Courses= new List<Course>() {Courses[1], Courses[2], Courses[0]} }
            };
        }

        public void BinarySerializeDemo()
        {
            Console.WriteLine("Serializing students to binary file...");
            var formatter = new BinaryFormatter();
            using var bestand = File.OpenWrite("students.bin");
            formatter.Serialize(bestand, Studenten);

            Console.WriteLine("Deserializing students from binary file...");
            using var bestand2 = File.OpenRead("students.bin");
            var studentenKopie = (List<Student>)formatter.Deserialize(bestand2);
            Console.WriteLine($"    {studentenKopie.Count} students read from file.");

        }

        public void XMLSerializerDemo()
        {
            Console.WriteLine("Serializing students to XML Stream in memory...\n");
            var formatter = new XmlSerializer(typeof(List<Student>));
            using var stream = new MemoryStream();

            formatter.Serialize(stream, Studenten);
            stream.Seek(0, SeekOrigin.Begin);

            using var reader = new StreamReader(stream);

            // To deserialize:
            // var studentenKopie = (List<Student>)formatter.Deserialize(reader);

            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                Console.WriteLine(line);
            }
            Console.WriteLine();
        }

        public void JSONSerializerDemo()
        {
            Console.WriteLine("Serializing students to JSON Stream in memory...\n");
            var formatter = new JsonSerializer();
            using var stream = new MemoryStream();
            using var sr = new StreamWriter(stream);
            formatter.Serialize(sr, Studenten);
            // JSON serializer does not flush its StreamWriter when finished!
            // so do it explicitly
            sr.Flush();
            stream.Seek(0, SeekOrigin.Begin);

            using var reader = new StreamReader(stream);
            // To Deserialize:
            //var studentenKopie = (List<Student>)formatter.Deserialize(reader, typeof(List<Student>));

            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                Console.WriteLine(line);
            }
            Console.WriteLine();
        }

    }
}
