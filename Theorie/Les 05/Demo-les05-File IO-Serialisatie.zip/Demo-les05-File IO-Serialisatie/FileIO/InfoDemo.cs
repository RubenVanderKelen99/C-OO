﻿using System;
using System.IO;

namespace FileIO
{
    internal class InfoDemo
    {

        public void DriveInfoDemo()
        {
            // get available DriveInfo object for all availabkle drives
            Console.WriteLine("Available drives");
            var drives = DriveInfo.GetDrives();
            foreach (var drive in drives)
            {
                Console.Write($"    {drive.Name}: ");
                try
                {
                    Console.WriteLine($"{drive.TotalFreeSpace / (float)drive.TotalSize:P3} used space");
                }
                catch
                {
                    Console.WriteLine("not available");
                }
            }
            Console.WriteLine("");
        }

        public void DirectoryInfoDemo()
        {
            Console.WriteLine("Directory demo");
            Console.WriteLine("");
            var di1 = new DirectoryInfo(@"c:\MyDir\temp");
            var di2 = new DirectoryInfo(@"c:\MyDir\temp2");
            var di3 = new DirectoryInfo(@"c:\MyDir");
            // Create the directories.
            Console.WriteLine($"Creating {di1.Name}...");
            di1.Create();
            Console.WriteLine($"Creating {di2.Name}...");
            di2.Create();

            // List all directories in C:\Mydir
            Console.WriteLine($"Directories under {di3.Name}");
            foreach (var dir in di3.EnumerateDirectories())
            {
                Console.WriteLine($"   {dir.Name}");
            }
            Console.WriteLine("");
            // delete these directories
            try
            {
                // This operation will not be allowed because there are subdirectories.
                Console.WriteLine("I am about to attempt to delete {0}.", di3.Name);
                di3.Delete();
                Console.WriteLine("The Delete operation was successful, which was unexpected.");
            }
            catch (Exception)
            {
                Console.WriteLine("The Delete operation failed as expected.");
                // now delete with "recursive=true"
                di3.Delete(true);
                Console.WriteLine("The Delete operation was successful when deleting recursively.");
            }
            Console.WriteLine("");
        }

        public void FileInfoDemo()
        {
            // list all files in C:\
            Console.WriteLine(@"Files under C:\");
            foreach (string fileName in Directory.EnumerateFiles(@"c:\"))
            {
                var fileInfo = new FileInfo(fileName);
                Console.WriteLine($"   {fileInfo.Name,-20} - {fileInfo.Length,10} bytes - created: {fileInfo.CreationTime}");
            }
            Console.WriteLine("");
        }

    }
}
