﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net.Sockets;
using System.IO.Compression;

namespace FileIO
{
    class StreamDemo
    {
        public void StreamReaderDemo1()
        {
            Console.WriteLine("The content of file TestFile.txt\n");
            StreamReader sr = null;
            try
            {
                sr = new StreamReader(@"Resources\TestFile.txt");
                string line;
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine();
                    Console.WriteLine(line);
                }
            }
            catch (Exception e)
            {               
                Console.WriteLine($"The file could not be read:{e.Message}");             
            }
            finally
            {
                if (sr != null) sr.Dispose(); 
            }
            Console.WriteLine();
        }

        public void StreamReaderDemo2()
        {
            try
            {
                // The using statement also disposes the StreamReader.
                using var sr = new StreamReader(@"..\..\TestFile.txt");
                string line;
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine();
                    Console.WriteLine(line);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"The file could not be read:{e.Message}");
            }
                        
        }

    }
}
