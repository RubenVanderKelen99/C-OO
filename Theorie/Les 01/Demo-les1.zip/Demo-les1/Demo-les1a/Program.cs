﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_les1a
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("BinDec");
            Console.WriteLine("------\n");
            string input;
            do
            {
                Console.Write("Getal: ");
                input=Console.ReadLine();
                if (input=="") break;
                if (input.StartsWith("b"))
                {
                    int number = Convert.ToInt32(input.Substring(1), 2);
                    Console.WriteLine($"--> {number}");
                }
                else
                {
                    int number = Convert.ToInt32(input);
                    string binary = Convert.ToString(number, 2);
                    Console.WriteLine($"--> b{ binary}");
                }               
            }
            while (input!="");

            Console.WriteLine("Druk nog een keer op <enter> om af te sluiten.");
            Console.ReadLine();
        }
    }
}
