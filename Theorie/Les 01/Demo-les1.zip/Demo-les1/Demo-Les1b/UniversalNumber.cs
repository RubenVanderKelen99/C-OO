﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Les1b
{
    public class UniversalNumber
    {
        public string Result;

        public UniversalNumber(string input)
        {
            if (input.StartsWith("b"))
            {
                int number = Convert.ToInt32(input.Substring(1), 2);
                Result = $"--> {number}";
            }
            else
            {
                int number = Convert.ToInt32(input);
                Result = $"--> b{Convert.ToString(number, 2)}";
            }
        }

    }
}
