﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Les1b
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("BinDec");
            Console.WriteLine("------\n");
            string input;
            do
            {
                Console.Write("Getal: ");
                input=Console.ReadLine();
                if (input=="") break;
                var number = new UniversalNumber(input);
                number.Result="onzin";
                Console.WriteLine(number.Result);
            }
            while (input!="");

            Console.WriteLine("Druk nog een keer op <enter> om af te sluiten.");
            Console.ReadLine();
        }
    }
}
