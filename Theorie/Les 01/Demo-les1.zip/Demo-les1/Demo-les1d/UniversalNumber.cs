﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_les1d
{
    public class UniversalNumber
    {
        // getter- & setter: C# style : using properties

        private string result;

        // full property

        public string Result
        {
            get
            {
                return result;
            }
            private set
            {
                result=value;
            }
        }


        //// expression bodied property
        //
        //public string Result
        //{
        //    get => result;
        //    private set => result=value;
        //}


        //// auto-implemented property

        //public string Result { get; private set; }


        public UniversalNumber(string input)
        {
            if (input.StartsWith("b"))
            {
                int number = Convert.ToInt32(input.Substring(1), 2);
                Result = $"--> {number}";
            }
            else
            {
                int number = Convert.ToInt32(input);
                Result =$"--> b{Convert.ToString(number, 2)}";
            }
        }       

    }
}
