﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Les1c
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("BinDec");
            Console.WriteLine("------\n");
            string input;
            do
            {
                Console.Write("Getal: ");
                input=Console.ReadLine();
                if (input=="")
                    break;
                var number = new UniversalNumber(input);                
                Console.WriteLine(number.GetResult());
            }
            while (input!="");

            Console.WriteLine("Druk nog een keer op <enter> om af te sluiten.");
            Console.ReadLine();
        }
    }
}
