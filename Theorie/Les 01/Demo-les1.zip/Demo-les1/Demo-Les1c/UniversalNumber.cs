﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Les1c
{
    public class UniversalNumber
    {
        // getter- & setter: Java-style

        private string result;

        public UniversalNumber(string input)
        {
            if (input.StartsWith("b"))
            {
                int number = Convert.ToInt32(input.Substring(1), 2);
                SetResult($"--> {number}");
            }
            else
            {
                int number = Convert.ToInt32(input);
                SetResult($"--> b{Convert.ToString(number, 2)}");
            }
        }

        public string GetResult()
        {
           return result;
        }

        private void SetResult(string result)
        {
            this.result=result;
        }

    }
}
